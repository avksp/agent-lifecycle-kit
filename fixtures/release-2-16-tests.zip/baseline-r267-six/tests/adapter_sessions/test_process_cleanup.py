from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from agent_lifecycle.adapter_sessions.process import run_process
from agent_lifecycle.contracts import canonical_digest


class ProcessCleanupTests(unittest.TestCase):
    def test_popen_failure_has_no_start_or_input_observation(self) -> None:
        events: list[str] = []
        with tempfile.TemporaryDirectory() as temporary:
            result = run_process(
                [str(Path(temporary) / "missing-executable")],
                env=dict(os.environ), timeout_seconds=5, stdin_text="private",
                on_started=lambda _event: events.append("start"),
                on_input=lambda _event: events.append("input"),
            )
        self.assertFalse(result["processStarted"])
        self.assertEqual(events, [])
        self.assertEqual(result["blockers"][0]["code"], "adapter-process-start-failed")
        self.assertIsNone(result.get("startObservation"))
        self.assertIsNone(result.get("inputObservation"))

    @unittest.skipUnless(os.name == "posix", "observed OS pipe uses POSIX descriptor readiness")
    def test_observed_start_precedes_complete_stdin_receipt(self) -> None:
        events: list[tuple[str, dict]] = []
        child_env = dict(os.environ)
        argv = [sys.executable, "-c", "import sys; sys.stdin.buffer.read()"]
        result = run_process(
            argv, env=child_env, timeout_seconds=5, stdin_text="exact prompt",
            on_started=lambda event: events.append(("start", event)),
            on_input=lambda event: events.append(("input", event)),
        )
        self.assertEqual(result["status"], "PASS", result)
        self.assertEqual([name for name, _ in events], ["start", "input"])
        self.assertEqual(events[0][1]["stdinStatus"], "PENDING")
        self.assertEqual(events[0][1]["argv"], argv)
        self.assertEqual(events[0][1]["environmentSha256"], canonical_digest(child_env))
        self.assertEqual(events[1][1]["status"], "COMPLETE")
        self.assertEqual(events[1][1]["acceptedBytes"], len(b"exact prompt"))
        self.assertFalse(events[1][1]["hostConsumptionProven"])

    @unittest.skipUnless(os.name == "posix", "observed OS pipe uses POSIX descriptor readiness")
    def test_start_observer_time_consumes_stdin_deadline(self) -> None:
        inputs: list[dict] = []

        def slow_start(_event: dict) -> None:
            time.sleep(0.12)

        result = run_process(
            [sys.executable, "-c", "import time; time.sleep(30)"],
            env=dict(os.environ), timeout_seconds=0.05, stdin_text="private",
            on_started=slow_start, on_input=inputs.append,
        )
        self.assertTrue(result["processStarted"])
        self.assertTrue(result["startedFailure"])
        self.assertEqual(inputs[0]["acceptedBytes"], 0)
        self.assertEqual(inputs[0]["status"], "PARTIAL_OR_FAILED")
        self.assertEqual(inputs[0]["errorType"], "cancelled-or-timeout")

    @unittest.skipUnless(os.name == "posix", "observed OS pipe uses POSIX descriptor readiness")
    def test_start_observation_failure_is_started_failure(self) -> None:
        def fail(_event: dict) -> None:
            raise OSError("receipt unavailable")

        result = run_process(
            [sys.executable, "-c", "import time; time.sleep(30)"],
            env=dict(os.environ), timeout_seconds=5, stdin_text="private",
            on_started=fail, on_input=lambda _event: None,
        )
        self.assertTrue(result["processStarted"])
        self.assertTrue(result["startedFailure"])
        self.assertEqual(result["status"], "FAIL")
        self.assertIsNone(result["processReceipt"])
        self.assertEqual(result["cleanup"]["status"], "PASS")

    @unittest.skipUnless(os.name == "posix", "observed OS pipe uses POSIX descriptor readiness")
    def test_broken_pipe_retains_partial_input_and_started_cost(self) -> None:
        events: list[dict] = []
        with patch("agent_lifecycle.adapter_sessions.process.os.write", side_effect=BrokenPipeError):
            result = run_process(
                [sys.executable, "-c", "import time; time.sleep(30)"],
                env=dict(os.environ), timeout_seconds=5, stdin_text="private",
                on_started=lambda _event: None, on_input=events.append,
            )
        self.assertTrue(result["processStarted"])
        self.assertTrue(result["startedFailure"])
        self.assertEqual(events[0]["status"], "PARTIAL_OR_FAILED")
        self.assertEqual(events[0]["acceptedBytes"], 0)
        self.assertEqual(result["blockers"][-1]["costStatus"], "UNAVAILABLE")

    @unittest.skipUnless(os.name == "posix", "observed OS pipe uses POSIX descriptors")
    def test_stdin_close_error_after_full_write_is_started_failure(self) -> None:
        real_popen = subprocess.Popen

        class CloseErrorStream:
            def __init__(self, stream: object) -> None:
                self.stream = stream

            def fileno(self) -> int:
                return self.stream.fileno()

            @property
            def closed(self) -> bool:
                return self.stream.closed

            def close(self) -> None:
                self.stream.close()
                raise OSError("simulated close failure after OS close")

        def popen_with_close_error(*args: object, **kwargs: object) -> subprocess.Popen:
            process = real_popen(*args, **kwargs)
            process.stdin = CloseErrorStream(process.stdin)
            return process

        events: list[dict] = []
        with patch("agent_lifecycle.adapter_sessions.process.subprocess.Popen",
                   side_effect=popen_with_close_error):
            result = run_process(
                [sys.executable, "-c", "import sys; sys.stdin.buffer.read()"],
                env=dict(os.environ), timeout_seconds=5, stdin_text="private",
                on_started=lambda _event: None, on_input=events.append,
            )
        self.assertTrue(result["processStarted"])
        self.assertTrue(result["startedFailure"])
        self.assertEqual(events[0]["acceptedBytes"], len(b"private"))
        self.assertFalse(events[0]["closeSucceeded"])
        self.assertEqual(events[0]["status"], "PARTIAL_OR_FAILED")
        self.assertEqual(result["blockers"][-1]["costStatus"], "UNAVAILABLE")

    @unittest.skipUnless(os.name == "posix", "observed OS pipe uses POSIX descriptor readiness")
    def test_short_write_and_input_receipt_failure_remain_started(self) -> None:
        with patch("agent_lifecycle.adapter_sessions.process.os.write", return_value=0):
            short = run_process(
                [sys.executable, "-c", "import time; time.sleep(30)"],
                env=dict(os.environ), timeout_seconds=5, stdin_text="private",
                on_started=lambda _event: None, on_input=lambda _event: None,
            )
        self.assertTrue(short["processStarted"])
        self.assertTrue(short["startedFailure"])
        self.assertEqual(short["inputObservation"]["status"], "PARTIAL_OR_FAILED")
        self.assertEqual(short["inputObservation"]["errorType"], "short-write")
        self.assertEqual(short["blockers"][-1]["costStatus"], "UNAVAILABLE")

        def fail_receipt(_event: dict) -> None:
            raise OSError("input receipt unavailable")

        lost = run_process(
            [sys.executable, "-c", "import time; time.sleep(30)"],
            env=dict(os.environ), timeout_seconds=5, stdin_text="private",
            on_started=lambda _event: None, on_input=fail_receipt,
        )
        self.assertTrue(lost["processStarted"])
        self.assertTrue(lost["startedFailure"])
        self.assertEqual(lost["inputObservation"]["status"], "COMPLETE")
        self.assertEqual(lost["blockers"][-1]["code"], "adapter-process-input-observation-failed")
        self.assertEqual(lost["blockers"][-1]["costStatus"], "UNAVAILABLE")

    @unittest.skipUnless(os.name == "posix", "process-group fixture uses POSIX sessions")
    def test_timeout_terminates_descendant_group(self) -> None:
        script = "import subprocess,sys,time; subprocess.Popen([sys.executable,'-c','import time; time.sleep(30)']); time.sleep(30)"

        result = run_process(
            [sys.executable, "-c", script],
            env=dict(os.environ),
            timeout_seconds=0.1,
            cleanup_grace_seconds=0.5,
            operation_id="cleanup-op",
            attempt_id="cleanup-attempt",
            adapter_id="fixture",
        )

        self.assertEqual(result["status"], "FAIL")
        self.assertTrue(result["timedOut"])
        self.assertEqual(result["cleanup"]["status"], "PASS")
        self.assertEqual(result["blockers"][0]["code"], "adapter-process-timeout")

    def test_normal_exit_has_cleanup_receipt(self) -> None:
        result = run_process(
            [sys.executable, "-c", "pass"],
            env=dict(os.environ),
            timeout_seconds=5,
            operation_id="normal-op",
            attempt_id="normal-attempt",
            adapter_id="fixture",
        )

        self.assertEqual(result["status"], "PASS", result)
        self.assertEqual(result["processReceipt"]["cleanup"]["status"], "PASS")


if __name__ == "__main__":
    unittest.main()
