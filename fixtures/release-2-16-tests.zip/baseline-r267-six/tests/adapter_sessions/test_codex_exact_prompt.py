from __future__ import annotations

import json
import hashlib
import os
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from agent_lifecycle.adapter_sessions.codex_exact_prompt import (
    CLAIM, ROUTE_ID, _observed_bundled_catalog, _observed_prompt_diagnostic,
    _record_transport_witness, _selected_binary_path, _selected_host_evidence,
    _recheck_alk_fit_sources, _recheck_active_workflow_state, _require_current_manifest,
    _require_fresh_catalog,
    _recompute_bootstrap_subject, _source_test_ids, _review_projection,
    _review_findings_match,
    _remove_snapshot_no_start, _snapshot_digest,
    _private_dir,
    _write_exclusive,
    assess_retention_pre_fixture, assess_structured_review_context_fit,
    build_structured_review_request, collect_two_turn_bootstrap_review,
    cleanup_no_start, cleanup_prestart_raw,
    create_prestart_raw_inventory, prepare_exact_prompt,
    read_codex_app_server_thread, reconcile_prelaunch_intents, record_proven_no_start,
    require_bootstrap_audit,
    stage_input_request,
    verify_prestart_raw_inventory,
)
from agent_lifecycle.adapter_sessions.launch_preflight import (
    _managed_task, _run_exact_managed_process, launch_from_local_profile,
)
from agent_lifecycle.adapter_sessions.process import run_process
from agent_lifecycle.adapter_sessions.unified_start import start_lifecycle
from agent_lifecycle.contracts import LifecycleError, canonical_bytes, canonical_digest
from agent_lifecycle.accounting.contracts import RunClosure
from agent_lifecycle.accounting.journal import Journal
from agent_lifecycle.accounting.input_fit import assess_local_input_fit, select_source_excerpts
from tests.accounting.test_journal import PROOF
from tests.accounting.test_opening_balances import import_data


class ExactPromptPrivateInputTests(unittest.TestCase):
    def test_bootstrap_case_names_rederived_from_current_sources(self) -> None:
        root = Path(__file__).parents[2]
        names, hashes = _source_test_ids(root, [
            "tests.adapter_sessions.test_codex_exact_prompt",
            "tests.cli.test_host_launch_commands",
        ])
        self.assertIn(
            "tests.adapter_sessions.test_codex_exact_prompt."
            "ExactPromptPrivateInputTests.test_orphan_staged_input_blocks_next_attempt",
            names)
        self.assertEqual(len(names), len(set(names)))
        self.assertEqual(hashes["tests/adapter_sessions/test_codex_exact_prompt.py"],
                         hashlib.sha256(Path(__file__).read_bytes()).hexdigest())

    def test_rb11_pre_is_pure_due_not_due_open_and_refusal(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            with Journal(Path(temporary) / "retention.db", PROOF) as journal:
                scope, policy, opening = import_data("run-1")
                self.assertEqual(journal.import_opening(scope, policy, opening).status, "IMPORTED")
                now = datetime.now(timezone.utc) + timedelta(seconds=1)
                self.assertIsNone(journal.closed_run("run-1"))
                oracle = lambda fixture, instant, clear=True: assess_retention_pre_fixture(
                    "run-1", fixture, instant, reconciliation_clear=clear)
                self.assertEqual(oracle(journal.closed_run("run-1"), now.isoformat())["status"],
                                 "OPEN_NO_PURGE_CLOCK")
                revision = journal.snapshot("run-1").journal_revision
                closure = RunClosure("close-1", "run-1", "reportedTokens:fixture:v1",
                                     now.isoformat(), (("run-1", revision),), PROOF, PROOF)
                closed_outcome = journal.close_run(closure, now.isoformat())
                self.assertEqual(closed_outcome.status, "CLOSED")
                verified = journal.closed_run("run-1")
                self.assertIsNotNone(verified)
                due_at = datetime.fromisoformat(closed_outcome.eligible_after)
                self.assertEqual(oracle(verified, (due_at - timedelta(microseconds=1)).isoformat())["status"],
                                 "NOT_DUE_PRE_ONLY")
                self.assertEqual(oracle(verified, due_at.isoformat()),
                                 {"caseId": "RB11-PRE", "runtimeStatus": "NOT_RUN",
                                  "status": "DUE_PRE_ONLY"})
                self.assertEqual(oracle(verified, due_at.isoformat(), False)["status"],
                                 "REFUSED_PRE_ONLY")
                self.assertEqual(oracle({**verified, "eligible_after": now.isoformat()},
                                        due_at.isoformat())["status"], "REFUSED_PRE_ONLY")
                self.assertEqual(oracle({**verified, "summary_digest": "0" * 64},
                                        due_at.isoformat())["status"], "REFUSED_PRE_ONLY")

    @staticmethod
    def _workflow_state(root: Path) -> dict[str, str]:
        event_log = root / "work/run.events.jsonl"
        event_log.parent.mkdir(parents=True, exist_ok=True)
        event_log.write_text("")
        return {"runId": "run-1", "eventLog": "work/run.events.jsonl"}

    @staticmethod
    def _snapshot(root: Path) -> Path:
        snapshot = (root / "work/release-2-16/runtime-private/codex-exact-prompt"
                    / "run-1/task-1/1/codex-home")
        _private_dir(snapshot.parent, boundary=root)
        snapshot.mkdir(mode=0o700)
        snapshot.chmod(0o700)
        config = snapshot / "config.toml"
        config.write_bytes(b"model = 'test-model'\n")
        config.chmod(0o400)
        return snapshot

    @unittest.skipUnless(os.name == "posix", "snapshot symlink fixture requires POSIX")
    def test_snapshot_symlink_ancestor_refuses_inventory_and_cleanup(self) -> None:
        with tempfile.TemporaryDirectory() as temporary, tempfile.TemporaryDirectory() as external:
            root = Path(temporary)
            outside = Path(external)
            snapshot = outside / "codex-exact-prompt/run-1/task-1/1/codex-home"
            snapshot.mkdir(parents=True, mode=0o700)
            (snapshot / "config.toml").write_text("private")
            parent = root / "work/release-2-16"
            parent.mkdir(parents=True)
            (parent / "runtime-private").symlink_to(outside, target_is_directory=True)
            selected = parent / "runtime-private/codex-exact-prompt/run-1/task-1/1/codex-home"
            with self.assertRaises(LifecycleError) as inventory:
                _snapshot_digest(selected, root=root)
            self.assertEqual(inventory.exception.code, "codex-exact-private-path-unsafe")
            with self.assertRaises(LifecycleError) as cleanup:
                _remove_snapshot_no_start(selected, root=root)
            self.assertEqual(cleanup.exception.code, "codex-exact-private-path-unsafe")
            self.assertTrue((snapshot / "config.toml").exists())

    def test_prestart_inventory_lists_snapshot_tree_and_no_start_cleans_it(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            private = (root / "work/release-2-16/private-details/codex-exact-prompt"
                       / "run-1/task-1/1")
            for name, raw in (("input-request.json", b"request"),
                              ("prompt-input.json", b"diagnostic"),
                              ("effective-config.json", b"config")):
                _write_exclusive(private / name, raw, root=root)
            snapshot = self._snapshot(root)
            inventory, marker, digest = create_prestart_raw_inventory(
                root, run_id="run-1", task_id="task-1", attempt_id="1",
                sealed_request=private / "input-request.json",
                state=self._workflow_state(root),
                plan_digest="a" * 64,
            )
            body = json.loads(inventory.read_text())
            self.assertEqual(body["journalAuthorityKind"], "WORKFLOW_EVENT_LOG_PRE_WS01")
            self.assertEqual(len(body["journalIdentity"]), 64)
            self.assertEqual([row["kind"] for row in body["sources"]],
                             ["sealed-request", "diagnostic", "effective-config",
                              "codex-home-snapshot-tree", "codex-home-snapshot-file"])
            self.assertEqual(body["sources"][3]["cleanupScope"],
                             "WHOLE_TREE_INCLUDING_POST_START_ADDITIONS")
            self.assertEqual(body["sources"][4]["path"],
                             str((snapshot / "config.toml").relative_to(root)))
            self.assertEqual(json.loads(marker.read_text())["inventorySha256"], digest)
            self.assertEqual(json.loads(marker.read_text())["status"], "PENDING")
            cleanup_prestart_raw(root, run_id="run-1", task_id="task-1", attempt_id="1",
                                 staging_source=None, proven_no_start=True)
            self.assertEqual(json.loads(marker.read_text())["status"], "DONE")
            self.assertEqual(list(private.glob("*.json")), [])
            self.assertFalse(snapshot.exists())

    def test_prestart_inventory_requires_journal_binding(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with self.assertRaises(LifecycleError) as raised:
                create_prestart_raw_inventory(
                    root, run_id="run-1", task_id="task-1", attempt_id="1",
                    sealed_request=root / "unbound.json",
                    state={"runId": "run-1", "eventLog": "work/missing.events.jsonl"},
                    plan_digest="a" * 64)
            self.assertEqual(raised.exception.code, "codex-exact-journal-unavailable")

    def test_prestart_inventory_refuses_symlinked_event_log(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            outside = root / "outside.events.jsonl"
            outside.write_text("")
            (root / "work").mkdir()
            (root / "work/run.events.jsonl").symlink_to(outside)
            with self.assertRaises(LifecycleError) as raised:
                create_prestart_raw_inventory(
                    root, run_id="run-1", task_id="task-1", attempt_id="1",
                    sealed_request=root / "unbound.json",
                    state={"runId": "run-1", "eventLog": "work/run.events.jsonl"},
                    plan_digest="a" * 64)
            self.assertEqual(raised.exception.code, "codex-exact-journal-unavailable")

    def test_last_boundary_detects_replaced_event_log_and_changed_raw(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            private = (root / "work/release-2-16/private-details/codex-exact-prompt"
                       / "run-1/task-1/1")
            for name in ("input-request.json", "prompt-input.json", "effective-config.json"):
                _write_exclusive(private / name, name.encode(), root=root)
            snapshot = self._snapshot(root)
            state = self._workflow_state(root)
            inventory, marker, _ = create_prestart_raw_inventory(
                root, run_id="run-1", task_id="task-1", attempt_id="1",
                sealed_request=private / "input-request.json", state=state,
                plan_digest="a" * 64)
            self.assertEqual(len(verify_prestart_raw_inventory(
                root, inventory_path=inventory, pending_path=marker,
                state=state, plan_digest="a" * 64)), 64)
            event_log = root / state["eventLog"]
            event_log.rename(event_log.with_name("old.events.jsonl"))
            event_log.write_text("")
            with self.assertRaises(LifecycleError) as replaced:
                verify_prestart_raw_inventory(
                    root, inventory_path=inventory, pending_path=marker,
                    state=state, plan_digest="a" * 64)
            self.assertEqual(replaced.exception.code, "codex-exact-raw-inventory-stale")
            event_log.unlink()
            event_log.with_name("old.events.jsonl").rename(event_log)
            (private / "prompt-input.json").write_text("changed")
            with self.assertRaises(LifecycleError) as changed:
                verify_prestart_raw_inventory(
                    root, inventory_path=inventory, pending_path=marker,
                    state=state, plan_digest="a" * 64)
            self.assertEqual(changed.exception.code, "codex-exact-raw-inventory-stale")
            (private / "prompt-input.json").write_text("prompt-input.json")
            (snapshot / "config.toml").chmod(0o600)
            (snapshot / "config.toml").write_bytes(b"changed")
            (snapshot / "config.toml").chmod(0o400)
            with self.assertRaises(LifecycleError) as changed_snapshot:
                verify_prestart_raw_inventory(
                    root, inventory_path=inventory, pending_path=marker,
                    state=state, plan_digest="a" * 64)
            self.assertEqual(changed_snapshot.exception.code, "codex-exact-raw-inventory-stale")

    def test_last_boundary_refusal_never_calls_runner(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            evidence = (root / "work/release-2-16/evidence/codex-exact-prompt"
                        / "run-1/task-1/1")
            start = evidence / "process-start.json"
            _write_exclusive(evidence / "prelaunch-intent.json", json.dumps({
                "schemaVersion": "alk-codex-prelaunch-intent.v1",
                "hostLaunchStarted": False,
            }).encode(), root=root)
            _write_exclusive(start, b"", root=root)
            runner = Mock()
            context = SimpleNamespace(
                root=root, runner=runner, timeout_seconds=5.0,
                env_receipt={}, profile_digest="profile", env=dict(os.environ),
            )

            def refuse() -> None:
                raise LifecycleError("codex-exact-raw-inventory-stale", "changed")

            receipt = _run_exact_managed_process(
                context, prepared={"verifyBeforeStart": refuse, "runId": "run-1",
                                   "taskId": "task-1", "attemptId": "1",
                                   "startReceiptPath": start},
                audit={}, session_id="session", risk_profile={"profileDigest": "risk"},
                host_identity={"status": "PASS"}, operation_id="op-1",
            )
            self.assertEqual(receipt["status"], "BLOCKED")
            self.assertFalse(receipt["hostLaunchStarted"])
            runner.assert_not_called()

    def test_observed_start_prevents_raw_early_delete(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            private = (root / "work/release-2-16/private-details/codex-exact-prompt"
                       / "run-1/task-1/1")
            for name in ("input-request.json", "prompt-input.json", "effective-config.json"):
                _write_exclusive(private / name, name.encode(), root=root)
            snapshot = self._snapshot(root)
            _, marker, _ = create_prestart_raw_inventory(
                root, run_id="run-1", task_id="task-1", attempt_id="1",
                sealed_request=private / "input-request.json",
                state=self._workflow_state(root),
                plan_digest="a" * 64)
            _write_exclusive(marker.with_name("process-start.json"), b"observed", root=root)
            with self.assertRaises(LifecycleError) as raised:
                cleanup_prestart_raw(root, run_id="run-1", task_id="task-1", attempt_id="1",
                                     staging_source=None, proven_no_start=True)
            self.assertEqual(raised.exception.code, "codex-exact-start-uncertain")
            self.assertTrue((private / "input-request.json").exists())
            self.assertTrue((snapshot / "config.toml").exists())
            self.assertEqual(json.loads(marker.read_text())["status"], "PENDING")

    def test_failed_attempt_raw_unlink_keeps_private_cleanup_pending(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            private = (root / "work/release-2-16/private-details/codex-exact-prompt"
                       / "run-1/task-1/1")
            for name in ("input-request.json", "prompt-input.json", "effective-config.json"):
                _write_exclusive(private / name, name.encode(), root=root)
            self._snapshot(root)
            _, marker, _ = create_prestart_raw_inventory(
                root, run_id="run-1", task_id="task-1", attempt_id="1",
                sealed_request=private / "input-request.json",
                state=self._workflow_state(root),
                plan_digest="a" * 64)
            diagnostic = private / "prompt-input.json"
            original_unlink = Path.unlink

            def refuse_diagnostic(path: Path, *args: object, **kwargs: object) -> None:
                if path == diagnostic:
                    raise OSError("unlink refused")
                original_unlink(path, *args, **kwargs)

            with patch.object(Path, "unlink", refuse_diagnostic):
                with self.assertRaises(LifecycleError) as raised:
                    cleanup_prestart_raw(root, run_id="run-1", task_id="task-1", attempt_id="1",
                                         staging_source=None, proven_no_start=True)
            self.assertEqual(raised.exception.code, "codex-exact-private-cleanup-pending")
            self.assertEqual(json.loads(marker.read_text())["status"], "PRIVATE_CLEANUP_PENDING")
            self.assertTrue(diagnostic.exists())

    def test_failed_snapshot_unlink_keeps_private_cleanup_pending(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            private = (root / "work/release-2-16/private-details/codex-exact-prompt"
                       / "run-1/task-1/1")
            for name in ("input-request.json", "prompt-input.json", "effective-config.json"):
                _write_exclusive(private / name, name.encode(), root=root)
            snapshot = self._snapshot(root)
            _, marker, _ = create_prestart_raw_inventory(
                root, run_id="run-1", task_id="task-1", attempt_id="1",
                sealed_request=private / "input-request.json",
                state=self._workflow_state(root), plan_digest="a" * 64)
            config = snapshot / "config.toml"
            original_unlink = Path.unlink

            def refuse_snapshot(path: Path, *args: object, **kwargs: object) -> None:
                if path == config:
                    raise OSError("snapshot unlink refused")
                original_unlink(path, *args, **kwargs)

            with patch.object(Path, "unlink", refuse_snapshot):
                with self.assertRaises(LifecycleError) as raised:
                    cleanup_prestart_raw(root, run_id="run-1", task_id="task-1", attempt_id="1",
                                         staging_source=None, proven_no_start=True)
            self.assertEqual(raised.exception.code, "codex-exact-private-cleanup-pending")
            self.assertEqual(json.loads(marker.read_text())["status"], "PRIVATE_CLEANUP_PENDING")
            self.assertTrue(config.exists())

    def test_unresolved_prelaunch_intent_holds_unknown_start_and_cost(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            evidence = (root / "work/release-2-16/evidence/codex-exact-prompt"
                        / "run-1/task-1/1")
            intent = evidence / "prelaunch-intent.json"
            start = evidence / "process-start.json"
            body = {"schemaVersion": "alk-codex-prelaunch-intent.v1",
                    "runId": "run-1", "taskId": "task-1", "attemptId": "1",
                    "finalPromptSha256": "a" * 64, "hostLaunchStarted": False}
            _write_exclusive(intent, json.dumps(body).encode(), root=root)
            _write_exclusive(start, b"", root=root)
            with self.assertRaises(LifecycleError) as raised:
                reconcile_prelaunch_intents(root)
            self.assertEqual(raised.exception.code, "codex-exact-start-uncertain")
            marker = evidence / "start-uncertain.json"
            self.assertEqual(json.loads(marker.read_text())["costStatus"], "UNAVAILABLE")
            with self.assertRaises(LifecycleError):
                reconcile_prelaunch_intents(root)

    def test_started_receipt_without_input_holds_raw_and_unknown_cost(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            evidence = (root / "work/release-2-16/evidence/codex-exact-prompt"
                        / "run-1/task-1/1")
            private = (root / "work/release-2-16/private-details/codex-exact-prompt"
                       / "run-1/task-1/1/input-request.json")
            _write_exclusive(private, b"retained started raw", root=root)
            identity = {"runId": "run-1", "taskId": "task-1", "attemptId": "1",
                        "finalPromptSha256": "a" * 64}
            _write_exclusive(evidence / "prelaunch-intent.json", canonical_bytes({
                "schemaVersion": "alk-codex-prelaunch-intent.v1", **identity,
                "plannedStdinBytes": 10, "hostLaunchStarted": False}), root=root)
            _write_exclusive(evidence / "process-start.json", canonical_bytes({
                "schemaVersion": "alk-codex-process-start.v1", **identity,
                "hostLaunchStarted": True, "stdinStatus": "PENDING"}), root=root)
            _write_exclusive(evidence / "process-input.json", b"", root=root)
            with self.assertRaises(LifecycleError) as raised:
                reconcile_prelaunch_intents(root)
            self.assertEqual(raised.exception.code, "codex-exact-start-uncertain")
            self.assertEqual(json.loads((evidence / "start-uncertain.json").read_text())["costStatus"],
                             "UNAVAILABLE")
            self.assertEqual(private.read_bytes(), b"retained started raw")

            _write_exclusive(evidence / "transport-equivalence.json", canonical_bytes({
                "schemaVersion": "alk-codex-os-pipe-transport.v1", **identity,
                "status": "OS_PIPE_ACCEPTED"}), root=root)
            with self.assertRaises(LifecycleError) as still_uncertain:
                reconcile_prelaunch_intents(root)
            self.assertEqual(still_uncertain.exception.code, "codex-exact-start-uncertain")

    def test_orphan_staged_input_blocks_next_attempt(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            current = stage_input_request(root, "current", {"routeId": ROUTE_ID})
            orphan = stage_input_request(root, "orphan", {"routeId": ROUTE_ID})
            with self.assertRaises(LifecycleError) as staged:
                reconcile_prelaunch_intents(root, active_staging_request=current)
            self.assertEqual(staged.exception.code, "codex-exact-start-uncertain")
            self.assertTrue(orphan.exists())
            marker = (root / "work/release-2-16/evidence/codex-exact-prompt/prestart"
                      / "orphan/orphan-private-input.json")
            self.assertEqual(json.loads(marker.read_text())["costStatus"], "UNAVAILABLE")

    def test_uncertain_prior_attempt_keeps_its_raw_when_new_staging_is_refused(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            prior = (root / "work/release-2-16/private-details/codex-exact-prompt"
                     / "run-1/task-1/1/input-request.json")
            _write_exclusive(prior, b"prior started raw", root=root)
            snapshot = self._snapshot(root)
            intent = (root / "work/release-2-16/evidence/codex-exact-prompt"
                      / "run-1/task-1/1/prelaunch-intent.json")
            _write_exclusive(intent, canonical_bytes({
                "schemaVersion": "alk-codex-prelaunch-intent.v1", "runId": "run-1",
                "taskId": "task-1", "attemptId": "1", "hostLaunchStarted": False,
                "finalPromptSha256": "a" * 64}), root=root)
            _write_exclusive(intent.with_name("process-start.json"), b"", root=root)
            fresh = stage_input_request(root, "new-request", {"routeId": ROUTE_ID})
            with self.assertRaises(LifecycleError) as blocked:
                prepare_exact_prompt(
                    project_root=root, input_request=fresh,
                    route_id=ROUTE_ID, requested_claim=CLAIM,
                    state={"runId": "run-1", "sourceRevision": "rev-1"},
                    task={"id": "task-1", "attempt": 1, "status": "RUNNING"},
                    manifest={}, lock_path=root / "plan.lock.json",
                    source_revision="rev-1", operation_id="op-1",
                    executable_identity={"status": "PASS"}, executable="codex",
                )
            self.assertEqual(blocked.exception.code, "codex-exact-start-uncertain")
            self.assertFalse(fresh.exists())
            self.assertEqual(prior.read_bytes(), b"prior started raw")
            self.assertTrue((snapshot / "config.toml").exists())

    def test_sealed_input_without_intent_blocks_next_attempt(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            sealed = (root / "work/release-2-16/private-details/codex-exact-prompt"
                      / "run-1/task-1/1/input-request.json")
            _write_exclusive(sealed, b"sealed before intent", root=root)
            with self.assertRaises(LifecycleError) as lost_intent:
                reconcile_prelaunch_intents(root)
            self.assertEqual(lost_intent.exception.code, "codex-exact-start-uncertain")
            self.assertEqual(sealed.read_bytes(), b"sealed before intent")
            marker = (root / "work/release-2-16/evidence/codex-exact-prompt"
                      / "run-1/task-1/1/orphan-private-input.json")
            self.assertEqual(json.loads(marker.read_text())["costStatus"], "UNAVAILABLE")

    def test_active_workflow_state_is_reopened_before_child_start(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            state_path = root / "state.json"
            state = {"runId": "run-1", "sourceRevision": "rev-1",
                     "tasks": [{"id": "task-1", "status": "RUNNING", "attempt": 1}]}
            state_path.write_bytes(canonical_bytes(state))
            _recheck_active_workflow_state(root, state_path, state, "run-1", "task-1", 1)
            state_path.write_bytes(canonical_bytes({
                **state, "tasks": [{"id": "task-1", "status": "CANCELLED", "attempt": 1}]}))
            with self.assertRaises(LifecycleError) as cancelled:
                _recheck_active_workflow_state(root, state_path, state, "run-1", "task-1", 1)
            self.assertEqual(cancelled.exception.code, "codex-exact-state-stale")
            state_path.write_bytes(canonical_bytes({
                **state, "tasks": [{"id": "task-1", "status": "RUNNING", "attempt": 2}]}))
            with self.assertRaises(LifecycleError) as advanced:
                _recheck_active_workflow_state(root, state_path, state, "run-1", "task-1", 1)
            self.assertEqual(advanced.exception.code, "codex-exact-state-stale")

    def test_post_popen_start_receipt_failure_reconciles_as_uncertain(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            evidence = (root / "work/release-2-16/evidence/codex-exact-prompt"
                        / "run-1/task-1/1")
            private = (root / "work/release-2-16/private-details/codex-exact-prompt"
                       / "run-1/task-1/1/input-request.json")
            _write_exclusive(private, b"retained raw", root=root)
            raw = b"private prompt"
            intent = {"schemaVersion": "alk-codex-prelaunch-intent.v1",
                      "runId": "run-1", "taskId": "task-1", "attemptId": "1",
                      "finalPromptSha256": hashlib.sha256(raw).hexdigest(),
                      "hostLaunchStarted": False}
            _write_exclusive(evidence / "prelaunch-intent.json", canonical_bytes(intent), root=root)
            _write_exclusive(evidence / "process-start.json", b"", root=root)

            def lose_start_receipt(event: dict) -> None:
                self.assertEqual(event["plannedStdinSha256"], intent["finalPromptSha256"])
                raise OSError("start receipt unavailable after Popen")

            result = run_process(
                [sys.executable, "-c", "import time; time.sleep(30)"],
                env=dict(os.environ), timeout_seconds=5, stdin_text=raw.decode(),
                on_started=lose_start_receipt, on_input=lambda _event: None,
            )
            self.assertTrue(result["processStarted"])
            self.assertTrue(result["startedFailure"])
            self.assertEqual(result["blockers"][-1]["costStatus"], "UNAVAILABLE")
            with self.assertRaises(LifecycleError) as raised:
                reconcile_prelaunch_intents(root)
            self.assertEqual(raised.exception.code, "codex-exact-start-uncertain")
            self.assertEqual(json.loads((evidence / "start-uncertain.json").read_text())["costStatus"],
                             "UNAVAILABLE")
            self.assertFalse((evidence / "proven-no-start.json").exists())
            self.assertEqual(private.read_bytes(), b"retained raw")

    @unittest.skipUnless(os.name == "posix", "crash fixture requires POSIX signals")
    def test_child_crash_after_observed_start_before_complete_input_is_uncertain(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            evidence = (root / "work/release-2-16/evidence/codex-exact-prompt"
                        / "run-1/task-1/1")
            private = (root / "work/release-2-16/private-details/codex-exact-prompt"
                       / "run-1/task-1/1/input-request.json")
            _write_exclusive(private, b"retained after crash", root=root)
            raw = "x" * 70_000
            _write_exclusive(evidence / "prelaunch-intent.json", canonical_bytes({
                "schemaVersion": "alk-codex-prelaunch-intent.v1",
                "runId": "run-1", "taskId": "task-1", "attemptId": "1",
                "finalPromptSha256": hashlib.sha256(raw.encode()).hexdigest(),
                "hostLaunchStarted": False}), root=root)
            _write_exclusive(evidence / "process-start.json", b"", root=root)
            started: list[dict] = []
            inputs: list[dict] = []

            def crash_after_start(event: dict) -> None:
                started.append(event)
                os.kill(event["pid"], signal.SIGKILL)
                time.sleep(0.05)

            result = run_process(
                [sys.executable, "-c", "import time; time.sleep(30)"],
                env=dict(os.environ), timeout_seconds=5, stdin_text=raw,
                max_input_bytes=80_000, on_started=crash_after_start,
                on_input=inputs.append,
            )
            self.assertEqual(started[0]["stdinStatus"], "PENDING")
            self.assertTrue(result["processStarted"])
            self.assertTrue(result["startedFailure"])
            self.assertEqual(inputs[0]["status"], "PARTIAL_OR_FAILED")
            self.assertEqual(result["blockers"][-1]["costStatus"], "UNAVAILABLE")
            with self.assertRaises(LifecycleError) as uncertain:
                reconcile_prelaunch_intents(root)
            self.assertEqual(uncertain.exception.code, "codex-exact-start-uncertain")
            self.assertEqual(private.read_bytes(), b"retained after crash")

    @unittest.skipUnless(os.name == "posix", "controller exit fixture requires POSIX process")
    def test_launcher_exit_after_popen_before_receipt_reconciles_on_restart(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            evidence = (root / "work/release-2-16/evidence/codex-exact-prompt"
                        / "run-1/task-1/1")
            private = (root / "work/release-2-16/private-details/codex-exact-prompt"
                       / "run-1/task-1/1/input-request.json")
            _write_exclusive(private, b"retained across launcher restart", root=root)
            _write_exclusive(evidence / "prelaunch-intent.json", canonical_bytes({
                "schemaVersion": "alk-codex-prelaunch-intent.v1",
                "runId": "run-1", "taskId": "task-1", "attemptId": "1",
                "finalPromptSha256": hashlib.sha256(b"private prompt").hexdigest(),
                "hostLaunchStarted": False}), root=root)
            _write_exclusive(evidence / "process-start.json", b"", root=root)
            controller = (
                "import os,sys\n"
                "from agent_lifecycle.adapter_sessions.process import run_process\n"
                "def crash_after_popen(_event): os._exit(77)\n"
                "run_process([sys.executable,'-c','import time;time.sleep(0.2)'],"
                " env=dict(os.environ),timeout_seconds=5,stdin_text='private prompt',"
                " on_started=crash_after_popen,on_input=lambda _event: None)\n"
            )
            env = {**os.environ,
                   "PYTHONPATH": str(Path(__file__).parents[2] / "src"),
                   "PYTHONDONTWRITEBYTECODE": "1"}
            ended = subprocess.run([sys.executable, "-c", controller],
                                   cwd=root, env=env, capture_output=True,
                                   timeout=5, check=False)
            self.assertEqual(ended.returncode, 77, ended.stderr.decode(errors="replace"))
            self.assertEqual((evidence / "process-start.json").read_bytes(), b"")
            with self.assertRaises(LifecycleError) as uncertain:
                reconcile_prelaunch_intents(root)
            self.assertEqual(uncertain.exception.code, "codex-exact-start-uncertain")
            marker = json.loads((evidence / "start-uncertain.json").read_bytes())
            self.assertEqual(marker["costStatus"], "UNAVAILABLE")
            self.assertFalse((evidence / "proven-no-start.json").exists())
            self.assertEqual(private.read_bytes(), b"retained across launcher restart")

    def test_proven_runner_no_start_resolves_reserved_intent(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            evidence = (root / "work/release-2-16/evidence/codex-exact-prompt"
                        / "run-1/task-1/1")
            intent = evidence / "prelaunch-intent.json"
            start = evidence / "process-start.json"
            _write_exclusive(intent, json.dumps({
                "schemaVersion": "alk-codex-prelaunch-intent.v1",
                "hostLaunchStarted": False,
            }).encode(), root=root)
            _write_exclusive(start, b"", root=root)
            record_proven_no_start(root, start)
            reconcile_prelaunch_intents(root)
            self.assertEqual(json.loads((evidence / "proven-no-start.json").read_text())["costStatus"],
                             "NOT_STARTED")

    def test_failed_no_start_unlink_retains_sticky_privacy_blocker(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = stage_input_request(root, "request-1", {"routeId": ROUTE_ID})
            original_unlink = Path.unlink

            def fail_first_unlink(path: Path, *args: object, **kwargs: object) -> None:
                if path == source:
                    raise OSError("unlink refused")
                original_unlink(path, *args, **kwargs)

            with patch.object(Path, "unlink", fail_first_unlink):
                with self.assertRaises(LifecycleError) as raised:
                    cleanup_no_start(root, None, source)
            self.assertEqual(raised.exception.code, "codex-exact-private-cleanup-pending")
            marker = (root / "work/release-2-16/evidence/codex-exact-prompt/prestart"
                      / "request-1/raw-cleanup-pending.json")
            self.assertEqual(json.loads(marker.read_text())["status"], "PRIVATE_CLEANUP_PENDING")
            self.assertEqual(marker.stat().st_mode & 0o777, 0o600)

            second = stage_input_request(root, "request-2", {"routeId": ROUTE_ID})
            with self.assertRaises(LifecycleError) as blocked:
                prepare_exact_prompt(
                    project_root=root, input_request=second,
                    route_id=ROUTE_ID, requested_claim=CLAIM,
                    state={"runId": "run-1", "sourceRevision": "rev-1"},
                    task={"id": "task-1", "attempt": 1, "status": "RUNNING"},
                    manifest={"planRevision": 68}, lock_path=root / "plan.lock.json",
                    source_revision="rev-1", operation_id="op-1",
                    executable_identity={"status": "PASS"}, executable="codex",
                )
            self.assertEqual(blocked.exception.code, "codex-exact-private-cleanup-pending")
            self.assertFalse(second.exists())
            cleanup_no_start(root, None, source)
            self.assertEqual(json.loads(marker.read_text())["status"], "DONE")
            self.assertFalse(source.exists())

    def test_staging_is_private_and_prelaunch_binding_failure_cleans_raw(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = stage_input_request(root, "request-1", {
                "routeId":ROUTE_ID, "requestedClaim":CLAIM,
                "runId":"run-1", "taskId":"task-1", "planDigest":"wrong",
            })
            self.assertEqual(source.stat().st_mode & 0o777, 0o600)
            self.assertEqual(source.parent.stat().st_mode & 0o777, 0o700)
            lock = root / "plan.lock.json"
            lock.write_text("{}")
            with self.assertRaises(LifecycleError) as raised:
                prepare_exact_prompt(
                    project_root=root, input_request=source,
                    route_id=ROUTE_ID, requested_claim=CLAIM,
                    state={"runId":"run-1", "sourceRevision":"rev-1"},
                    task={"id":"task-1", "attempt":1, "status":"RUNNING"},
                    manifest={"planRevision":67}, lock_path=lock,
                    source_revision="rev-1", operation_id="op-1",
                    executable_identity={"status":"PASS"}, executable="codex",
                )
            self.assertEqual(raised.exception.code, "codex-exact-request-binding-mismatch")
            self.assertEqual(list(root.rglob("input-request.json")), [])

    def test_symlinked_private_parent_is_refused(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "work/release-2-16").mkdir(parents=True)
            outside = root / "outside"
            outside.mkdir()
            (root / "work/release-2-16/private-details").symlink_to(outside, target_is_directory=True)
            with self.assertRaises(LifecycleError) as raised:
                stage_input_request(root, "request-1", {"routeId":ROUTE_ID})
            self.assertEqual(raised.exception.code, "codex-exact-private-path-unsafe")
            self.assertEqual(list(outside.iterdir()), [])

    def test_missing_independent_bootstrap_audit_refuses(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaises(LifecycleError) as raised:
                require_bootstrap_audit(Path(temporary), plan_digest="a" * 64,
                                        lock_sha256="b" * 64, selected_binary_sha256="c" * 64)
            self.assertEqual(raised.exception.code, "codex-exact-bootstrap-audit-missing")

    @patch("agent_lifecycle.adapter_sessions.codex_exact_prompt._source_test_ids",
           side_effect=lambda _root, modules: (
               ["fixture.c34"] if "test_codex_exact_prompt" in modules[0]
               else ["fixture.c35"], {}))
    def test_bootstrap_subject_reopens_real_wip_and_private_support(
        self, _synthetic_ids: Mock,
    ) -> None:
        # Synthetic Git/WIP fixture tests the verifier; it is never an audit verdict.
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            contract = json.loads((Path(__file__).parents[2] / "tasks/release-2-16"
                                   / "route-bootstrap-contract.json").read_text())
            owned = contract["ownership"]["temporaryLeadWritePaths"]

            def git(*args: str) -> bytes:
                return subprocess.run(["git", *args], cwd=root, check=True,
                                      capture_output=True).stdout

            git("init", "-q")
            for relative in owned[:4]:
                path = root / relative
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(("base:" + relative).encode())
            git("add", "--", "src")
            git("-c", "user.name=Fixture", "-c", "user.email=fixture@example.invalid",
                "commit", "-qm", "base")
            for relative in owned:
                path = root / relative
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(("after:" + relative).encode())
            six = {}
            tracked, untracked = [], []
            for relative in owned:
                current = (root / relative).read_bytes()
                head = subprocess.run(["git", "show", f"HEAD:{relative}"], cwd=root,
                                      capture_output=True)
                six[relative] = {"beforeExists": head.returncode == 0,
                                 "beforeSha256": hashlib.sha256(head.stdout).hexdigest()
                                 if head.returncode == 0 else None,
                                 "afterSha256": hashlib.sha256(current).hexdigest()}
                row = {"path": relative, "currentBytes": len(current),
                       "currentSha256": hashlib.sha256(current).hexdigest()}
                (tracked if head.returncode == 0 else untracked).append(row)
            diff = git("diff", "--binary", "--", "src", "tests", "policy", "tools")
            inventory_subject = {
                "gitHead": git("rev-parse", "HEAD").decode().strip(),
                "trackedDiff": {"sha256": hashlib.sha256(diff).hexdigest(),
                                "bytes": len(diff)},
                "trackedModified": tracked, "untracked": untracked,
            }
            inventory = {"inventorySubject": inventory_subject,
                         "canonicalInventorySubjectSha256": canonical_digest(inventory_subject)}
            support = root / "work/release-2-16/evidence/route-bootstrap/support"
            admission = {"status": "ADMITTED_PREAPPROVED_BY_USER",
                         "bootstrapAdmissionId": "fixture-admission",
                         "implementationOriginAdmissionId": "r166-pre-ws01-route-bootstrap",
                         "priorUnknownHolds": 7, "tokenCap": 3,
                         "admittedUnknownHolds": 10, "actualModelTokens": None,
                         "costStatus": "UNAVAILABLE"}
            admission_raw = canonical_bytes(admission)
            raw = {"before-wip-inventory.json": canonical_bytes(inventory),
                   "after-wip-inventory.json": canonical_bytes(inventory),
                   "cost.json": canonical_bytes({"costStatus": "UNAVAILABLE",
                                                  "heldUnknownTokens": 10,
                                                  "actualModelTokens": None,
                                                  "priorUnknownHolds": 7,
                                                  "windowCap": 3,
                                                  "implementationOriginAdmissionId":
                                                      "r166-pre-ws01-route-bootstrap",
                                                  "admissionSha256": hashlib.sha256(
                                                      admission_raw).hexdigest()}),
                   "admission.json": admission_raw}
            outputs = []
            for command in contract["validation"]["commands"]:
                ident = command["id"].lower()
                stderr = b"----------------------------------------------------------------------\nRan 1 test in 0.001s\n\nOK\n"
                test_names = [f"fixture.{ident}"]
                case_ids = (["RB01", "RB02", "RB03", "RB04", "RB07", "RB09", "RB11-PRE", "RB12"]
                            if ident == "c34" else ["RB05", "RB06", "RB08", "RB10"])
                cases = {"commandId": command["id"], "testNames": test_names,
                         "sourceTestFileSha256": {},
                         "localCaseMapping": {case: test_names for case in case_ids}}
                raw[f"{ident}.stdout"] = b""
                raw[f"{ident}.stderr"] = stderr
                raw[f"{ident}-result.json"] = canonical_bytes({
                    ident: "PASS_1_TESTS", f"{ident}StderrSha256": hashlib.sha256(stderr).hexdigest()})
                raw[f"{ident}-cases.json"] = canonical_bytes(cases)
                python_path = Path(sys.executable).resolve()
                raw[f"{ident}-execution.json"] = canonical_bytes({
                    "source": "SUBPROCESS_CAPTURE",
                    "contractCommand": command["command"],
                    "commandDigest": command["canonicalDigest"],
                    "argv": command["command"].split()[2:],
                    "environment": {"PYTHONDONTWRITEBYTECODE": "1", "PYTHONPATH": "src"},
                    "cwd": str(root), "exitCode": 0,
                    "stdoutSha256": hashlib.sha256(b"").hexdigest(),
                    "stderrSha256": hashlib.sha256(stderr).hexdigest(),
                    "testNames": test_names, "sourceTestFileSha256": {},
                    "pythonResolvedPath": str(python_path),
                    "pythonSha256": hashlib.sha256(python_path.read_bytes()).hexdigest(),
                    "processId": 12345,
                    "startedAtUtc": "2026-09-25T00:00:00+00:00",
                    "endedAtUtc": "2026-09-25T00:00:01+00:00",
                })
                outputs.append({"commandDigest": command["canonicalDigest"],
                                "outputSha256": canonical_digest({
                                    "stdoutSha256": hashlib.sha256(b"").hexdigest(),
                                    "stderrSha256": hashlib.sha256(stderr).hexdigest()}),
                                "caseDigest": canonical_digest(cases)})
            for name, value in raw.items():
                _write_exclusive(support / name, value, root=root)
            subject = {
                "r69LockSha256": "a" * 64, "r69PlanDigest": "b" * 64,
                "bootstrapAdmissionId": "fixture-admission", "bootstrapId": "fixture-bootstrap",
                "sixPathBeforeAfterSha256": six,
                "wholeWipBeforeAfterInventoryDigest": {
                    "before": inventory["canonicalInventorySubjectSha256"],
                    "after": inventory["canonicalInventorySubjectSha256"]},
                "C34C35CommandOutputCaseDigests": outputs,
                "privateSupportReceiptDigests": {
                    name: hashlib.sha256(value).hexdigest() for name, value in raw.items()},
                "costStatus": "UNAVAILABLE", "heldUnknownTokens": 10,
            }
            subject["reviewedInputDigest"] = canonical_digest(subject)
            base = support.parent
            _recompute_bootstrap_subject(root, base, contract, subject)
            changed = root / owned[0]
            changed.write_bytes(b"unreviewed edit")
            with self.assertRaises(LifecycleError):
                _recompute_bootstrap_subject(root, base, contract, subject)
            changed.write_bytes(("after:" + owned[0]).encode())
            (support / "admission.json").write_bytes(canonical_bytes({**admission, "tokenCap": 4}))
            with self.assertRaises(LifecycleError):
                _recompute_bootstrap_subject(root, base, contract, subject)
            (support / "admission.json").write_bytes(admission_raw)
            (support / "c34.stderr").write_bytes(b"forged OK\n")
            with self.assertRaises(LifecycleError):
                _recompute_bootstrap_subject(root, base, contract, subject)

    @patch("agent_lifecycle.adapter_sessions.codex_exact_prompt._recompute_bootstrap_subject")
    def test_r69_review_gate_requires_two_completed_turns_and_exact_transport(
        self, _synthetic_source_fixture: Mock,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            contract = json.loads((Path(__file__).parents[2] / "tasks/release-2-16"
                                   / "route-bootstrap-contract.json").read_text())
            contract_path = root / "tasks/release-2-16/route-bootstrap-contract.json"
            contract_path.parent.mkdir(parents=True)
            contract_path.write_text(json.dumps(contract))
            six = {}
            for relative in contract["ownership"]["temporaryLeadWritePaths"]:
                path = root / relative
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(relative.encode())
                six[relative] = {"beforeExists": False, "beforeSha256": None,
                                 "afterSha256": hashlib.sha256(path.read_bytes()).hexdigest()}
            subject = {"r69LockSha256": "a" * 64, "r69PlanDigest": "b" * 64,
                       "bootstrapAdmissionId": "admission-1", "bootstrapId": "bootstrap-1",
                       "sixPathBeforeAfterSha256": six,
                       "wholeWipBeforeAfterInventoryDigest": {"before": "c" * 64,
                                                                 "after": "d" * 64},
                       "C34C35CommandOutputCaseDigests": [
                           {"commandDigest": "e" * 64, "outputSha256": "f" * 64,
                            "caseDigest": "1" * 64},
                           {"commandDigest": "2" * 64, "outputSha256": "3" * 64,
                            "caseDigest": "4" * 64}],
                       "privateSupportReceiptDigests": {"support": "5" * 64},
                       "costStatus": "UNAVAILABLE", "heldUnknownTokens": 73400000,
                       "reviewedInputDigest": "6" * 64}
            digest = lambda raw: hashlib.sha256(raw).hexdigest()
            review_raw = b"NO_CURRENT_FINDINGS\n"
            body_schema = contract["artifacts"]["reviewerBody"]["closedSchema"]
            body_raw = canonical_bytes({"schemaVersion": "alk-route-bootstrap-reviewer-body.v3",
                                        "verdict": "PASS", "phase": "PRE_WS01",
                                        "rb11RuntimeStatus": "NOT_RUN", "subject": subject,
                                        "findings": [], "reviewTextSha256": digest(review_raw)})
            request_raw = build_structured_review_request(
                request_id=5, thread_id="review-thread", review_turn_id="review-turn",
                review_item_id="review-item", review_text=review_raw.decode(),
                subject=subject, output_schema=body_schema, cwd=root)
            self.assertTrue(request_raw.endswith(b"\n"))
            request = json.loads(request_raw)
            transport = {"requestId": 5, "responseId": 5, "turnId": "body-turn",
                         "writeCompleted": True, "writtenBytes": len(request_raw),
                         "writtenRequestSha256": digest(request_raw)}
            response = {"thread": {"id": "review-thread", "model": "selected-model", "turns": [
                {"id": "review-turn", "status": "completed", "items": [
                    {"id": "entered", "type": "enteredReviewMode", "review": "current"},
                    {"id": "review-item", "type": "exitedReviewMode",
                     "review": review_raw.decode()}]},
                {"id": "body-turn", "status": "completed", "items": [
                    {"id": "input-item", "type": "userMessage",
                     "content": request["params"]["input"]},
                    {"id": "body-item", "type": "agentMessage",
                     "text": body_raw.decode()}]}]}}
            fit = {**assess_structured_review_context_fit(
                first_turn_total_tokens=1000,
                first_turn_items=response["thread"]["turns"][0]["items"],
                request_bytes=request_raw, model_context_window=200000),
                "selectedBinarySha256": "7" * 64, "selectedModel": "selected-model"}
            fit_raw = canonical_bytes(fit)
            assignment = {"subject": {**subject, "codexBinarySha256": "7" * 64},
                          "reviewerActorId": "reviewer", "reviewerSessionId": "review-session",
                          "leadActorId": "lead", "leadSessionId": "lead-session"}
            assignment_raw = canonical_bytes(assignment)
            sequence = [{"turnId": turn["id"], "items": [
                {"id": item["id"], "type": item["type"],
                 "sha256": digest(canonical_bytes(item))} for item in turn["items"]]}
                for turn in response["thread"]["turns"]]
            from agent_lifecycle.adapter_sessions.codex_exact_prompt import _STRUCTURED_REVIEW_INSTRUCTION
            provenance = {"source": "LOCAL_CODEX_APP_SERVER_TWO_TURN_REVIEW_THREAD",
                          "reviewAssignmentSha256": digest(assignment_raw),
                          "codexBinarySha256": "7" * 64,
                          "reviewThreadId": "review-thread", "reviewTurnId": "review-turn",
                          "reviewItemId": "review-item", "rawReviewTextSha256": digest(review_raw),
                          "structuredTurnId": "body-turn", "structuredItemId": "body-item",
                          "structuredRequestSha256": digest(request_raw),
                          "outputSchemaSha256": digest(canonical_bytes(body_schema)),
                          "fixedPromptTemplateSha256": digest(_STRUCTURED_REVIEW_INSTRUCTION.encode()),
                          "rawStructuredBodySha256": digest(body_raw),
                          "structuredRequestId": 5,
                          "structuredRequestBytes": len(request_raw),
                          "structuredWrittenBytes": len(request_raw),
                          "structuredWriteCompleted": True,
                          "structuredInputItemId": "input-item",
                          "structuredInputSha256": digest(canonical_bytes(request["params"]["input"])),
                          "secondTurnContextFitSha256": digest(fit_raw),
                          "structuredResponseId": 5,
                          "structuredWrittenRequestSha256": digest(request_raw),
                          "orderedThreadItemSequenceSha256": canonical_digest(sequence)}
            provenance["threadReadSha256"] = canonical_digest(
                _review_projection(response, provenance, request))
            audit = {"schemaVersion": "alk-route-bootstrap-independent-audit.v3",
                     "createdAtUtc": "2026-09-25T00:00:00Z", "verdict": "PASS",
                     "reviewerActorId": "reviewer", "reviewerSessionId": "review-session",
                     "leadActorId": "lead", "leadSessionId": "lead-session", **subject,
                     "producerProvenance": provenance,
                     "phase": "PRE_WS01", "rb11RuntimeStatus": "NOT_RUN",
                     "reviewerBodySha256": digest(body_raw),
                     "reviewTextSha256": digest(review_raw), "collectorStatus": "VERIFIED"}
            audit_raw = canonical_bytes(audit)
            receipt = {"planDigest": "b" * 64, "lockSha256": "a" * 64,
                       "independentAuditSha256": digest(audit_raw),
                       "reviewerBodySha256": digest(body_raw),
                       "independentAuditVerdict": "PASS", **subject}
            base = root / "work/release-2-16/evidence/route-bootstrap"
            for name, raw in (("review-subject.json", canonical_bytes(subject)),
                              ("review-text.raw", review_raw),
                              ("structured-turn-request.json", request_raw),
                              ("structured-turn-response.json", canonical_bytes(transport)),
                              ("second-turn-context-fit.json", fit_raw),
                              ("review-assignment.json", assignment_raw)):
                _write_exclusive(base / name, raw, root=root)
            self.assertEqual(collect_two_turn_bootstrap_review(
                root, thread_read=response, selected_binary_sha256="7" * 64,
                created_at_utc="2026-09-25T00:00:00Z")["verdict"], "PASS")
            self.assertEqual((base / "independent-audit.json").read_bytes(), audit_raw)
            _write_exclusive(base / "receipt.json", canonical_bytes(receipt), root=root)
            self.assertEqual(require_bootstrap_audit(
                root, plan_digest="b" * 64, lock_sha256="a" * 64,
                selected_binary_sha256="7" * 64,
                fresh_thread_read=lambda _: response)["status"], "PASS")
            transport_path = base / "structured-turn-response.json"
            transport_path.write_bytes(canonical_bytes({**transport, "writtenBytes": len(request_raw) - 1}))
            with self.assertRaises(LifecycleError) as short_write:
                require_bootstrap_audit(root, plan_digest="b" * 64, lock_sha256="a" * 64,
                                        selected_binary_sha256="7" * 64,
                                        fresh_thread_read=lambda _: response)
            self.assertEqual(short_write.exception.code, "codex-exact-bootstrap-review-stale")
            transport_path.write_bytes(canonical_bytes(transport))
            fit_path = base / "second-turn-context-fit.json"
            fit_path.write_bytes(canonical_bytes({**fit, "firstTurnTotalTokens": None}))
            with self.assertRaises(LifecycleError) as unknown_context:
                require_bootstrap_audit(root, plan_digest="b" * 64, lock_sha256="a" * 64,
                                        selected_binary_sha256="7" * 64,
                                        fresh_thread_read=lambda _: response)
            self.assertEqual(unknown_context.exception.code,
                             "codex-exact-bootstrap-review-context-unknown")
            fit_path.write_bytes(fit_raw)
            with self.assertRaises(LifecycleError) as no_read:
                require_bootstrap_audit(root, plan_digest="b" * 64, lock_sha256="a" * 64,
                                        selected_binary_sha256="7" * 64)
            self.assertEqual(no_read.exception.code, "codex-exact-bootstrap-review-unavailable")
            response["thread"]["turns"][1]["items"][1]["text"] = "changed"
            with self.assertRaises(LifecycleError) as stale:
                require_bootstrap_audit(root, plan_digest="b" * 64, lock_sha256="a" * 64,
                                        selected_binary_sha256="7" * 64,
                                        fresh_thread_read=lambda _: response)
            self.assertEqual(stale.exception.code, "codex-exact-bootstrap-review-stale")
            response["thread"]["turns"][1]["items"][1]["text"] = body_raw.decode()
            (base / "review-text.raw").write_bytes(b"Looks solid overall")
            with self.assertRaises(LifecycleError) as prose:
                require_bootstrap_audit(root, plan_digest="b" * 64, lock_sha256="a" * 64,
                                        selected_binary_sha256="7" * 64,
                                        fresh_thread_read=lambda _: response)
            self.assertEqual(prose.exception.code, "codex-exact-bootstrap-audit-mismatch")

    def test_r69_review_prefix_and_finding_mapping_fail_closed(self) -> None:
        raw = "- [P1] Current source omits the required receipt"
        finding = {"id": "F1", "severity": "HIGH", "status": "OPEN",
                   "evidence": "required receipt absent", "reviewLevel": "P1",
                   "rawSpanSha256": hashlib.sha256(raw.encode()).hexdigest()}
        self.assertTrue(_review_findings_match(raw, {"verdict": "FAIL", "findings": [finding]}))
        self.assertFalse(_review_findings_match(raw, {"verdict": "PASS", "findings": []}))
        self.assertFalse(_review_findings_match(raw, {"verdict": "FAIL", "findings": []}))
        self.assertFalse(_review_findings_match(raw, {"verdict": "FAIL", "findings": [
            {**finding, "severity": "LOW"}]}))
        request = {"params": {"input": [{"type": "text", "text": "assigned review"}]}}
        turns = [
            {"id": "prefix", "status": "interrupted", "items": [
                {"id": "prefix-input", "type": "userMessage", "content": []}]},
            {"id": "review-turn", "status": "completed", "items": [
                {"id": "review-item", "type": "exitedReviewMode",
                 "review": "NO_CURRENT_FINDINGS"}]},
            {"id": "body-turn", "status": "completed", "items": [
                {"id": "body-input", "type": "userMessage", "content": request["params"]["input"]},
                {"id": "body-item", "type": "agentMessage", "text": "{}"}]},
        ]
        sequence = [{"turnId": turn["id"], "items": [
            {"id": item["id"], "type": item["type"],
             "sha256": hashlib.sha256(canonical_bytes(item)).hexdigest()}
            for item in turn["items"]]} for turn in turns]
        provenance = {"reviewThreadId": "thread", "reviewTurnId": "review-turn",
                      "reviewItemId": "review-item", "structuredTurnId": "body-turn",
                      "structuredItemId": "body-item", "structuredInputItemId": "body-input",
                      "structuredInputSha256": hashlib.sha256(
                          canonical_bytes(request["params"]["input"])).hexdigest(),
                      "orderedThreadItemSequenceSha256": canonical_digest(sequence)}
        response = {"thread": {"id": "thread", "turns": turns}}
        projection = _review_projection(response, provenance, request)
        self.assertEqual(len(projection["turns"]), 3)
        with self.assertRaises(LifecycleError):
            _review_projection({"thread": {"id": "thread", "turns": [
                *turns[:2], {"id": "intervening", "status": "completed", "items": []},
                turns[2]]}}, provenance, request)
        with self.assertRaises(LifecycleError):
            assess_structured_review_context_fit(
                first_turn_total_tokens=100,
                first_turn_items=turns[0]["items"] + turns[1]["items"],
                request_bytes=b"x" * 65536, model_context_window=1000)

    def test_local_app_server_fresh_read_uses_only_documented_read_protocol(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            executable = root / "codex"
            executable.write_text(
                f"#!{sys.executable}\n"
                "import json,sys\n"
                "from pathlib import Path\n"
                "for line in sys.stdin:\n"
                "    message = json.loads(line)\n"
                "    with Path('methods.log').open('a') as stream:\n"
                "        stream.write(message['method'] + '\\n')\n"
                "    if message['method'] == 'initialize':\n"
                "        print(json.dumps({'id': message['id'], 'result': {}}), flush=True)\n"
                "    elif message['method'] == 'thread/read':\n"
                "        print(json.dumps({'id': message['id'], 'result': {'thread': "
                "{'id': message['params']['threadId'], 'turns': []}}}), flush=True)\n"
            )
            executable.chmod(0o700)
            digest = hashlib.sha256(executable.read_bytes()).hexdigest()
            response = read_codex_app_server_thread(
                root, executable=str(executable), expected_binary_sha256=digest,
                thread_id="review-thread")
            self.assertEqual(response["thread"]["id"], "review-thread")
            self.assertEqual((root / "methods.log").read_text().splitlines(),
                             ["initialize", "initialized", "thread/read"])
            path_response = read_codex_app_server_thread(
                root, executable="codex", expected_binary_sha256=digest,
                thread_id="review-thread", process_env={**os.environ, "PATH": str(root)})
            self.assertEqual(path_response["thread"]["id"], "review-thread")
            with self.assertRaises(LifecycleError) as wrong_binary:
                read_codex_app_server_thread(root, executable=str(executable),
                                             expected_binary_sha256="0" * 64,
                                             thread_id="review-thread")
            self.assertEqual(wrong_binary.exception.code,
                             "codex-exact-bootstrap-review-unavailable")


class ExactPromptPublicGateTests(unittest.TestCase):
    def test_public_unified_early_refusals_cleanup_staged_request(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            for profile in (None, {}):
                with self.subTest(project_profile=profile):
                    source = stage_input_request(root, f"early-{len(list(root.rglob('input-request.json')))}",
                                                 {"routeId": ROUTE_ID})
                    receipt = start_lifecycle(
                        adapter_id="codex", mode="implement", project_root=root,
                        project_profile=profile, route_id=ROUTE_ID,
                        requested_claim=CLAIM, input_request=source)
                    self.assertEqual(receipt["status"], "BLOCKED")
                    self.assertFalse(receipt["hostLaunchStarted"])
                    self.assertFalse(source.exists())
                    self.assertEqual(receipt["receiptDigest"], canonical_digest({
                        k: v for k, v in receipt.items() if k != "receiptDigest"}))

    def test_public_unified_cleanup_failure_retains_privacy_blocker(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            source = stage_input_request(root, "sticky-unified", {"routeId": ROUTE_ID})
            with patch("agent_lifecycle.adapter_sessions.unified_start.cleanup_no_start",
                       side_effect=LifecycleError("codex-exact-private-cleanup-pending",
                                                  "cleanup failed")):
                receipt = start_lifecycle(adapter_id="codex", mode="implement",
                                          project_root=root, input_request=source)
            self.assertEqual(receipt["status"], "BLOCKED")
            self.assertEqual(receipt["blockers"][-1]["code"],
                             "codex-exact-private-cleanup-pending")
            self.assertTrue(source.exists())
            cleanup_no_start(root, None, source)

    def test_direct_context_and_managed_read_failure_cleanup_before_start(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            source = stage_input_request(root, "missing-profile", {"routeId": ROUTE_ID})
            missing_profile = launch_from_local_profile(
                profile_path=root / "missing-profile.json", operation="managedTask",
                adapter_id="codex", project_root=root, route_id=ROUTE_ID,
                requested_claim=CLAIM, input_request=source)
            self.assertEqual(missing_profile["status"], "BLOCKED")
            self.assertFalse(missing_profile["hostLaunchStarted"])
            self.assertEqual(missing_profile["receiptDigest"], canonical_digest({
                k: v for k, v in missing_profile.items() if k != "receiptDigest"}))
            self.assertFalse(source.exists())

            source = stage_input_request(root, "missing-profile-sticky", {"routeId": ROUTE_ID})
            original_unlink = Path.unlink

            def refuse_source(path: Path, *args: object, **kwargs: object) -> None:
                if path == source:
                    raise OSError("simulated cleanup refusal")
                original_unlink(path, *args, **kwargs)

            with patch.object(Path, "unlink", refuse_source):
                sticky = launch_from_local_profile(
                    profile_path=root / "missing-profile.json", operation="managedTask",
                    adapter_id="codex", project_root=root, route_id=ROUTE_ID,
                    requested_claim=CLAIM, input_request=source)
            self.assertEqual(sticky["status"], "BLOCKED")
            self.assertEqual(sticky["blockers"][-1]["code"],
                             "codex-exact-private-cleanup-pending")
            self.assertTrue(source.exists())
            cleanup_no_start(root, None, source)

            source = stage_input_request(root, "missing-manifest", {"routeId": ROUTE_ID})
            runner = Mock()
            context = SimpleNamespace(root=root, profile_adapter="codex",
                                      timeout_seconds=5.0, env_receipt={},
                                      profile_digest="profile", runner=runner)
            with patch("agent_lifecycle.adapter_sessions.launch_preflight._managed_launch_blockers",
                       return_value=[]), patch(
                       "agent_lifecycle.adapter_sessions.launch_preflight._identity",
                       return_value={"status": "PASS"}):
                receipt = _managed_task(
                    context, session_id="session", explicit_launch=True,
                    state_path=root / "state.json", manifest_path=root / "missing.json",
                    lock_path=root / "lock.json", task_id="task-1", operation_id="op-1",
                    source_revision="rev-1", risk_profile={"profileDigest": "risk"},
                    route_id=ROUTE_ID, requested_claim=CLAIM, input_request=source)
            self.assertEqual(receipt["status"], "BLOCKED")
            self.assertFalse(receipt["hostLaunchStarted"])
            self.assertFalse(source.exists())
            runner.assert_not_called()

    def test_direct_planning_route_refusal_cleans_staged_request(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            source = stage_input_request(root, "planning-refusal", {"routeId": ROUTE_ID})
            context = SimpleNamespace(root=root, profile_adapter="codex",
                                      timeout_seconds=5.0, env_receipt={},
                                      profile_digest="profile")
            with patch("agent_lifecycle.adapter_sessions.launch_preflight._load_context",
                       return_value=context):
                receipt = launch_from_local_profile(
                    profile_path=root / "profile.json", operation="planningTask",
                    project_root=root, route_id=ROUTE_ID,
                    requested_claim=CLAIM, input_request=source)
            self.assertEqual(receipt["status"], "BLOCKED")
            self.assertFalse(source.exists())

    def test_rb12_dynamic_catalog_change_refuses_with_same_binary(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            catalog_file = root / "catalog.json"
            catalog_file.write_text(json.dumps({
                "models": [{"slug": "test-model", "context_window": 32768}]}))
            binary = root / "codex"
            binary.write_text(
                f"#!{sys.executable}\n"
                "import sys\nfrom pathlib import Path\n"
                "if sys.argv[1:] == ['--version']:\n"
                "    print('codex-cli test')\n"
                "elif sys.argv[1:] == ['debug', 'models', '--bundled']:\n"
                f"    print(Path({str(catalog_file)!r}).read_text())\n"
                "else:\n    sys.exit(2)\n")
            binary.chmod(0o755)
            identity = {"status": "PASS",
                        "resolvedPathSha256": hashlib.sha256(os.fsencode(str(binary))).hexdigest(),
                        "executableContentSha256": hashlib.sha256(binary.read_bytes()).hexdigest()}
            expected = _observed_bundled_catalog(
                root, str(binary), identity, "test-model", dict(os.environ))
            _require_fresh_catalog(
                root, str(binary), identity, "test-model", dict(os.environ), expected)
            catalog_file.write_text(json.dumps({
                "models": [{"slug": "test-model", "context_window": 32769}]}))
            self.assertEqual(hashlib.sha256(binary.read_bytes()).hexdigest(),
                             identity["executableContentSha256"])
            with self.assertRaises(LifecycleError) as stale:
                _require_fresh_catalog(
                    root, str(binary), identity, "test-model", dict(os.environ), expected)
            self.assertEqual(stale.exception.code, "codex-exact-catalog-stale")

    def test_rb12_final_packet_source_and_output_plan_recheck(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            source_repo = Path(__file__).parents[2]
            contract_raw = (source_repo / "tasks/release-2-16/alk-input-fit-contract.json").read_bytes()
            profile_raw = (source_repo / "profiles/small-context-profile.v1.json").read_bytes()
            contract = json.loads(contract_raw)
            profile = json.loads(profile_raw)
            paths = contract["sourceScope"]["orderedContextRefs"]
            source = root / paths[0]
            source.parent.mkdir(parents=True)
            source_bytes = b"bounded selected source"
            source.write_bytes(source_bytes)
            packet = {"schemaVersion": "agent-task-packet.v1",
                      "plan": {"planDigest": "a" * 64, "packageId": "release-2-16"},
                      "task": {"id": "task-1", "plannedItems": []},
                      "context": {"refs": paths}, "ownership": {}, "specification": {},
                      "validation": {}, "acceptance": []}
            summary = {key: [] for key in profile["requiredSummaryFields"]}
            selected = select_source_excerpts(
                root, packet, contract,
                [{"path": paths[0], "fileSha256": hashlib.sha256(source_bytes).hexdigest(),
                  "startByte": 0, "endByte": len(source_bytes),
                  "selectedSha256": hashlib.sha256(source_bytes).hexdigest(),
                  "candidateDigest": "a" * 64,
                  "estimatorId": "canonical-json-bytes-div-4-ceil"}],
                run_id="run-1", attempt_id="1", manifest_sha256="a" * 64,
                candidate_digest="a" * 64,
                estimator_id="canonical-json-bytes-div-4-ceil")
            binding = {key: selected[key] for key in
                       ("runId", "taskId", "attemptId", "planDigest", "manifestSha256",
                        "candidateDigest", "estimatorId")}
            request = {"role": "worker", "hostVersion": "0.test",
                       "hostMode": "managedTask", "estimatorId": "canonical-json-bytes-div-4-ceil",
                       "instruction": "bounded task", "schema": {}, "latestUser": ""}
            fit = assess_local_input_fit(
                root, contract, profile, packet, summary, selected,
                role="worker", host_adapter_id="codex", host_version="0.test",
                host_mode="managedTask", estimator_id=request["estimatorId"],
                instruction=request["instruction"], schema={}, current_binding=binding,
                latest_user="", window="16k")
            self.assertEqual(fit["status"], "PASS_ALK_COMPONENTS_ONLY")
            files = {
                "packet": (root / "work/release-2-16/packet.json", canonical_bytes(packet)),
                "contract": (root / "tasks/release-2-16/alk-input-fit-contract.json", contract_raw),
                "profile": (root / "profiles/small-context-profile.v1.json", profile_raw),
                "source": (source, source_bytes),
            }
            for path, raw in files.values():
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(raw)

            def recheck() -> None:
                _recheck_alk_fit_sources(
                    root, request, "work/release-2-16/packet.json",
                    hashlib.sha256(files["packet"][1]).hexdigest(),
                    hashlib.sha256(contract_raw).hexdigest(),
                    hashlib.sha256(profile_raw).hexdigest(),
                    "a" * 64, "task-1", selected, summary, binding, fit["receiptDigest"])

            recheck()
            altered_contract = {**contract, "commonEnvelope": {
                **contract["commonEnvelope"], "reservedOutputEstimatedTokens": 3073}}
            mutations = {"packet": files["packet"][1] + b"\n",
                         "source": b"changed selected source",
                         "contract": canonical_bytes(altered_contract),
                         "profile": profile_raw + b"\n"}
            for name, changed in mutations.items():
                with self.subTest(changed=name):
                    path, original = files[name]
                    path.write_bytes(changed)
                    with self.assertRaises(LifecycleError):
                        recheck()
                    path.write_bytes(original)

    def test_final_manifest_reopen_refuses_manifest_only_change(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            manifest_path = root / "manifest.json"
            captured = {"status": "FROZEN", "planRevision": 69}
            manifest_path.write_bytes(canonical_bytes(captured))
            expected = canonical_digest(captured)
            _require_current_manifest(root, manifest_path, captured, expected)
            manifest_path.write_bytes(canonical_bytes({**captured, "planRevision": 70}))
            with self.assertRaises(LifecycleError) as changed:
                _require_current_manifest(root, manifest_path, captured, expected)
            self.assertEqual(changed.exception.code, "codex-exact-plan-stale")
            with self.assertRaises(LifecycleError) as missing:
                _require_current_manifest(root, None, captured, expected)
            self.assertEqual(missing.exception.code, "codex-exact-plan-stale")

    def test_selected_binary_path_refuses_changed_bytes_before_start(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            binary = root / "codex"
            binary.write_bytes(b"first")
            identity = {"status": "PASS",
                        "resolvedPathSha256": hashlib.sha256(os.fsencode(str(binary))).hexdigest(),
                        "executableContentSha256": hashlib.sha256(b"first").hexdigest()}
            self.assertEqual(_selected_binary_path(str(binary), identity, dict(os.environ)), binary)
            binary.write_bytes(b"changed")
            with self.assertRaises(LifecycleError) as changed:
                _selected_binary_path(str(binary), identity, dict(os.environ))
            self.assertEqual(changed.exception.code, "codex-exact-binary-mismatch")

    def test_transport_witness_requires_observed_start_and_input(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            evidence = (root / "work/release-2-16/evidence/codex-exact-prompt"
                        / "run-1/task-1/1")
            event = {"status": "COMPLETE", "acceptedBytes": 5,
                     "acceptedSha256": "a" * 64, "closeSucceeded": True}
            input_body = {"schemaVersion": "alk-codex-process-input.v1",
                          "runId": "run-1", "taskId": "task-1", "attemptId": "1",
                          "role": "worker", "finalPromptSha256": "a" * 64, **event}
            _write_exclusive(evidence / "process-input.json",
                             canonical_bytes(input_body), root=root)
            with self.assertRaises(LifecycleError):
                _record_transport_witness(
                    root, evidence, run_id="run-1", task_id="task-1",
                    attempt_id="1", role="worker", final_sha="a" * 64,
                    config_manifest_sha="b" * 64,
                    diagnostic={"rawSha256": "c" * 64, "items": []}, event=event)
            self.assertFalse((evidence / "transport-equivalence.json").exists())
            start_body = {"schemaVersion": "alk-codex-process-start.v1",
                          "hostLaunchStarted": True, "stdinStatus": "PENDING",
                          "runId": "run-1", "taskId": "task-1", "attemptId": "1",
                          "role": "worker", "finalPromptSha256": "a" * 64}
            _write_exclusive(evidence / "process-start.json",
                             canonical_bytes(start_body), root=root)
            _record_transport_witness(
                root, evidence, run_id="run-1", task_id="task-1",
                attempt_id="1", role="worker", final_sha="a" * 64,
                config_manifest_sha="b" * 64,
                diagnostic={"rawSha256": "c" * 64, "items": []}, event=event)
            body = json.loads((evidence / "transport-equivalence.json").read_text())
            self.assertEqual(body["status"], "OS_PIPE_ACCEPTED")
            self.assertEqual(body["childConsumption"], "UNPROVEN")

    @unittest.skipUnless(os.name == "posix", "joined OS-pipe fixture uses POSIX descriptors")
    def test_local_one_attempt_process_receipts_join_transport_witness(self) -> None:
        # This is a Python child fixture through the real runner, not selected Codex proof.
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            evidence = (root / "work/release-2-16/evidence/codex-exact-prompt"
                        / "run-1/task-1/1")
            start_path = evidence / "process-start.json"
            input_path = evidence / "process-input.json"
            final = "one attempt local prompt"
            final_sha = hashlib.sha256(final.encode()).hexdigest()
            diagnostic = {"rawSha256": "d" * 64, "items": []}

            def on_started(event: dict) -> None:
                _write_exclusive(start_path, canonical_bytes({
                    "schemaVersion": "alk-codex-process-start.v1",
                    "hostLaunchStarted": True, "stdinStatus": "PENDING",
                    "runId": "run-1", "taskId": "task-1", "attemptId": "1",
                    "role": "worker", "finalPromptSha256": final_sha,
                    "processIdentityHash": event["processIdentityHash"],
                    "plannedStdinSha256": event["plannedStdinSha256"],
                    "plannedStdinBytes": event["plannedStdinBytes"],
                }), root=root)

            def on_input(event: dict) -> None:
                _write_exclusive(input_path, canonical_bytes({
                    "schemaVersion": "alk-codex-process-input.v1",
                    "runId": "run-1", "taskId": "task-1", "attemptId": "1",
                    "role": "worker", "finalPromptSha256": final_sha,
                    **event,
                }), root=root)
                _record_transport_witness(
                    root, evidence, run_id="run-1", task_id="task-1",
                    attempt_id="1", role="worker", final_sha=final_sha,
                    config_manifest_sha="c" * 64, diagnostic=diagnostic,
                    event=event)

            context = SimpleNamespace(
                root=root, runner=run_process, timeout_seconds=5.0,
                env=dict(os.environ), env_receipt={}, profile_digest="profile",
            )
            prepared = {
                "verifyBeforeStart": lambda: None,
                "argv": [sys.executable, "-c", "import sys; sys.stdin.buffer.read()"],
                "codexHome": str(root / "codex-home"), "stdinText": final,
                "runId": "run-1", "taskId": "task-1", "attemptId": "1",
                "sealedSha256": "a" * 64, "finalPromptSha256": final_sha,
                "fitReceiptDigest": "b" * 64,
                "startReceiptPath": start_path, "inputReceiptPath": input_path,
                "onStarted": on_started, "onInput": on_input,
            }
            receipt = _run_exact_managed_process(
                context, prepared=prepared, audit={"auditSha256": "e" * 64},
                session_id="session", risk_profile={"profileDigest": "risk"},
                host_identity={"status": "PASS"}, operation_id="op-1")
            self.assertEqual(receipt["status"], "PASS", receipt)
            self.assertTrue(receipt["hostLaunchStarted"])
            start_raw, input_raw = start_path.read_bytes(), input_path.read_bytes()
            joined = json.loads((evidence / "transport-equivalence.json").read_bytes())
            self.assertEqual(joined["status"], "OS_PIPE_ACCEPTED")
            self.assertEqual(joined["attemptId"], "1")
            self.assertEqual(joined["processStartSha256"], hashlib.sha256(start_raw).hexdigest())
            self.assertEqual(joined["processInputSha256"], hashlib.sha256(input_raw).hexdigest())
            self.assertEqual(joined["observedPipe"]["acceptedSha256"], final_sha)
            self.assertEqual(receipt["exactPrompt"]["startReceiptSha256"],
                             joined["processStartSha256"])
            self.assertEqual(receipt["exactPrompt"]["inputReceiptSha256"],
                             joined["processInputSha256"])
            self.assertEqual(joined["childConsumption"], "UNPROVEN")

    def test_prelaunch_sources_config_and_diagnostic_without_caller_pass(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            binary = root / "codex"
            binary.write_text(
                f"#!{sys.executable}\n"
                "import json, sys\n"
                "if sys.argv[1:] == ['--version']:\n"
                "    print('codex-cli test')\n"
                "elif sys.argv[1:] == ['debug', 'models', '--bundled']:\n"
                "    print(json.dumps({'models':[{'slug':'test-model','context_window':32768}]}))\n"
                "elif sys.argv[1:3] == ['debug', 'prompt-input']:\n"
                "    print(json.dumps([{'type':'message','role':'user','content':sys.argv[3]}]))\n"
                "else:\n"
                "    sys.exit(2)\n"
            )
            binary.chmod(0o755)
            binary_sha = hashlib.sha256(binary.read_bytes()).hexdigest()
            identity = {"status": "PASS", "executableContentSha256": binary_sha,
                        "resolvedPathSha256": hashlib.sha256(os.fsencode(str(binary))).hexdigest()}
            snapshot = (root / "work/release-2-16/runtime-private/codex-exact-prompt"
                        / "run-1/task-1/1/codex-home")
            _private_dir(snapshot.parent, boundary=root)
            snapshot.mkdir(mode=0o700)
            request = {"selectedHost": {"model": "test-model", "binarySha256": binary_sha,
                                        "catalogWindowTokens": 32768}}
            observed = _selected_host_evidence(
                root, request, identity, "a" * 64, "run-1", "task-1", "1",
                str(binary), dict(os.environ), "worker")
            self.assertEqual(observed[0], "test-model")
            self.assertEqual(observed[3]["actualChildWindow"], "UNPROVEN")
            self.assertEqual(observed[4]["execStdinEquivalence"], "UNPROVEN")
            private = (root / "work/release-2-16/private-details/codex-exact-prompt"
                       / "run-1/task-1/1")
            config = json.loads((private / "effective-config.json").read_text())
            self.assertEqual(config["childInternalEffectiveConfig"], "UNPROVEN")
            self.assertEqual((private / "prompt-input.json").stat().st_mode & 0o777, 0o600)
            evidence = (root / "work/release-2-16/evidence/codex-exact-prompt"
                        / "run-1/task-1/1")
            manifest = json.loads((evidence / "config-snapshot-manifest.json").read_text())
            self.assertEqual(manifest["status"], "OBSERVED_ALK_SOURCE")
            self.assertFalse((evidence / "transport-equivalence.json").exists())
            request["selectedHost"]["configManifestSha256"] = "b" * 64
            with self.assertRaises(LifecycleError) as legacy:
                _selected_host_evidence(root, request, identity, "a" * 64,
                                        "run-2", "task-1", "1", str(binary),
                                        dict(os.environ), "worker")
            self.assertEqual(legacy.exception.code, "codex-exact-legacy-witness-refused")

    def test_per_role_diagnostic_is_private_and_only_a_candidate(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            binary = root / "codex"
            binary.write_text(
                f"#!{sys.executable}\n"
                "import json, sys\n"
                "assert sys.argv[1:3] == ['debug', 'prompt-input']\n"
                "print(json.dumps([{'type':'message','role':'user',"
                "'content':sys.argv[3]}]))\n"
            )
            binary.chmod(0o755)
            binary_sha = hashlib.sha256(binary.read_bytes()).hexdigest()
            identity = {"status": "PASS", "executableContentSha256": binary_sha,
                        "resolvedPathSha256": hashlib.sha256(os.fsencode(str(binary))).hexdigest()}
            snapshot = root / "snapshot"
            snapshot.mkdir(mode=0o700)
            observed = _observed_prompt_diagnostic(
                root, str(binary), identity, snapshot=snapshot, model="test-model",
                role="worker", run_id="run-1", task_id="task-1", attempt_id="1",
                final_sha="a" * 64, process_env=dict(os.environ))
            raw = (root / "work/release-2-16/private-details/codex-exact-prompt"
                   / "run-1/task-1/1/prompt-input.json")
            self.assertEqual(observed["rawSha256"], hashlib.sha256(raw.read_bytes()).hexdigest())
            self.assertEqual(raw.stat().st_mode & 0o777, 0o600)
            self.assertEqual(observed["itemCount"], 1)
            self.assertEqual(observed["execStdinEquivalence"], "UNPROVEN")
            self.assertNotIn("private model input", raw.read_text())

    def test_selected_binary_bundled_catalog_is_observed_and_bounded(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            binary = root / "codex"
            binary.write_text(
                f"#!{sys.executable}\n"
                "import json, sys\n"
                "if sys.argv[1:] == ['--version']:\n"
                "    print('codex-cli test')\n"
                "elif sys.argv[1:] == ['debug', 'models', '--bundled']:\n"
                "    print(json.dumps({'models':[{'slug':'test-model','context_window':32768}]}))\n"
                "else:\n"
                "    sys.exit(2)\n"
            )
            binary.chmod(0o755)
            binary = binary.resolve(strict=True)
            binary_sha = hashlib.sha256(binary.read_bytes()).hexdigest()
            identity = {"status": "PASS", "executableContentSha256": binary_sha,
                        "resolvedPathSha256": hashlib.sha256(os.fsencode(str(binary))).hexdigest()}
            observed = _observed_bundled_catalog(
                root, str(binary), identity, "test-model", dict(os.environ))
            self.assertEqual(observed["catalogWindowTokens"], 32768)
            self.assertEqual(observed["binarySha256"], binary_sha)
            self.assertEqual(observed["actualChildWindow"], "UNPROVEN")
            with self.assertRaises(LifecycleError) as missing:
                _observed_bundled_catalog(root, str(binary), identity,
                                          "absent-model", dict(os.environ))
            self.assertEqual(missing.exception.code, "codex-exact-model-unavailable")

    def test_early_managed_blocker_cleans_staged_request_without_start(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = stage_input_request(root, "request-early", {"routeId": ROUTE_ID})
            runner = Mock()
            context = SimpleNamespace(
                root=root, profile_adapter="codex", timeout_seconds=5.0,
                env_receipt={}, profile_digest="profile", runner=runner,
            )
            with patch("agent_lifecycle.adapter_sessions.launch_preflight._managed_launch_blockers",
                       return_value=[{"code": "local-launch-required-field-missing"}]):
                receipt = _managed_task(
                    context, session_id="session", explicit_launch=True,
                    state_path=None, manifest_path=None, lock_path=None,
                    task_id=None, operation_id=None, source_revision=None,
                    risk_profile=None, route_id=ROUTE_ID, requested_claim=CLAIM,
                    input_request=source,
                )
            self.assertEqual(receipt["status"], "BLOCKED")
            self.assertFalse(receipt["hostLaunchStarted"])
            self.assertEqual(receipt["blockers"][0]["code"],
                             "local-launch-required-field-missing")
            self.assertFalse(source.exists())
            runner.assert_not_called()

    def test_early_refusal_cannot_delete_another_attempt_sealed_request(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            sealed = (root / "work/release-2-16/private-details/codex-exact-prompt"
                      / "run-1/task-1/1/input-request.json")
            _write_exclusive(sealed, b"started raw from another attempt", root=root)
            context = SimpleNamespace(
                root=root, profile_adapter="codex", timeout_seconds=5.0,
                env_receipt={}, profile_digest="profile", runner=Mock(),
            )
            with patch("agent_lifecycle.adapter_sessions.launch_preflight._managed_launch_blockers",
                       return_value=[{"code": "local-launch-required-field-missing"}]):
                receipt = _managed_task(
                    context, session_id="session", explicit_launch=True,
                    state_path=None, manifest_path=None, lock_path=None,
                    task_id=None, operation_id=None, source_revision=None,
                    risk_profile=None, route_id=ROUTE_ID, requested_claim=CLAIM,
                    input_request=sealed,
                )
            self.assertEqual(receipt["status"], "BLOCKED")
            self.assertEqual(receipt["blockers"][-1]["code"],
                             "codex-exact-private-path-unsafe")
            self.assertEqual(sealed.read_bytes(), b"started raw from another attempt")
            context.runner.assert_not_called()

    def test_early_identity_failure_cleans_staged_request_without_start(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = stage_input_request(root, "request-identity", {"routeId": ROUTE_ID})
            runner = Mock()
            context = SimpleNamespace(
                root=root, profile_adapter="codex", timeout_seconds=5.0,
                env_receipt={}, profile_digest="profile", runner=runner,
            )
            with patch("agent_lifecycle.adapter_sessions.launch_preflight._managed_launch_blockers",
                       return_value=[]), patch(
                       "agent_lifecycle.adapter_sessions.launch_preflight._identity",
                       return_value={"status": "BLOCKED"}):
                receipt = _managed_task(
                    context, session_id="session", explicit_launch=True,
                    state_path=root / "state.json", manifest_path=root / "manifest.json",
                    lock_path=root / "lock.json", task_id="task-1", operation_id="op-1",
                    source_revision="rev-1", risk_profile={"profileDigest": "risk"},
                    route_id=ROUTE_ID, requested_claim=CLAIM, input_request=source,
                )
            self.assertEqual(receipt["status"], "BLOCKED")
            self.assertEqual(receipt["blockers"][0]["code"],
                             "local-launch-executable-identity-unavailable")
            self.assertFalse(source.exists())
            runner.assert_not_called()

    def test_direct_managed_route_missing_arguments_never_calls_runner(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            runner = Mock()
            context = SimpleNamespace(
                root=root, profile_adapter="codex", timeout_seconds=5.0,
                env_receipt={}, profile_digest="profile", runner=runner,
                profile={"executable":"codex"}, env=dict(os.environ),
            )
            manifest = {"status":"FROZEN", "package":{"id":"release-2-16"},
                        "runtimePolicy":{"preExecutionBootstrap":{}}, "planRevision":67}
            state = {"tasks":[{"id":"task-1", "attempt":1, "status":"RUNNING"}]}
            paths = [root / name for name in ("state.json", "manifest.json", "lock.json")]
            values = {paths[0]:state, paths[1]:manifest, paths[2]:{}}
            with patch("agent_lifecycle.adapter_sessions.launch_preflight._managed_launch_blockers", return_value=[]), \
                 patch("agent_lifecycle.adapter_sessions.launch_preflight._identity", return_value={"status":"PASS"}), \
                 patch("agent_lifecycle.adapter_sessions.launch_preflight.read_json_object", side_effect=lambda p, **_: values[p]), \
                 patch("agent_lifecycle.adapter_sessions.launch_preflight.verify_plan_package_integrity"), \
                 patch("agent_lifecycle.adapter_sessions.launch_preflight.validate_task_risk_profile"):
                receipt = _managed_task(
                    context, session_id="session", explicit_launch=True,
                    state_path=paths[0], manifest_path=paths[1], lock_path=paths[2],
                    task_id="task-1", operation_id="op-1", source_revision="rev-1",
                    risk_profile={"profileDigest":"risk", "adapterId":"codex"},
                    route_id=None, requested_claim=None, input_request=None,
                )
            self.assertEqual(receipt["status"], "BLOCKED")
            self.assertFalse(receipt["hostLaunchStarted"])
            self.assertEqual(receipt["blockers"][0]["code"], "codex-exact-route-required")
            runner.assert_not_called()

    def test_direct_and_unified_route_reach_same_prestart_attempt_gate(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            state_path, manifest_path, lock_path = (
                root / name for name in ("state.json", "manifest.json", "lock.json"))
            lock_path.write_text("{}")
            state = {"tasks": [{"id": "task-1", "attempt": 1, "status": "RUNNING"}]}
            manifest = {"status": "FROZEN", "package": {"id": "release-2-16"},
                        "runtimePolicy": {"preExecutionBootstrap": {}}, "planRevision": 69}
            values = {state_path: state, manifest_path: manifest, lock_path: {}}
            context = SimpleNamespace(
                root=root, profile_adapter="codex", timeout_seconds=5.0,
                env_receipt={}, profile_digest="profile", runner=run_process,
                profile={"executable": "codex"}, env=dict(os.environ),
            )
            binary_sha = "7" * 64
            blocked = {"status": "BLOCKED", "hostLaunchStarted": False,
                       "blockers": [{"code": "local-prestart-stop"}]}
            task_receipt = {
                "status": "READY", "action": "MANAGED_RUN", "input": {},
                "workflowBinding": {
                    "state": str(state_path), "manifest": str(manifest_path),
                    "lock": str(lock_path), "task": "task-1",
                    "operationId": "op-1", "sourceRevision": "rev-1"},
                "adapterSessionReceipt": {"sessionId": "session", "nextAction": {
                    "riskExecutionProfile": {"profileDigest": "risk"}}},
            }
            with patch("agent_lifecycle.adapter_sessions.launch_preflight._managed_launch_blockers",
                       return_value=[]), patch(
                       "agent_lifecycle.adapter_sessions.launch_preflight._identity",
                       return_value={"status": "PASS", "executableContentSha256": binary_sha}), patch(
                       "agent_lifecycle.adapter_sessions.launch_preflight.read_json_object",
                       side_effect=lambda path, **_: values[path]), patch(
                       "agent_lifecycle.adapter_sessions.launch_preflight.verify_plan_package_integrity"), patch(
                       "agent_lifecycle.adapter_sessions.launch_preflight.validate_task_risk_profile"), patch(
                       "agent_lifecycle.adapter_sessions.launch_preflight.require_bootstrap_audit",
                       return_value={"status": "PASS"}) as audit, patch(
                       "agent_lifecycle.adapter_sessions.launch_preflight.prepare_exact_prompt",
                       return_value={"attemptId": "1"}) as prepare, patch(
                       "agent_lifecycle.adapter_sessions.launch_preflight._run_exact_managed_process",
                       return_value=blocked) as stop, patch(
                       "agent_lifecycle.adapter_sessions.launch_preflight._load_context",
                       return_value=context), patch(
                       "agent_lifecycle.adapter_sessions.unified_start._inspect_task_source",
                       return_value=({}, {"schemaVersion": "agent-adapter-task-run-request.v1"}, b"{}")), patch(
                       "agent_lifecycle.adapter_sessions.unified_start._missing_frozen_bindings",
                       return_value=[]), patch(
                       "agent_lifecycle.adapter_sessions.unified_start.start_adapter_task",
                       return_value=task_receipt), patch(
                       "agent_lifecycle.adapter_sessions.unified_start.strategy_projection_for_receipt",
                       return_value={}):
                direct_source = stage_input_request(root, "direct-positive", {"routeId": ROUTE_ID})
                direct = _managed_task(
                    context, session_id="session", explicit_launch=True,
                    state_path=state_path, manifest_path=manifest_path,
                    lock_path=lock_path, task_id="task-1", operation_id="op-1",
                    source_revision="rev-1", risk_profile={"profileDigest": "risk"},
                    route_id=ROUTE_ID, requested_claim=CLAIM,
                    input_request=direct_source)
                self.assertFalse(direct["hostLaunchStarted"])
                cleanup_no_start(root, None, direct_source)

                unified_source = stage_input_request(root, "unified-positive", {"routeId": ROUTE_ID})
                unified = start_lifecycle(
                    adapter_id="codex", mode="implement", task_text="{}", launch=True,
                    host_launch_profile_path=root / "profile.json", project_root=root,
                    route_id=ROUTE_ID, requested_claim=CLAIM,
                    input_request=unified_source)
                self.assertFalse(unified["hostLaunchStarted"])
                self.assertFalse(unified_source.exists())

            self.assertEqual(audit.call_count, 2)
            self.assertEqual(prepare.call_count, 2)
            self.assertEqual(stop.call_count, 2)
            for called in prepare.call_args_list:
                self.assertEqual(called.kwargs["task"]["attempt"], 1)
                self.assertEqual(called.kwargs["operation_id"], "op-1")
                self.assertEqual(called.kwargs["route_id"], ROUTE_ID)
            for called in audit.call_args_list:
                self.assertEqual(called.kwargs["selected_binary_sha256"], binary_sha)

    def test_unified_no_profile_preserves_explicit_route_fields(self) -> None:
        source = Path("work/release-2-16/private-details/codex-exact-prompt/staging/r/input-request.json")
        with patch("agent_lifecycle.adapter_sessions.unified_start._start_lifecycle_core", return_value={"status":"BLOCKED"}) as core:
            start_lifecycle(adapter_id="codex", mode="implement", route_id=ROUTE_ID,
                            requested_claim=CLAIM, input_request=source)
        self.assertEqual(core.call_args.kwargs["route_id"], ROUTE_ID)
        self.assertEqual(core.call_args.kwargs["requested_claim"], CLAIM)
        self.assertEqual(core.call_args.kwargs["input_request"], source)

    def test_unified_project_profile_preserves_explicit_route_fields(self) -> None:
        source = Path("work/release-2-16/private-details/codex-exact-prompt/staging/r/input-request.json")
        effective = {"defaultAdapter":"codex", "defaultMode":"implement", "defaultRisk":"S0"}
        with patch("agent_lifecycle.adapter_sessions.unified_start._profile_plan_authority", return_value=({},{})), \
             patch("agent_lifecycle.adapter_sessions.unified_start.build_effective_project_profile", return_value=effective), \
             patch("agent_lifecycle.adapter_sessions.unified_start._start_lifecycle_core", return_value={"status":"BLOCKED"}) as core, \
             patch("agent_lifecycle.adapter_sessions.unified_start._build_guided_action_receipt", return_value={"status":"BLOCKED"}):
            start_lifecycle(adapter_id="codex", mode="implement", project_profile={},
                            route_id=ROUTE_ID, requested_claim=CLAIM, input_request=source)
        self.assertEqual(core.call_args.kwargs["route_id"], ROUTE_ID)
        self.assertEqual(core.call_args.kwargs["requested_claim"], CLAIM)
        self.assertEqual(core.call_args.kwargs["input_request"], source)


if __name__ == "__main__":
    unittest.main()
