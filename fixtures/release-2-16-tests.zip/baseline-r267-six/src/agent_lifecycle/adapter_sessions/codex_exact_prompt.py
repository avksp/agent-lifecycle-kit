"""Private, fail-closed ALK input boundary for the scoped Codex exec route.

The local fit receipt proves only ALK-controlled bytes. Selected-host proof is
separate, and missing proof leaves the process unstarted.
"""

from __future__ import annotations

import ast
import hashlib
import json
import os
import re
import selectors
import shlex
import shutil
import stat
import subprocess
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable

from agent_lifecycle.accounting.input_fit import assess_local_input_fit
from agent_lifecycle.accounting.contracts import digest as accounting_digest, utc_instant
from agent_lifecycle.context import render_context
from agent_lifecycle.contracts import LifecycleError, canonical_bytes, canonical_digest, read_json_object
from agent_lifecycle.contracts.authority_io import read_authority_bytes
from agent_lifecycle.contracts.process_execution_schemas import command_identity_hash

ROUTE_ID = "codex-exact-prompt-v1"
CLAIM = "ALK_CONTROLLED_OUTBOUND_INPUT_FIT"
_PART = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
_MAX_REQUEST_BYTES = 131_072
_STRUCTURED_REVIEW_INSTRUCTION = (
    "ALK_ROUTE_BOOTSTRAP_REVIEW_V3. Return only one JSON object matching outputSchema. "
    "Use the exact assignedSubject below. A PASS is allowed only when reviewText is "
    "NO_CURRENT_FINDINGS with at most one terminal newline; then findings is empty. "
    "Otherwise use FAIL and map every current - [P1], - [P2] or - [P3] line "
    "one-to-one to an OPEN HIGH, MEDIUM or LOW finding with the exact line SHA-256. "
    "Never convert other prose to PASS, close a current finding, or alter the subject.\n"
)


def _part(value: Any, label: str) -> str:
    if not isinstance(value, str) or _PART.fullmatch(value) is None or value in {".", ".."}:
        raise LifecycleError("codex-exact-identity-invalid", f"{label} is not one path component")
    return value


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def assess_retention_pre_fixture(
    run_id: str, closed_run: dict[str, Any] | None, now_utc: str,
    *, reconciliation_clear: bool,
) -> dict[str, str]:
    """RB11-PRE only: inspect a verified Journal.closed_run fixture, never delete.

    The caller must separately establish journal/root authority and current
    exception state. Even DUE_PRE_ONLY is not permission to purge raw details.
    """
    result = {"caseId": "RB11-PRE", "runtimeStatus": "NOT_RUN"}
    try:
        _part(run_id, "runId")
        now = utc_instant(now_utc)
        if closed_run is None:
            return {**result, "status": "OPEN_NO_PURGE_CLOCK"}
        if type(reconciliation_clear) is not bool or not isinstance(closed_run, dict):
            raise ValueError("verified closure or exception state unavailable")
        if set(closed_run) != {"closure", "summary", "summary_digest", "eligible_after"}:
            raise ValueError("closed-run fixture incomplete")
        closure = closed_run["closure"]
        summary = closed_run["summary"]
        if not isinstance(closure, dict) or not isinstance(summary, dict):
            raise ValueError("closed-run fixture malformed")
        if closure.get("run_id") != run_id:
            raise ValueError("closure belongs to another run")
        _part(closure.get("closure_id"), "closureId")
        closed_at = utc_instant(closure.get("closed_at_utc"))
        eligible_after = utc_instant(closed_run["eligible_after"])
        if closed_at > now or eligible_after != closed_at + timedelta(days=30):
            raise ValueError("30-day clock does not match verified closure")
        if closed_run["summary_digest"] != accounting_digest(summary):
            raise ValueError("closure summary digest mismatch")
        scopes = closure.get("scope_revisions")
        actual = summary.get("scopes")
        if not isinstance(scopes, list) or not scopes or not isinstance(actual, dict):
            raise ValueError("full-run scope inventory missing")
        names: list[str] = []
        for row in scopes:
            if not isinstance(row, list) or len(row) != 2:
                raise ValueError("invalid scope revision")
            name, revision = row
            _part(name, "scope")
            if type(revision) is not int or revision < 0 or not isinstance(actual.get(name), dict):
                raise ValueError("invalid scope revision")
            if actual[name].get("revision") != revision + 1:
                raise ValueError("closed scope revision mismatch")
            names.append(name)
        if names != sorted(set(names)) or set(actual) != set(names):
            raise ValueError("incomplete full-run scope inventory")
        if not reconciliation_clear:
            raise ValueError("financial reconciliation remains open")
        return {**result, "status": "DUE_PRE_ONLY" if now >= eligible_after else "NOT_DUE_PRE_ONLY"}
    except (ValueError, TypeError, LifecycleError, OverflowError):
        return {**result, "status": "REFUSED_PRE_ONLY"}


def _file_sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1_048_576), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _private_dir(path: Path, *, boundary: Path) -> None:
    if path == boundary:
        return
    _private_dir(path.parent, boundary=boundary)
    try:
        path.mkdir(mode=0o700)
    except FileExistsError:
        pass
    info = path.lstat()
    relative = path.relative_to(boundary).parts
    shared_parent = relative in {("work",), ("work", "release-2-16"),
                                 ("work", "release-2-16", "evidence")}
    if not stat.S_ISDIR(info.st_mode) or (not shared_parent and stat.S_IMODE(info.st_mode) != 0o700):
        raise LifecycleError("codex-exact-private-path-unsafe", "private directory is not mode 0700")


def _verify_private_ancestors(path: Path, *, root: Path) -> None:
    """Refuse an existing snapshot reached through a symlink or open parent."""
    _require(path.is_relative_to(root) and path != root,
             "codex-exact-private-path-unsafe", "private path lies outside root")
    current = path.parent
    while current != root:
        info = current.lstat()
        relative = current.relative_to(root).parts
        shared = relative in {("work",), ("work", "release-2-16"),
                              ("work", "release-2-16", "evidence")}
        _require(stat.S_ISDIR(info.st_mode)
                 and (shared or stat.S_IMODE(info.st_mode) == 0o700),
                 "codex-exact-private-path-unsafe", "snapshot ancestor is unsafe")
        current = current.parent


def _write_exclusive(path: Path, raw: bytes, *, root: Path) -> None:
    if len(raw) > _MAX_REQUEST_BYTES:
        raise LifecycleError("codex-exact-private-overflow", "private artifact exceeds byte limit")
    _private_dir(path.parent, boundary=root)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    flags |= getattr(os, "O_NOFOLLOW", 0)
    try:
        fd = os.open(path, flags, 0o600)
    except OSError as exc:
        raise LifecycleError("codex-exact-private-create-failed", "private artifact cannot be created") from exc
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
    except BaseException:
        path.unlink(missing_ok=True)
        raise


def _read_private(path: Path, *, root: Path) -> bytes:
    if not path.is_relative_to(root):
        raise LifecycleError("codex-exact-private-path-unsafe", "private artifact lies outside root")
    current = path.parent
    while current != root:
        info = current.lstat()
        relative = current.relative_to(root).parts
        shared_parent = relative in {("work",), ("work", "release-2-16"),
                                     ("work", "release-2-16", "evidence")}
        if not stat.S_ISDIR(info.st_mode) or (not shared_parent and stat.S_IMODE(info.st_mode) != 0o700):
            raise LifecycleError("codex-exact-private-path-unsafe", "private parent is not mode 0700")
        current = current.parent
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode) != 0o600 or info.st_size > _MAX_REQUEST_BYTES:
        raise LifecycleError("codex-exact-private-path-unsafe", "private file is not bounded mode 0600")
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags)
    with os.fdopen(fd, "rb") as stream:
        raw = stream.read(_MAX_REQUEST_BYTES + 1)
    if len(raw) > _MAX_REQUEST_BYTES:
        raise LifecycleError("codex-exact-private-overflow", "private artifact exceeds byte limit")
    return raw


def stage_input_request(project_root: Path, request_id: str, request: dict[str, Any]) -> Path:
    """Create a caller-supplied private source; never infer route or prompt."""
    root = Path(project_root).absolute()
    request_id = _part(request_id, "requestId")
    if not isinstance(request, dict) or "attemptId" in request:
        raise LifecycleError("codex-exact-request-invalid", "caller request must precede attempt binding")
    path = root / "work/release-2-16/private-details/codex-exact-prompt/staging" / request_id / "input-request.json"
    _write_exclusive(path, canonical_bytes(request), root=root)
    return path


def _seal_request(root: Path, source: Path, run_id: str, task_id: str, attempt_id: str) -> tuple[Path, dict[str, Any]]:
    staging = root / "work/release-2-16/private-details/codex-exact-prompt/staging"
    source = Path(source).absolute()
    if source.name != "input-request.json" or source.parent.parent != staging:
        raise LifecycleError("codex-exact-request-source-invalid", "request is not an ALK staging artifact")
    _part(source.parent.name, "requestId")
    raw = _read_private(source, root=root)
    try:
        request = json.loads(raw)
    except (ValueError, UnicodeDecodeError) as exc:
        raise LifecycleError("codex-exact-request-invalid", "private request is not JSON") from exc
    if not isinstance(request, dict) or "attemptId" in request:
        raise LifecycleError("codex-exact-request-invalid", "private request has invalid attempt binding")
    request = {**request, "attemptId": attempt_id}
    sealed = root / "work/release-2-16/private-details/codex-exact-prompt" / run_id / task_id / attempt_id / "input-request.json"
    _write_exclusive(sealed, canonical_bytes(request), root=root)
    try:
        source.unlink()
        source.parent.rmdir()
    except OSError as exc:
        _cleanup_sealed_no_start(root, sealed, source, run_id, task_id, attempt_id)
        raise LifecycleError("codex-exact-request-staging-finalize-failed", "staging directory could not be finalized") from exc
    return sealed, request


def _cleanup_marker(root: Path, path: Path) -> tuple[Path, dict[str, str]]:
    private = root / "work/release-2-16/private-details/codex-exact-prompt"
    relative = path.relative_to(private).parts
    evidence = root / "work/release-2-16/evidence/codex-exact-prompt"
    if len(relative) == 3 and relative[0] == "staging" and relative[2] == "input-request.json":
        request_id = _part(relative[1], "requestId")
        return (evidence / "prestart" / request_id / "raw-cleanup-pending.json",
                {"requestId": request_id})
    if len(relative) == 4 and relative[3] == "input-request.json":
        run_id, task_id, attempt_id = (_part(value, "cleanupIdentity") for value in relative[:3])
        return (evidence / run_id / task_id / attempt_id / "raw-cleanup-pending.json",
                {"runId": run_id, "taskId": task_id, "attemptId": attempt_id})
    raise LifecycleError("codex-exact-private-path-unsafe", "cleanup target is not an ALK input request")


def _record_cleanup_pending(root: Path, path: Path) -> None:
    marker, identity = _cleanup_marker(root, path)
    record = {"schemaVersion": "alk-codex-raw-cleanup-pending.v1",
              "status": "PRIVATE_CLEANUP_PENDING", **identity,
              "rawPathSha256": _sha(os.fsencode(str(path)))}
    if marker.exists():
        previous = json.loads(_read_private(marker, root=root))
        _require(previous == record, "codex-exact-private-cleanup-pending",
                 "cleanup marker differs from the pending raw path")
        return
    _write_exclusive(marker, canonical_bytes(record), root=root)


def _finish_cleanup_marker(root: Path, path: Path) -> None:
    marker, identity = _cleanup_marker(root, path)
    if not marker.exists():
        return
    previous = json.loads(_read_private(marker, root=root))
    _require(previous.get("status") in {"PRIVATE_CLEANUP_PENDING", "DONE"}
             and all(previous.get(key) == value for key, value in identity.items())
             and previous.get("rawPathSha256") == _sha(os.fsencode(str(path))),
             "codex-exact-private-cleanup-pending", "cleanup marker identity differs")
    if previous["status"] == "DONE":
        return
    temporary = marker.with_name(marker.name + ".tmp")
    _write_exclusive(temporary, canonical_bytes({**previous, "status": "DONE"}), root=root)
    os.replace(temporary, marker)


def _complete_started_input(root: Path, evidence: Path, intent: dict[str, Any]) -> bool:
    """A start alone never resolves the reserved OS-pipe receipt."""
    try:
        start_raw = _read_private(evidence / "process-start.json", root=root)
        input_raw = _read_private(evidence / "process-input.json", root=root)
        transport_raw = _read_private(evidence / "transport-equivalence.json", root=root)
        start = json.loads(start_raw)
        observed_input = json.loads(input_raw)
        transport = json.loads(transport_raw)
    except (OSError, ValueError, UnicodeDecodeError, LifecycleError):
        return False
    if not all(isinstance(item, dict) for item in (start, observed_input, transport)):
        return False
    identity = ("runId", "taskId", "attemptId", "finalPromptSha256")
    return (
        start.get("schemaVersion") == "alk-codex-process-start.v1"
        and start.get("hostLaunchStarted") is True
        and start.get("stdinStatus") == "PENDING"
        and observed_input.get("schemaVersion") == "alk-codex-process-input.v1"
        and transport.get("schemaVersion") == "alk-codex-os-pipe-transport.v1"
        and transport.get("status") == "OS_PIPE_ACCEPTED"
        and observed_input.get("status") == "COMPLETE"
        and observed_input.get("closeSucceeded") is True
        and type(intent.get("plannedStdinBytes")) is int
        and observed_input.get("acceptedBytes") == intent["plannedStdinBytes"]
        and observed_input.get("acceptedSha256") == intent.get("finalPromptSha256")
        and all(start.get(key) == intent.get(key)
                and observed_input.get(key) == intent.get(key)
                and transport.get(key) == intent.get(key) for key in identity)
        and transport.get("processStartSha256") == _sha(start_raw)
        and transport.get("processInputSha256") == _sha(input_raw)
    )


def _assert_no_cleanup_blockers(root: Path) -> None:
    evidence = root / "work/release-2-16/evidence/codex-exact-prompt"
    if not evidence.exists():
        return
    for marker in evidence.rglob("raw-cleanup-pending.json"):
        try:
            record = json.loads(_read_private(marker, root=root))
        except (ValueError, UnicodeDecodeError) as exc:
            raise LifecycleError("codex-exact-private-cleanup-pending",
                                 "a raw cleanup marker is incomplete") from exc
        _require(record.get("status") in {"DONE", "PENDING"},
                 "codex-exact-private-cleanup-pending", "a previous raw cleanup remains unresolved")
        if record["status"] == "PENDING":
            start = marker.with_name("process-start.json")
            intent_path = marker.with_name("prelaunch-intent.json")
            try:
                observed = json.loads(_read_private(start, root=root))
                intent = json.loads(_read_private(intent_path, root=root))
            except (OSError, ValueError, UnicodeDecodeError, LifecycleError) as exc:
                raise LifecycleError("codex-exact-start-uncertain",
                                     "pending raw details have no verified child start") from exc
            _require(observed.get("schemaVersion") == "alk-codex-process-start.v1"
                     and observed.get("hostLaunchStarted") is True
                     and all(observed.get(key) == record.get(key)
                             for key in ("runId", "taskId", "attemptId")),
                     "codex-exact-start-uncertain", "pending raw details differ from child start")
            _require(_complete_started_input(root, marker.parent, intent),
                     "codex-exact-start-uncertain", "pending raw details lack a completed pipe receipt")


def _record_orphan_private_input(root: Path, path: Path, marker: Path) -> None:
    record = {"schemaVersion": "alk-codex-orphan-private-input.v1",
              "status": "START_UNCERTAIN", "costStatus": "UNAVAILABLE",
              "rawPathSha256": _sha(os.fsencode(str(path)))}
    if marker.exists():
        _require(json.loads(_read_private(marker, root=root)) == record,
                 "codex-exact-start-uncertain", "orphan private input marker differs")
    else:
        _write_exclusive(marker, canonical_bytes(record), root=root)
    raise LifecycleError("codex-exact-start-uncertain",
                         "an orphan private input needs reconciliation before another attempt")


def reconcile_prelaunch_intents(
    project_root: Path, *, active_staging_request: Path | None = None,
) -> None:
    """Reconcile intents and raw requests before a new child can start."""
    root = Path(project_root).absolute()
    evidence = root / "work/release-2-16/evidence/codex-exact-prompt"
    private = root / "work/release-2-16/private-details/codex-exact-prompt"
    active = (_staging_request(root, active_staging_request)
              if active_staging_request is not None else None)
    if evidence.exists():
        for pattern in ("start-uncertain.json", "orphan-private-input.json"):
            for marker in evidence.rglob(pattern):
                _read_private(marker, root=root)
                raise LifecycleError("codex-exact-start-uncertain",
                                     "a previous uncertain start or orphan input remains unresolved")
    if private.exists():
        _require(stat.S_ISDIR(private.lstat().st_mode),
                 "codex-exact-private-path-unsafe", "private input root is unsafe")
        for path in sorted(private.rglob("input-request.json")):
            relative = path.relative_to(private).parts
            if len(relative) == 3 and relative[0] == "staging":
                request_id = _part(relative[1], "requestId")
                if path == active:
                    _read_private(path, root=root)
                    continue
                cleanup_marker = (evidence / "prestart" / request_id
                                  / "raw-cleanup-pending.json")
                if cleanup_marker.exists():
                    pending = json.loads(_read_private(cleanup_marker, root=root))
                    if pending.get("status") == "PRIVATE_CLEANUP_PENDING":
                        continue  # The existing sticky privacy blocker has priority.
                _record_orphan_private_input(
                    root, path, evidence / "prestart" / request_id / "orphan-private-input.json")
            _require(len(relative) == 4 and relative[3] == "input-request.json",
                     "codex-exact-private-path-unsafe", "private input has an unexpected path")
            run_id, task_id, attempt_id = (_part(value, "orphanIdentity") for value in relative[:3])
            attempt_evidence = evidence / run_id / task_id / attempt_id
            if not (attempt_evidence / "prelaunch-intent.json").exists():
                cleanup_marker = attempt_evidence / "raw-cleanup-pending.json"
                if cleanup_marker.exists():
                    pending = json.loads(_read_private(cleanup_marker, root=root))
                    if pending.get("status") == "PRIVATE_CLEANUP_PENDING":
                        continue  # Preserve the more specific existing blocker.
                _record_orphan_private_input(
                    root, path, attempt_evidence / "orphan-private-input.json")
    if not evidence.exists():
        return
    for path in evidence.rglob("prelaunch-intent.json"):
        raw = _read_private(path, root=root)
        try:
            intent = json.loads(raw)
        except (ValueError, UnicodeDecodeError) as exc:
            raise LifecycleError("codex-exact-start-uncertain", "prelaunch intent is unreadable") from exc
        _require(isinstance(intent, dict) and intent.get("schemaVersion") == "alk-codex-prelaunch-intent.v1"
                 and intent.get("hostLaunchStarted") is False,
                 "codex-exact-start-uncertain", "prelaunch intent cannot establish no-start")
        resolved = _complete_started_input(root, path.parent, intent)
        if not resolved:
            no_start = path.with_name("proven-no-start.json")
            if no_start.exists():
                try:
                    record = json.loads(_read_private(no_start, root=root))
                    resolved = (record.get("schemaVersion") == "alk-codex-proven-no-start.v1"
                                and record.get("status") == "PROVEN_NO_START"
                                and record.get("prelaunchIntentSha256") == _sha(raw)
                                and path.with_name("process-start.json").exists()
                                and path.with_name("process-start.json").stat().st_size == 0
                                and (not path.with_name("process-input.json").exists()
                                     or path.with_name("process-input.json").stat().st_size == 0))
                except (OSError, ValueError, UnicodeDecodeError, LifecycleError):
                    resolved = False
        if resolved:
            continue
        marker = path.with_name("start-uncertain.json")
        record = {"schemaVersion": "alk-codex-start-uncertain.v1", "status": "START_UNCERTAIN",
                  "runId": intent.get("runId"), "taskId": intent.get("taskId"),
                  "attemptId": intent.get("attemptId"), "prelaunchIntentSha256": _sha(raw),
                  "costStatus": "UNAVAILABLE"}
        if marker.exists():
            _require(json.loads(_read_private(marker, root=root)) == record,
                     "codex-exact-start-uncertain", "uncertain-start marker differs")
        else:
            _write_exclusive(marker, canonical_bytes(record), root=root)
        raise LifecycleError("codex-exact-start-uncertain", "a prior possible child start needs reconciliation")


def record_proven_no_start(project_root: Path, start_receipt_path: Path) -> None:
    """Resolve a reserved intent only after the runner reports no Popen success."""
    root = Path(project_root).absolute()
    start = Path(start_receipt_path).absolute()
    intent = start.with_name("prelaunch-intent.json")
    _require(start.name == "process-start.json" and intent.is_relative_to(
        root / "work/release-2-16/evidence/codex-exact-prompt"),
        "codex-exact-start-uncertain", "no-start receipt has an invalid path")
    raw = _read_private(intent, root=root)
    _require(start.stat().st_size == 0, "codex-exact-start-uncertain",
             "observed start cannot be resolved as no-start")
    record = {"schemaVersion": "alk-codex-proven-no-start.v1", "status": "PROVEN_NO_START",
              "prelaunchIntentSha256": _sha(raw), "costStatus": "NOT_STARTED"}
    _write_exclusive(start.with_name("proven-no-start.json"), canonical_bytes(record), root=root)


def _staging_request(root: Path, source: Path) -> Path:
    staging = root / "work/release-2-16/private-details/codex-exact-prompt/staging"
    path = Path(source).absolute()
    _require(path.name == "input-request.json" and path.parent.parent == staging,
             "codex-exact-private-path-unsafe", "cleanup target is not an ALK staged request")
    _part(path.parent.name, "requestId")
    return path


def _cleanup_input_paths(root: Path, *paths: Path) -> None:
    failed = False
    for path in paths:
        try:
            if path.exists() or path.is_symlink():
                _read_private(path, root=root)
            path.unlink(missing_ok=True)
            _finish_cleanup_marker(root, path)
        except (OSError, LifecycleError):
            _record_cleanup_pending(root, path)
            failed = True
    if failed:
        raise LifecycleError("codex-exact-private-cleanup-pending", "raw request cleanup failed; durable privacy blocker retained")


def _cleanup_sealed_no_start(
    root: Path, sealed: Path, source: Path, run_id: str, task_id: str, attempt_id: str,
) -> None:
    """Only the sealing transaction may remove its newly created attempt copy."""
    source = _staging_request(root, source)
    expected = (root / "work/release-2-16/private-details/codex-exact-prompt"
                / run_id / task_id / attempt_id / "input-request.json")
    _require(Path(sealed).absolute() == expected,
             "codex-exact-private-path-unsafe", "sealed cleanup identity differs")
    start = (root / "work/release-2-16/evidence/codex-exact-prompt"
             / run_id / task_id / attempt_id / "process-start.json")
    _require(not start.exists() or start.stat().st_size == 0,
             "codex-exact-start-uncertain", "observed child start forbids sealed cleanup")
    _cleanup_input_paths(root, expected, source)


def cleanup_no_start(project_root: Path, sealed: Path | None, source: Path | None) -> None:
    """Remove only a caller-supplied ALK staging request on a no-start return."""
    root = Path(project_root).absolute()
    _require(sealed is None, "codex-exact-private-path-unsafe",
             "public no-start cleanup cannot remove a sealed attempt request")
    if source is not None:
        _cleanup_input_paths(root, _staging_request(root, source))


def _require(value: bool, code: str, message: str) -> None:
    if not value:
        raise LifecycleError(code, message)


def _snapshot_digest(snapshot: Path, *, root: Path) -> str:
    _verify_private_ancestors(snapshot, root=root)
    info = snapshot.lstat()
    _require(stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode) == 0o700,
             "codex-exact-config-unsafe", "private CODEX_HOME is not protected")
    rows: list[dict[str, Any]] = []
    total = 0
    for path in sorted(snapshot.rglob("*")):
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            _require(stat.S_IMODE(info.st_mode) == 0o700,
                     "codex-exact-config-unsafe", "snapshot directory mode is unsafe")
            continue
        _require(stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode) in {0o400, 0o600},
                 "codex-exact-config-unsafe", "snapshot has unsafe file or symlink")
        total += info.st_size
        _require(len(rows) < 128 and total <= 8_388_608,
                 "codex-exact-config-overflow", "snapshot exceeds inventory limit")
        data = path.read_bytes()
        rows.append({"path":path.relative_to(snapshot).as_posix(), "sha256":_sha(data),
                     "bytes":len(data), "mode":stat.S_IMODE(info.st_mode)})
    return canonical_digest(rows)


def _snapshot_raw_sources(root: Path, snapshot: Path) -> list[dict[str, Any]]:
    """Inventory the whole child CODEX_HOME tree and every prestart file."""
    info = snapshot.lstat()
    _require(stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode) == 0o700,
             "codex-exact-config-unsafe", "private CODEX_HOME is not protected")
    tree_digest = _snapshot_digest(snapshot, root=root)
    sources: list[dict[str, Any]] = []
    total = 0
    for path in sorted(snapshot.rglob("*")):
        file_info = path.lstat()
        if stat.S_ISDIR(file_info.st_mode):
            continue
        _require(stat.S_ISREG(file_info.st_mode)
                 and stat.S_IMODE(file_info.st_mode) in {0o400, 0o600},
                 "codex-exact-config-unsafe", "snapshot contains an unsafe raw file")
        raw = path.read_bytes()
        _require(len(raw) == file_info.st_size,
                 "codex-exact-raw-inventory-invalid", "snapshot file changed during inventory")
        total += len(raw)
        sources.append({"kind": "codex-home-snapshot-file",
                        "path": str(path.relative_to(root)),
                        "pathSha256": _sha(os.fsencode(str(path))),
                        "fileIdentity": {"device": file_info.st_dev, "inode": file_info.st_ino},
                        "sha256": _sha(raw), "bytes": len(raw),
                        "mode": stat.S_IMODE(file_info.st_mode)})
    _require(_snapshot_digest(snapshot, root=root) == tree_digest,
             "codex-exact-raw-inventory-invalid", "snapshot changed during inventory")
    return [{"kind": "codex-home-snapshot-tree",
             "path": str(snapshot.relative_to(root)),
             "pathSha256": _sha(os.fsencode(str(snapshot))),
             "fileIdentity": {"device": info.st_dev, "inode": info.st_ino},
             "sha256": tree_digest, "bytes": total,
             "cleanupScope": "WHOLE_TREE_INCLUDING_POST_START_ADDITIONS"}, *sources]


def _remove_snapshot_no_start(snapshot: Path, *, root: Path) -> None:
    """Remove a known unstarted snapshot without following links or unknown types."""
    if not snapshot.exists() and not snapshot.is_symlink():
        return
    _verify_private_ancestors(snapshot, root=root)
    info = snapshot.lstat()
    _require(stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode) == 0o700,
             "codex-exact-private-path-unsafe", "snapshot cleanup root is unsafe")
    entries = sorted(snapshot.rglob("*"), key=lambda path: len(path.parts), reverse=True)
    for path in entries:
        item = path.lstat()
        _require((stat.S_ISDIR(item.st_mode) and stat.S_IMODE(item.st_mode) == 0o700)
                 or (stat.S_ISREG(item.st_mode) and stat.S_IMODE(item.st_mode) in {0o400, 0o600}),
                 "codex-exact-private-path-unsafe", "snapshot cleanup contains an unsafe entry")
    for path in entries:
        if stat.S_ISDIR(path.lstat().st_mode):
            path.rmdir()
        else:
            path.unlink()
    snapshot.rmdir()


def _bounded_codex_debug_output(
    binary: Path, args: tuple[str, ...], *, root: Path,
    process_env: dict[str, str], limit: int,
) -> bytes:
    """Run a local no-model diagnostic with a wall-clock and output bound."""
    process = None
    selector = selectors.DefaultSelector()
    try:
        process = subprocess.Popen(
            [str(binary), *args], cwd=root, env=process_env,
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
        assert process.stdout is not None
        selector.register(process.stdout, selectors.EVENT_READ)
        deadline = time.monotonic() + 15.0
        chunks: list[bytes] = []
        total = 0
        while True:
            ready = selector.select(max(0.0, deadline - time.monotonic()))
            _require(bool(ready), "codex-exact-catalog-unavailable", "selected binary diagnostic timed out")
            chunk = os.read(process.stdout.fileno(), 65_536)
            if not chunk:
                break
            total += len(chunk)
            _require(total <= limit, "codex-exact-catalog-overflow", "selected binary diagnostic is oversized")
            chunks.append(chunk)
        remaining = max(0.0, deadline - time.monotonic())
        _require(process.wait(timeout=remaining) == 0,
                 "codex-exact-catalog-unavailable", "selected binary diagnostic failed")
        return b"".join(chunks)
    except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
        raise LifecycleError("codex-exact-catalog-unavailable",
                             "selected binary diagnostic could not complete") from exc
    finally:
        selector.close()
        if process is not None:
            if process.poll() is None:
                process.terminate()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=2)
            if process.stdout is not None:
                process.stdout.close()


def _selected_binary_path(
    executable: str, identity: dict[str, Any], process_env: dict[str, str],
) -> Path:
    """Resolve and rehash the exact executable selected by launch preflight."""
    candidate = (Path(executable) if Path(executable).is_absolute()
                 else Path(shutil.which(executable, path=process_env.get("PATH", "")) or ""))
    _require(candidate.is_file(),
             "codex-exact-binary-unavailable", "selected binary path is unavailable")
    binary = candidate.resolve(strict=True)
    binary_sha = _file_sha(binary)
    _require(identity.get("status") == "PASS"
             and identity.get("resolvedPathSha256") == _sha(os.fsencode(str(binary)))
             and identity.get("executableContentSha256") == binary_sha,
             "codex-exact-binary-mismatch", "binary differs from selected executable")
    return binary


def _observed_bundled_catalog(
    root: Path, executable: str, identity: dict[str, Any], model: str,
    process_env: dict[str, str],
) -> dict[str, Any]:
    """Bind a bundled catalog candidate to the exact selected binary."""
    binary = _selected_binary_path(executable, identity, process_env)
    binary_sha = identity["executableContentSha256"]
    version_raw = _bounded_codex_debug_output(
        binary, ("--version",), root=root, process_env=process_env, limit=1024)
    catalog_raw = _bounded_codex_debug_output(
        binary, ("debug", "models", "--bundled"), root=root,
        process_env=process_env, limit=1_048_576)
    _require(_file_sha(binary) == binary_sha,
             "codex-exact-binary-mismatch", "catalog binary changed during diagnostic")
    try:
        version = version_raw.decode("utf-8").strip()
        catalog = json.loads(catalog_raw)
    except (UnicodeDecodeError, ValueError) as exc:
        raise LifecycleError("codex-exact-catalog-unavailable",
                             "selected binary catalog is malformed") from exc
    _require(bool(version) and len(version) <= 256 and isinstance(catalog, dict)
             and isinstance(catalog.get("models"), list),
             "codex-exact-catalog-unavailable", "selected binary catalog is incomplete")
    selected = [row for row in catalog["models"]
                if isinstance(row, dict) and row.get("slug") == model]
    _require(len(selected) == 1, "codex-exact-model-unavailable",
             "selected model is absent or ambiguous in the bundled catalog")
    row = selected[0]
    window = row.get("context_window")
    _require(type(window) is int and window >= 16_384,
             "codex-exact-window-unavailable", "bundled catalog has no usable 16k window")
    return {"source": "SELECTED_BINARY_BUNDLED_CATALOG_CANDIDATE",
            "binarySha256": binary_sha, "version": version,
            "catalogSha256": _sha(catalog_raw), "model": model,
            "modelEntryDigest": canonical_digest(row),
            "catalogWindowTokens": window, "actualChildWindow": "UNPROVEN"}


def _recheck_alk_fit_sources(
    root: Path, request: dict[str, Any], packet_rel: str, packet_sha: str,
    contract_sha: str, profile_sha: str, plan_digest: str, task_id: str,
    selection: dict[str, Any], summary: dict[str, Any],
    binding: dict[str, Any], fit_digest: str,
) -> None:
    """Reopen every mutable ALK fit source at the last no-start boundary."""
    packet_raw = read_authority_bytes(root / packet_rel, root=root, max_bytes=65_536)
    contract_raw = read_authority_bytes(
        root / "tasks/release-2-16/alk-input-fit-contract.json", root=root,
        max_bytes=1_048_576)
    profile_raw = read_authority_bytes(
        root / "profiles/small-context-profile.v1.json", root=root,
        max_bytes=65_536)
    _require(_sha(packet_raw) == packet_sha and _sha(contract_raw) == contract_sha
             and _sha(profile_raw) == profile_sha,
             "codex-exact-fit-source-stale", "packet, fit contract or profile changed before start")
    try:
        packet = json.loads(packet_raw)
        contract = json.loads(contract_raw)
        profile = json.loads(profile_raw)
    except (ValueError, UnicodeDecodeError) as exc:
        raise LifecycleError("codex-exact-fit-source-stale", "ALK fit source is malformed") from exc
    _require(packet.get("plan", {}).get("planDigest") == plan_digest
             and packet.get("task", {}).get("id") == task_id
             and contract.get("commonEnvelope", {}).get("reservedOutputEstimatedTokens") == 3072,
             "codex-exact-fit-source-stale", "packet lineage or output reserve changed")
    fresh = assess_local_input_fit(
        root, contract, profile, packet, summary, selection,
        role=str(request.get("role")), host_adapter_id="codex",
        host_version=str(request.get("hostVersion", "")), host_mode=str(request.get("hostMode", "")),
        estimator_id=str(request.get("estimatorId", "")), instruction=request.get("instruction"),
        schema=request.get("schema"), current_binding=binding,
        latest_user=str(request.get("latestUser", "")), window="16k",
    )
    _require(fresh["status"] == "PASS_ALK_COMPONENTS_ONLY"
             and fresh["receiptDigest"] == fit_digest,
             "codex-exact-fit-source-stale", "selected source or output plan changed before start")


def _require_fresh_catalog(
    root: Path, executable: str, identity: dict[str, Any], model: str,
    process_env: dict[str, str], expected: dict[str, Any],
) -> None:
    _require(_observed_bundled_catalog(root, executable, identity, model, process_env) == expected,
             "codex-exact-catalog-stale", "selected binary catalog changed before start")


def _require_current_manifest(
    root: Path, manifest_path: Path | None, captured: dict[str, Any], plan_digest: str,
) -> None:
    """Reopen the authoritative manifest at the final process-start boundary."""
    _require(manifest_path is not None,
             "codex-exact-plan-stale", "manifest source is unavailable before start")
    try:
        current = json.loads(read_authority_bytes(
            manifest_path, root=root, max_bytes=1_048_576))
    except (ValueError, UnicodeDecodeError) as exc:
        raise LifecycleError("codex-exact-plan-stale", "manifest changed before start") from exc
    _require(isinstance(current, dict)
             and canonical_digest(current) == plan_digest
             and canonical_digest(captured) == plan_digest,
             "codex-exact-plan-stale", "manifest changed before start")


def _recheck_active_workflow_state(
    root: Path, state_path: Path | None, captured_state: dict[str, Any],
    run_id: str, task_id: str, attempt: int,
) -> None:
    """Reopen the authoritative task state at the last ALK pre-Popen boundary."""
    _require(state_path is not None, "codex-exact-state-stale",
             "authoritative workflow state path is missing")
    path = Path(state_path).absolute()
    _require(path.is_relative_to(root), "codex-exact-state-stale",
             "authoritative workflow state lies outside the project root")
    try:
        fresh = read_json_object(path, label="fresh workflow state")
    except (OSError, ValueError, LifecycleError) as exc:
        raise LifecycleError("codex-exact-state-stale",
                             "authoritative workflow state cannot be reopened") from exc
    tasks = fresh.get("tasks")
    active = ([task for task in tasks if isinstance(task, dict) and task.get("id") == task_id]
              if isinstance(tasks, list) else [])
    _require(fresh.get("runId") == run_id
             and canonical_digest(fresh) == canonical_digest(captured_state)
             and len(active) == 1
             and active[0].get("status") == "RUNNING"
             and active[0].get("attempt") == attempt,
             "codex-exact-state-stale", "task or attempt changed before child start")


def _observed_prompt_diagnostic(
    root: Path, executable: str, identity: dict[str, Any], *,
    snapshot: Path, model: str, role: str, run_id: str,
    task_id: str, attempt_id: str, final_sha: str,
    process_env: dict[str, str],
) -> dict[str, Any]:
    """Collect a private per-role candidate; never assert exec-stdin equivalence."""
    _require(role in {"worker", "validator", "auditor", "retry", "coordinator", "closing"},
             "codex-exact-role-unsupported", "diagnostic role is unsupported")
    _require(re.fullmatch(r"[0-9a-f]{64}", final_sha) is not None,
             "codex-exact-diagnostic-invalid", "final input digest is invalid")
    binary = _selected_binary_path(executable, identity, process_env)
    binary_sha = identity["executableContentSha256"]
    _require(snapshot.is_relative_to(root) and snapshot.is_dir()
             and stat.S_IMODE(snapshot.lstat().st_mode) == 0o700,
             "codex-exact-config-unsafe", "diagnostic CODEX_HOME is not protected")
    tag = (f"ALK_DIAGNOSTIC role={role} run={run_id} task={task_id} "
           f"attempt={attempt_id} inputSha256={final_sha}")
    environment = {**process_env, "CODEX_HOME": str(snapshot)}
    raw = _bounded_codex_debug_output(
        binary, ("debug", "prompt-input", tag), root=root,
        process_env=environment, limit=_MAX_REQUEST_BYTES)
    _require(_file_sha(binary) == binary_sha,
             "codex-exact-binary-mismatch", "diagnostic binary changed")
    try:
        items = json.loads(raw)
    except (ValueError, UnicodeDecodeError) as exc:
        raise LifecycleError("codex-exact-diagnostic-invalid",
                             "selected binary diagnostic is not JSON") from exc
    _require(isinstance(items, list) and 0 < len(items) <= 256
             and all(isinstance(item, dict) for item in items),
             "codex-exact-diagnostic-invalid", "selected binary diagnostic items are invalid")
    private = (root / "work/release-2-16/private-details/codex-exact-prompt"
               / run_id / task_id / attempt_id / "prompt-input.json")
    _write_exclusive(private, raw, root=root)
    return {"source": "SELECTED_BINARY_DEBUG_PROMPT_INPUT_CANDIDATE",
            "binarySha256": binary_sha, "model": model, "role": role,
            "safeTagSha256": _sha(tag.encode("utf-8")),
            "rawSha256": _sha(raw), "rawBytes": len(raw),
            "itemCount": len(items),
            "items": [{"index": index, "type": item.get("type"),
                       "role": item.get("role"),
                       "canonicalBytes": len(canonical_bytes(item)),
                       "canonicalSha256": _sha(canonical_bytes(item))}
                      for index, item in enumerate(items)],
            "execStdinEquivalence": "UNPROVEN"}


def _selected_host_evidence(root: Path, request: dict[str, Any], identity: dict[str, Any],
                            final_sha: str, run_id: str, task_id: str, attempt_id: str,
                            executable: str, process_env: dict[str, str],
                            role: str) -> tuple[str, str, str, dict[str, Any], dict[str, Any], str]:
    """Create ALK prelaunch sources without claiming child internal equivalence."""
    base = root / "work/release-2-16/evidence/codex-exact-prompt" / run_id / task_id / attempt_id
    private = root / "work/release-2-16/private-details/codex-exact-prompt" / run_id / task_id / attempt_id
    selected = request.get("selectedHost")
    _require(isinstance(selected, dict), "codex-exact-host-proof-missing", "selected host proof is missing")
    model = selected.get("model")
    _require(isinstance(model, str) and bool(model) and len(model) <= 128,
             "codex-exact-model-invalid", "selected model is invalid")
    _require(selected.get("binarySha256") == identity.get("executableContentSha256"),
             "codex-exact-binary-mismatch", "selected binary changed")
    catalog = _observed_bundled_catalog(root, executable, identity, model, process_env)
    if "catalogWindowTokens" in selected:
        _require(selected["catalogWindowTokens"] == catalog["catalogWindowTokens"],
                 "codex-exact-window-mismatch", "caller catalog hint differs from selected binary")
    _require(not any(key in selected for key in (
                 "configManifestSha256", "transportWitnessSha256", "diagnosticSha256")),
             "codex-exact-legacy-witness-refused", "caller-authored host PASS witnesses are not accepted")
    snapshot = root / "work/release-2-16/runtime-private/codex-exact-prompt" / run_id / task_id / attempt_id / "codex-home"
    _verify_private_ancestors(snapshot, root=root)
    info = snapshot.lstat()
    _require(stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode) == 0o700,
             "codex-exact-config-unsafe", "private CODEX_HOME is not protected")
    snapshot_digest = _snapshot_digest(snapshot, root=root)
    effective_config = private / "effective-config.json"
    source = {"schemaVersion": "alk-codex-alk-config-source.v1",
              "routeId": ROUTE_ID, "requestedClaim": CLAIM,
              "runId": run_id, "taskId": task_id, "attemptId": attempt_id,
              "role": role, "model": model, "finalPromptSha256": final_sha,
              "binarySha256": identity["executableContentSha256"],
              "selectedBinaryVersion": catalog["version"],
              "catalogSha256": catalog["catalogSha256"],
              "cwdPathSha256": _sha(os.fsencode(str(root))),
              "codexHomePathSha256": _sha(os.fsencode(str(snapshot))),
              "codexHomeContentDigest": snapshot_digest,
              "childInternalEffectiveConfig": "UNPROVEN"}
    _write_exclusive(effective_config, canonical_bytes(source), root=root)
    diagnostic = _observed_prompt_diagnostic(
        root, executable, identity, snapshot=snapshot, model=model, role=role,
        run_id=run_id, task_id=task_id, attempt_id=attempt_id,
        final_sha=final_sha, process_env=process_env)
    config_source = _raw_source_record(root, effective_config, "alk-config-source")
    manifest = {"schemaVersion": "alk-codex-config-source-manifest.v1",
                "status": "OBSERVED_ALK_SOURCE", "routeId": ROUTE_ID,
                "requestedClaim": CLAIM, "runId": run_id, "taskId": task_id,
                "attemptId": attempt_id, "role": role, "model": model,
                "finalPromptSha256": final_sha,
                "binarySha256": identity["executableContentSha256"],
                "selectedBinaryVersion": catalog["version"],
                "catalogObservation": catalog,
                "configSource": config_source,
                "diagnosticRawSha256": diagnostic["rawSha256"],
                "diagnosticItemCount": diagnostic["itemCount"],
                "childInternalEffectiveConfig": "UNPROVEN"}
    config_manifest = base / "config-snapshot-manifest.json"
    manifest_raw = canonical_bytes(manifest)
    _write_exclusive(config_manifest, manifest_raw, root=root)
    return model, str(snapshot), snapshot_digest, catalog, diagnostic, _sha(manifest_raw)


def _raw_source_record(root: Path, path: Path, kind: str) -> dict[str, Any]:
    raw = _read_private(path, root=root)
    info = path.lstat()
    _require(stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode) == 0o600
             and info.st_size == len(raw),
             "codex-exact-raw-inventory-invalid", "raw source changed during inventory")
    return {"kind": kind, "path": str(path.relative_to(root)),
            "pathSha256": _sha(os.fsencode(str(path))),
            "fileIdentity": {"device": info.st_dev, "inode": info.st_ino},
            "sha256": _sha(raw), "bytes": len(raw)}


def _record_transport_witness(
    root: Path, evidence: Path, *, run_id: str, task_id: str,
    attempt_id: str, role: str, final_sha: str,
    config_manifest_sha: str, diagnostic: dict[str, Any],
    event: dict[str, Any],
) -> None:
    """Join actual start and OS-pipe receipts without asserting consumption."""
    try:
        start_raw = _read_private(evidence / "process-start.json", root=root)
        input_raw = _read_private(evidence / "process-input.json", root=root)
    except OSError as exc:
        raise LifecycleError("codex-exact-process-join-invalid",
                             "observed process receipt is missing") from exc
    try:
        start = json.loads(start_raw)
        observed_input = json.loads(input_raw)
    except (ValueError, UnicodeDecodeError) as exc:
        raise LifecycleError("codex-exact-process-join-invalid",
                             "observed process receipt is malformed") from exc
    _require(start.get("schemaVersion") == "alk-codex-process-start.v1"
             and start.get("hostLaunchStarted") is True
             and start.get("stdinStatus") == "PENDING"
             and observed_input.get("schemaVersion") == "alk-codex-process-input.v1"
             and all(start.get(key) == value and observed_input.get(key) == value
                     for key, value in (("runId", run_id), ("taskId", task_id),
                                        ("attemptId", attempt_id), ("role", role)))
             and start.get("finalPromptSha256") == final_sha
             and observed_input.get("finalPromptSha256") == final_sha
             and all(observed_input.get(key) == value for key, value in event.items()),
             "codex-exact-process-join-invalid", "start/input receipt subject differs")
    transport = {"schemaVersion": "alk-codex-os-pipe-transport.v1",
                 "status": ("OS_PIPE_ACCEPTED" if event["status"] == "COMPLETE"
                            else "STARTED_INPUT_FAILURE"),
                 "runId": run_id, "taskId": task_id,
                 "attemptId": attempt_id, "role": role,
                 "routeId": ROUTE_ID, "requestedClaim": CLAIM,
                 "finalPromptSha256": final_sha,
                 "configManifestSha256": config_manifest_sha,
                 "diagnosticRawSha256": diagnostic["rawSha256"],
                 "diagnosticItemDigests": diagnostic["items"],
                 "processStartSha256": _sha(start_raw),
                 "processInputSha256": _sha(input_raw),
                 "observedPipe": event,
                 "childConsumption": "UNPROVEN",
                 "execStdinDiagnosticEquivalence": "UNPROVEN"}
    _write_exclusive(evidence / "transport-equivalence.json",
                     canonical_bytes(transport), root=root)


def _workflow_journal_identity(root: Path, state: dict[str, Any], run_id: str) -> dict[str, Any]:
    """Pin the PRE workflow event-log file identity, not a financial Journal grant."""
    event_log = state.get("eventLog")
    _require(state.get("runId") == run_id and isinstance(event_log, str)
             and bool(event_log) and not Path(event_log).is_absolute()
             and ".." not in Path(event_log).parts and bool(Path(event_log).parts),
             "codex-exact-journal-unavailable", "workflow event-log binding is missing")
    try:
        root_info = root.lstat()
        _require(stat.S_ISDIR(root_info.st_mode), "codex-exact-journal-unavailable",
                 "workflow root is not a directory")
        relative = Path(event_log)
        current = root
        for part in relative.parts[:-1]:
            current = current / part
            _require(stat.S_ISDIR(current.lstat().st_mode),
                     "codex-exact-journal-unavailable", "workflow event-log parent is unsafe")
        journal_info = (root / relative).lstat()
        _require(stat.S_ISREG(journal_info.st_mode), "codex-exact-journal-unavailable",
                 "workflow event log is not a regular file")
    except OSError as exc:
        raise LifecycleError("codex-exact-journal-unavailable",
                             "workflow event log cannot be inspected") from exc
    subject = {"kind": "WORKFLOW_EVENT_LOG_PRE_WS01", "runId": run_id,
               "rootPathSha256": _sha(os.fsencode(str(root))),
               "rootFileIdentity": {"device": root_info.st_dev, "inode": root_info.st_ino},
               "eventLog": relative.as_posix(),
               "eventLogFileIdentity": {"device": journal_info.st_dev, "inode": journal_info.st_ino}}
    return {**subject, "journalIdentity": canonical_digest(subject)}


def create_prestart_raw_inventory(
    project_root: Path, *, run_id: str, task_id: str, attempt_id: str,
    sealed_request: Path, state: dict[str, Any], plan_digest: str,
) -> tuple[Path, Path, str]:
    """Seal all known raw and the whole child snapshot cleanup obligation before Popen."""
    root = Path(project_root).absolute()
    run_id, task_id, attempt_id = (_part(value, "rawInventoryIdentity")
                                   for value in (run_id, task_id, attempt_id))
    journal = _workflow_journal_identity(root, state, run_id)
    private = root / "work/release-2-16/private-details/codex-exact-prompt" / run_id / task_id / attempt_id
    expected_request = private / "input-request.json"
    _require(Path(sealed_request).absolute() == expected_request,
             "codex-exact-raw-inventory-invalid", "sealed request identity differs")
    sources = [
        _raw_source_record(root, expected_request, "sealed-request"),
        _raw_source_record(root, private / "prompt-input.json", "diagnostic"),
        _raw_source_record(root, private / "effective-config.json", "effective-config"),
        *_snapshot_raw_sources(
            root, (root / "work/release-2-16/runtime-private/codex-exact-prompt"
                   / run_id / task_id / attempt_id / "codex-home")),
    ]
    inventory = {"schemaVersion": "alk-r68b-raw-inventory.v1", "runId": run_id,
                 "taskId": task_id, "attemptId": attempt_id, "planDigest": plan_digest,
                 "journalAuthorityKind": journal["kind"],
                 "journalIdentity": journal["journalIdentity"],
                 "eventLog": journal["eventLog"],
                 "eventLogFileIdentity": journal["eventLogFileIdentity"],
                 "rootPathSha256": journal["rootPathSha256"],
                 "rootFileIdentity": journal["rootFileIdentity"],
                 "workflowStateDigest": canonical_digest(state), "sources": sources}
    inventory_path = private / "raw-inventory.json"
    pending_path = (root / "work/release-2-16/evidence/codex-exact-prompt"
                    / run_id / task_id / attempt_id / "raw-cleanup-pending.json")
    _reserve(pending_path, root=root)
    _write_exclusive(inventory_path, canonical_bytes(inventory), root=root)
    inventory_sha = _sha(inventory_path.read_bytes())
    pending = {"schemaVersion": "alk-r68b-raw-cleanup-pending.v1", "status": "PENDING",
               "runId": run_id, "taskId": task_id, "attemptId": attempt_id,
               "journalIdentity": journal["journalIdentity"],
               "journalAuthorityKind": journal["kind"],
               "rootPathSha256": inventory["rootPathSha256"],
               "inventorySha256": inventory_sha}
    _replace_reserved(pending_path, pending, root=root)
    return inventory_path, pending_path, inventory_sha


def verify_prestart_raw_inventory(
    project_root: Path, *, inventory_path: Path, pending_path: Path,
    state: dict[str, Any], plan_digest: str,
) -> str:
    """Recheck inventory sources at the last ALK boundary before the runner."""
    root = Path(project_root).absolute()
    raw = _read_private(Path(inventory_path).absolute(), root=root)
    try:
        inventory = json.loads(raw)
        pending = json.loads(_read_private(Path(pending_path).absolute(), root=root))
    except (ValueError, UnicodeDecodeError) as exc:
        raise LifecycleError("codex-exact-raw-inventory-stale", "raw inventory is unreadable") from exc
    _require(isinstance(inventory, dict) and isinstance(pending, dict)
             and inventory.get("schemaVersion") == "alk-r68b-raw-inventory.v1"
             and pending.get("schemaVersion") == "alk-r68b-raw-cleanup-pending.v1"
             and pending.get("status") == "PENDING"
             and inventory.get("planDigest") == plan_digest
             and inventory.get("workflowStateDigest") == canonical_digest(state),
             "codex-exact-raw-inventory-stale", "raw inventory subject changed")
    run_id = _part(inventory.get("runId"), "rawInventoryRunId")
    task_id = _part(inventory.get("taskId"), "rawInventoryTaskId")
    attempt_id = _part(inventory.get("attemptId"), "rawInventoryAttemptId")
    private = (root / "work/release-2-16/private-details/codex-exact-prompt"
               / run_id / task_id / attempt_id)
    evidence = (root / "work/release-2-16/evidence/codex-exact-prompt"
                / run_id / task_id / attempt_id)
    _require(Path(inventory_path).absolute() == private / "raw-inventory.json"
             and Path(pending_path).absolute() == evidence / "raw-cleanup-pending.json",
             "codex-exact-raw-inventory-stale", "raw inventory paths changed")
    journal = _workflow_journal_identity(root, state, run_id)
    _require(inventory.get("journalAuthorityKind") == journal["kind"]
             and inventory.get("journalIdentity") == journal["journalIdentity"]
             and inventory.get("eventLogFileIdentity") == journal["eventLogFileIdentity"]
             and inventory.get("rootFileIdentity") == journal["rootFileIdentity"]
             and inventory.get("rootPathSha256") == journal["rootPathSha256"],
             "codex-exact-raw-inventory-stale", "workflow journal/root identity changed")
    expected = [
        _raw_source_record(root, private / "input-request.json", "sealed-request"),
        _raw_source_record(root, private / "prompt-input.json", "diagnostic"),
        _raw_source_record(root, private / "effective-config.json", "effective-config"),
        *_snapshot_raw_sources(
            root, (root / "work/release-2-16/runtime-private/codex-exact-prompt"
                   / run_id / task_id / attempt_id / "codex-home")),
    ]
    _require(inventory.get("sources") == expected
             and pending.get("inventorySha256") == _sha(raw)
             and pending.get("journalIdentity") == journal["journalIdentity"]
             and all(pending.get(key) == inventory.get(key)
                     for key in ("runId", "taskId", "attemptId", "rootPathSha256")),
             "codex-exact-raw-inventory-stale", "raw source bytes or pending obligation changed")
    return _sha(raw)


def cleanup_prestart_raw(
    project_root: Path, *, run_id: str, task_id: str, attempt_id: str,
    staging_source: Path | None, proven_no_start: bool,
) -> None:
    """Remove attempt raw only after an in-process, proven no-Popen outcome."""
    root = Path(project_root).absolute()
    _require(proven_no_start, "codex-exact-start-uncertain",
             "raw sources cannot be removed after a possible child start")
    run_id, task_id, attempt_id = (_part(value, "rawCleanupIdentity")
                                   for value in (run_id, task_id, attempt_id))
    evidence = (root / "work/release-2-16/evidence/codex-exact-prompt"
                / run_id / task_id / attempt_id)
    start = evidence / "process-start.json"
    _require(not start.exists() or start.stat().st_size == 0,
             "codex-exact-start-uncertain", "observed child start forbids no-start cleanup")
    private = (root / "work/release-2-16/private-details/codex-exact-prompt"
               / run_id / task_id / attempt_id)
    failed: list[str] = []
    for name in ("input-request.json", "prompt-input.json", "effective-config.json", "raw-inventory.json"):
        path = private / name
        try:
            if path.exists() or path.is_symlink():
                _read_private(path, root=root)
            path.unlink(missing_ok=True)
        except (OSError, LifecycleError):
            failed.append(_sha(os.fsencode(str(path))))
    snapshot = (root / "work/release-2-16/runtime-private/codex-exact-prompt"
                / run_id / task_id / attempt_id / "codex-home")
    try:
        _remove_snapshot_no_start(snapshot, root=root)
    except (OSError, LifecycleError):
        failed.append(_sha(os.fsencode(str(snapshot))))
    if staging_source is not None:
        try:
            cleanup_no_start(root, None, staging_source)
        except LifecycleError:
            failed.append(_sha(os.fsencode(str(Path(staging_source).absolute()))))
    marker = evidence / "raw-cleanup-pending.json"
    if marker.exists():
        raw = _read_private(marker, root=root)
        try:
            previous = json.loads(raw) if raw else {}
        except (ValueError, UnicodeDecodeError) as exc:
            raise LifecycleError("codex-exact-private-cleanup-pending",
                                 "raw cleanup marker is corrupt") from exc
    else:
        previous = {}
    _require(previous.get("status") in {None, "PENDING", "PRIVATE_CLEANUP_PENDING", "DONE"},
             "codex-exact-private-cleanup-pending", "raw cleanup marker state is invalid")
    record = {**previous, "schemaVersion": "alk-r68b-raw-cleanup-pending.v1",
              "status": "PRIVATE_CLEANUP_PENDING" if failed else "DONE",
              "runId": run_id, "taskId": task_id, "attemptId": attempt_id,
              "failedRawPathSha256": sorted(set(failed))}
    temporary = marker.with_name(marker.name + ".tmp")
    _write_exclusive(temporary, canonical_bytes(record), root=root)
    os.replace(temporary, marker)
    if failed:
        raise LifecycleError("codex-exact-private-cleanup-pending",
                             "raw cleanup failed; durable privacy blocker retained")


def _reserve(path: Path, *, root: Path) -> None:
    _write_exclusive(path, b"", root=root)


def _replace_reserved(path: Path, record: dict[str, Any], *, root: Path) -> None:
    _require(path.exists() and path.stat().st_size == 0,
             "codex-exact-receipt-reservation-lost", "reserved receipt changed")
    temporary = path.with_name(path.name + ".tmp")
    _write_exclusive(temporary, canonical_bytes(record), root=root)
    os.replace(temporary, path)


def _matches_closed_schema(value: Any, schema: dict[str, Any]) -> bool:
    """Validate the limited JSON Schema vocabulary frozen in the route contract."""
    allowed = {"type", "required", "properties", "additionalProperties", "const", "enum",
               "pattern", "minLength", "minimum", "maximum", "minProperties", "maxProperties",
               "minItems", "maxItems", "items", "anyOf", "format", "description"}
    if not isinstance(schema, dict) or not set(schema) <= allowed:
        return False
    if "anyOf" in schema and not any(_matches_closed_schema(value, option)
                                     for option in schema["anyOf"]):
        return False
    kind = schema.get("type")
    if kind is not None:
        checks = {"object": lambda: isinstance(value, dict),
                  "array": lambda: isinstance(value, list),
                  "string": lambda: isinstance(value, str),
                  "integer": lambda: type(value) is int,
                  "boolean": lambda: type(value) is bool,
                  "null": lambda: value is None}
        if kind not in checks or not checks[kind]():
            return False
    if "const" in schema and value != schema["const"]:
        return False
    if "enum" in schema and value not in schema["enum"]:
        return False
    if isinstance(value, dict):
        if not all(isinstance(key, str) for key in value):
            return False
        if not set(schema.get("required", [])) <= set(value):
            return False
        if len(value) < schema.get("minProperties", 0) or len(value) > schema.get("maxProperties", float("inf")):
            return False
        properties = schema.get("properties", {})
        extra = schema.get("additionalProperties", True)
        for key, item in value.items():
            rule = properties.get(key, extra)
            if rule is False or isinstance(rule, dict) and not _matches_closed_schema(item, rule):
                return False
    if isinstance(value, list):
        if len(value) < schema.get("minItems", 0) or len(value) > schema.get("maxItems", float("inf")):
            return False
        if "items" in schema and any(not _matches_closed_schema(item, schema["items"]) for item in value):
            return False
    if isinstance(value, str):
        if len(value) < schema.get("minLength", 0):
            return False
        if "pattern" in schema and re.fullmatch(schema["pattern"], value) is None:
            return False
        if schema.get("format") == "date-time":
            try:
                if datetime.fromisoformat(value.replace("Z", "+00:00")).tzinfo is None:
                    return False
            except ValueError:
                return False
        elif "format" in schema:
            return False
    if type(value) is int and (value < schema.get("minimum", -float("inf"))
                               or value > schema.get("maximum", float("inf"))):
        return False
    return True


def _source_test_ids(root: Path, modules: list[str]) -> tuple[list[str], dict[str, str]]:
    """Re-derive static unittest IDs from the exact current test source bytes."""
    names: list[str] = []
    source_hashes: dict[str, str] = {}
    for module in modules:
        _require(module.startswith("tests.") and all(_PART.fullmatch(part) for part in module.split(".")),
                 "codex-exact-bootstrap-subject-invalid", "validation module path is invalid")
        relative = module.replace(".", "/") + ".py"
        raw = read_authority_bytes(root / relative, root=root, max_bytes=262_144)
        source_hashes[relative] = _sha(raw)
        try:
            tree = ast.parse(raw, filename=relative)
        except (SyntaxError, ValueError) as exc:
            raise LifecycleError("codex-exact-bootstrap-subject-invalid",
                                 "validation test source cannot be parsed") from exc
        for node in tree.body:
            if not isinstance(node, ast.ClassDef):
                continue
            if not any((isinstance(base, ast.Attribute) and isinstance(base.value, ast.Name)
                        and base.value.id == "unittest" and base.attr == "TestCase")
                       or (isinstance(base, ast.Name) and base.id == "TestCase")
                       for base in node.bases):
                continue
            names.extend(f"{module}.{node.name}.{method.name}" for method in node.body
                         if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef))
                         and method.name.startswith("test_"))
    _require(bool(names) and len(names) == len(set(names)),
             "codex-exact-bootstrap-subject-invalid", "validation test IDs are missing or repeated")
    return sorted(names), source_hashes


def _review_projection(
    response: dict[str, Any], provenance: dict[str, Any], request: dict[str, Any],
) -> dict[str, Any]:
    """Bind both completed reviewer turns and every ordered persisted item."""
    thread = response.get("thread") if isinstance(response, dict) else None
    _require(isinstance(thread, dict) and thread.get("id") == provenance["reviewThreadId"],
             "codex-exact-bootstrap-review-stale", "review thread differs")
    turns = thread.get("turns")
    _require(isinstance(turns, list) and len(turns) in (2, 3)
             and all(isinstance(turn, dict) and isinstance(turn.get("items"), list)
                     for turn in turns)
             and [turn.get("id") for turn in turns[-2:]]
             == [provenance["reviewTurnId"], provenance["structuredTurnId"]]
             and all(turn.get("status") == "completed" for turn in turns[-2:])
             and (len(turns) == 2 or turns[0].get("status") == "interrupted"
                  and not any(isinstance(item, dict) and item.get("type") == "exitedReviewMode"
                              for item in turns[0]["items"])),
             "codex-exact-bootstrap-review-stale", "ordered completed turns differ")
    first, second = turns[-2:]
    first_items, second_items = first["items"], second["items"]
    _require(all(isinstance(item, dict) and isinstance(item.get("id"), str)
                 and isinstance(item.get("type"), str)
                 for turn in turns for item in turn["items"]),
             "codex-exact-bootstrap-review-stale", "thread item inventory is incomplete")
    all_ids = [item["id"] for turn in turns for item in turn["items"]]
    _require(len(all_ids) == len(set(all_ids)),
             "codex-exact-bootstrap-review-stale", "duplicate thread item ID")
    review = [item for item in first_items if item["id"] == provenance["reviewItemId"]]
    body = [item for item in second_items if item["id"] == provenance["structuredItemId"]]
    inputs = [item for item in second_items if item["id"] == provenance["structuredInputItemId"]]
    _require(len(review) == len(body) == len(inputs) == 1
             and review[0]["type"] == "exitedReviewMode"
             and isinstance(review[0].get("review"), str)
             and body[0]["type"] == "agentMessage"
             and isinstance(body[0].get("text"), str)
             and inputs[0]["type"] == "userMessage"
             and second_items.index(inputs[0]) < second_items.index(body[0]),
             "codex-exact-bootstrap-review-stale", "review, input or body item differs")
    expected_input = request["params"]["input"]
    _require(inputs[0].get("content") == expected_input
             and _sha(canonical_bytes(expected_input)) == provenance["structuredInputSha256"],
             "codex-exact-bootstrap-review-stale", "second-turn model input differs")
    sequence = [{"turnId": turn["id"], "items": [
        {"id": item["id"], "type": item["type"], "sha256": _sha(canonical_bytes(item))}
        for item in turn["items"]]} for turn in turns]
    _require(canonical_digest(sequence) == provenance["orderedThreadItemSequenceSha256"],
             "codex-exact-bootstrap-review-stale", "ordered thread item sequence differs")
    return {"threadId": thread["id"], "turns": sequence,
            "reviewText": review[0]["review"], "structuredBody": body[0]["text"]}


def build_structured_review_request(
    *, request_id: int, thread_id: str, review_turn_id: str,
    review_item_id: str, review_text: str, subject: dict[str, Any],
    output_schema: dict[str, Any], cwd: Path,
) -> bytes:
    """Serialize the exact second-turn request for private save-before-send."""
    _require(type(request_id) is int and request_id > 0 and bool(thread_id)
             and bool(review_turn_id) and bool(review_item_id)
             and isinstance(review_text, str)
             and len(review_text.encode("utf-8")) <= 32768,
             "codex-exact-bootstrap-review-unavailable", "second-turn source unavailable")
    payload = {"assignedSubject": subject, "reviewText": review_text,
               "reviewTurnId": review_turn_id, "reviewItemId": review_item_id,
               "reviewTextSha256": _sha(review_text.encode("utf-8"))}
    prompt = _STRUCTURED_REVIEW_INSTRUCTION + canonical_bytes(payload).decode("utf-8")
    request = {"id": request_id, "method": "turn/start", "params": {
        "threadId": thread_id, "cwd": str(Path(cwd).absolute()),
        "approvalPolicy": "never", "sandboxPolicy": {"type": "readOnly"},
        "input": [{"type": "text", "text": prompt}], "outputSchema": output_schema}}
    raw = canonical_bytes(request) + b"\n"
    _require(len(raw) <= 65536,
             "codex-exact-bootstrap-review-unavailable", "second-turn request exceeds cap")
    return raw


def assess_structured_review_context_fit(
    *, first_turn_total_tokens: int, first_turn_items: list[dict[str, Any]],
    request_bytes: bytes, model_context_window: int,
) -> dict[str, int | str]:
    """Conservative same-model pre-send bound; unknown telemetry refuses."""
    _require(type(first_turn_total_tokens) is int and first_turn_total_tokens >= 0
             and type(model_context_window) is int and model_context_window > 0
             and isinstance(first_turn_items, list) and bool(first_turn_items)
             and all(isinstance(item, dict) for item in first_turn_items)
             and isinstance(request_bytes, bytes) and 0 < len(request_bytes) <= 65536,
             "codex-exact-bootstrap-review-context-unknown", "context evidence unavailable")
    transcript_bytes = sum(len(canonical_bytes(item)) for item in first_turn_items)
    upper = max(first_turn_total_tokens, transcript_bytes)
    required = upper + len(request_bytes) + 8192 + 16384
    _require(required <= model_context_window,
             "codex-exact-bootstrap-review-context-overflow", "second turn exceeds conservative fit")
    return {"schemaVersion": "alk-route-bootstrap-context-fit.v1",
            "firstTurnTotalTokens": first_turn_total_tokens,
            "firstTurnItemTranscriptUtf8Bytes": transcript_bytes,
            "priorContextUpperBoundTokens": upper,
            "serializedSecondRequestUtf8Bytes": len(request_bytes),
            "structuredOutputReserveTokens": 8192,
            "contextSafetyTokens": 16384,
            "modelContextWindow": model_context_window,
            "requiredUpperBoundTokens": required}


def _review_findings_match(review_text: str, body: dict[str, Any]) -> bool:
    """Never promote prose or an omitted/downgraded current comment to PASS."""
    clean = review_text in {"NO_CURRENT_FINDINGS", "NO_CURRENT_FINDINGS\n"}
    if clean:
        return body["verdict"] == "PASS" and body["findings"] == []
    if body["verdict"] != "FAIL":
        return False
    expected = []
    for match in re.finditer(r"(?m)^- \[(P[123])\] [^\r\n]+$", review_text):
        level = match.group(1)
        expected.append((level, {"P1": "HIGH", "P2": "MEDIUM", "P3": "LOW"}[level],
                         _sha(match.group(0).encode("utf-8"))))
    actual = [(finding["reviewLevel"], finding["severity"], finding["rawSpanSha256"])
              for finding in body["findings"]]
    return bool(expected) and len(expected) == len(set(expected)) and sorted(actual) == sorted(expected)


def collect_two_turn_bootstrap_review(
    project_root: Path, *, thread_read: dict[str, Any], selected_binary_sha256: str,
    created_at_utc: str,
) -> dict[str, Any]:
    """Independent collector for exact reviewer-authored item bytes.

    This produces a review receipt, never a lead acceptance receipt. The caller
    must be the assigned independent reviewer; first-native admission separately
    reopens the App Server thread and the lead's later digest join.
    """
    root = Path(project_root).absolute()
    base = root / "work/release-2-16/evidence/route-bootstrap"
    try:
        assignment_raw = _read_private(base / "review-assignment.json", root=root)
        subject_raw = _read_private(base / "review-subject.json", root=root)
        review_raw = _read_private(base / "review-text.raw", root=root)
        request_raw = _read_private(base / "structured-turn-request.json", root=root)
        transport_raw = _read_private(base / "structured-turn-response.json", root=root)
        fit_raw = _read_private(base / "second-turn-context-fit.json", root=root)
        assignment, subject = json.loads(assignment_raw), json.loads(subject_raw)
        request, transport, fit = json.loads(request_raw), json.loads(transport_raw), json.loads(fit_raw)
        review_text = review_raw.decode("utf-8")
    except (OSError, ValueError, UnicodeDecodeError) as exc:
        raise LifecycleError("codex-exact-bootstrap-review-unavailable",
                             "two-turn reviewer source unavailable") from exc
    contract = json.loads((root / "tasks/release-2-16/route-bootstrap-contract.json").read_text())
    schema = contract["artifacts"]["reviewerBody"]["closedSchema"]
    audit_schema = contract["artifacts"]["independentAudit"]["closedSchema"]
    _require(isinstance(subject, dict) and isinstance(assignment, dict)
             and assignment.get("subject") == {**subject, "codexBinarySha256": selected_binary_sha256}
             and assignment.get("reviewerActorId") != assignment.get("leadActorId")
             and assignment.get("reviewerSessionId") != assignment.get("leadSessionId"),
             "codex-exact-bootstrap-review-stale", "independent assignment differs")
    _recompute_bootstrap_subject(root, base, contract, subject)
    _require(isinstance(request, dict) and isinstance(request.get("params"), dict)
             and type(request.get("id")) is int
             and isinstance(transport, dict) and isinstance(fit, dict)
             and len(review_raw) <= 32768,
             "codex-exact-bootstrap-review-stale", "review source or request malformed")
    turns = thread_read.get("thread", {}).get("turns") if isinstance(thread_read, dict) else None
    _require(isinstance(turns, list) and len(turns) in (2, 3)
             and all(isinstance(turn, dict) and isinstance(turn.get("items"), list)
                     for turn in turns),
             "codex-exact-bootstrap-review-stale", "two-turn thread unavailable")
    first, second = turns[-2:]
    review = [item for item in first["items"] if isinstance(item, dict)
              and item.get("type") == "exitedReviewMode"]
    bodies = [item for item in second["items"] if isinstance(item, dict)
              and item.get("type") == "agentMessage"]
    inputs = [item for item in second["items"] if isinstance(item, dict)
              and item.get("type") == "userMessage"]
    _require(len(review) == len(bodies) == len(inputs) == 1
             and review[0].get("review") == review_text
             and isinstance(bodies[0].get("text"), str),
             "codex-exact-bootstrap-review-stale", "completed reviewer items unavailable")
    sequence = [{"turnId": turn["id"], "items": [
        {"id": item["id"], "type": item["type"], "sha256": _sha(canonical_bytes(item))}
        for item in turn["items"]]} for turn in turns]
    provenance = {
        "source": "LOCAL_CODEX_APP_SERVER_TWO_TURN_REVIEW_THREAD",
        "reviewAssignmentSha256": _sha(assignment_raw),
        "codexBinarySha256": selected_binary_sha256,
        "reviewThreadId": thread_read["thread"]["id"],
        "reviewTurnId": first["id"], "reviewItemId": review[0]["id"],
        "rawReviewTextSha256": _sha(review_raw),
        "structuredTurnId": second["id"], "structuredItemId": bodies[0]["id"],
        "structuredRequestSha256": _sha(request_raw),
        "outputSchemaSha256": _sha(canonical_bytes(schema)),
        "fixedPromptTemplateSha256": _sha(_STRUCTURED_REVIEW_INSTRUCTION.encode("utf-8")),
        "rawStructuredBodySha256": _sha(bodies[0]["text"].encode("utf-8")),
        "structuredRequestId": request["id"], "structuredRequestBytes": len(request_raw),
        "structuredWrittenBytes": transport.get("writtenBytes"),
        "structuredWriteCompleted": transport.get("writeCompleted"),
        "structuredInputItemId": inputs[0]["id"],
        "structuredInputSha256": _sha(canonical_bytes(request["params"]["input"])),
        "secondTurnContextFitSha256": _sha(fit_raw),
        "structuredResponseId": transport.get("responseId"),
        "structuredWrittenRequestSha256": transport.get("writtenRequestSha256"),
        "orderedThreadItemSequenceSha256": canonical_digest(sequence),
    }
    projection = _review_projection(thread_read, provenance, request)
    provenance["threadReadSha256"] = canonical_digest(projection)
    _require(request_raw == build_structured_review_request(
                 request_id=request["id"], thread_id=provenance["reviewThreadId"],
                 review_turn_id=provenance["reviewTurnId"],
                 review_item_id=provenance["reviewItemId"], review_text=review_text,
                 subject=subject, output_schema=schema, cwd=root)
             and transport.get("requestId") == request["id"]
             and transport.get("responseId") == request["id"]
             and transport.get("turnId") == second["id"]
             and transport.get("writtenBytes") == len(request_raw)
             and transport.get("writtenRequestSha256") == _sha(request_raw)
             and transport.get("writeCompleted") is True,
             "codex-exact-bootstrap-review-stale", "second-turn write/response unproved")
    expected_fit = assess_structured_review_context_fit(
        first_turn_total_tokens=fit.get("firstTurnTotalTokens"),
        first_turn_items=[item for turn in turns[:-1] for item in turn["items"]],
        request_bytes=request_raw,
        model_context_window=fit.get("modelContextWindow"))
    _require(all(fit.get(key) == value for key, value in expected_fit.items())
             and fit.get("selectedBinarySha256") == selected_binary_sha256
             and fit.get("selectedModel") == thread_read["thread"].get("model"),
             "codex-exact-bootstrap-review-context-unknown", "selected context fit differs")
    body_raw = bodies[0]["text"].encode("utf-8")
    try:
        body = json.loads(body_raw)
    except (ValueError, UnicodeDecodeError) as exc:
        raise LifecycleError("codex-exact-bootstrap-review-stale",
                             "reviewer body is not JSON") from exc
    _require(_matches_closed_schema(body, schema)
             and body["subject"] == subject
             and body["reviewTextSha256"] == _sha(review_raw)
             and body["phase"] == "PRE_WS01" and body["rb11RuntimeStatus"] == "NOT_RUN"
             and _review_findings_match(review_text, body),
             "codex-exact-bootstrap-review-stale", "reviewer body or finding mapping differs")
    audit = {"schemaVersion": "alk-route-bootstrap-independent-audit.v3",
             "createdAtUtc": created_at_utc, "verdict": body["verdict"],
             "reviewerActorId": assignment["reviewerActorId"],
             "reviewerSessionId": assignment["reviewerSessionId"],
             "leadActorId": assignment["leadActorId"],
             "leadSessionId": assignment["leadSessionId"], **subject,
             "producerProvenance": provenance, "phase": "PRE_WS01",
             "rb11RuntimeStatus": "NOT_RUN", "reviewerBodySha256": _sha(body_raw),
             "reviewTextSha256": _sha(review_raw), "collectorStatus": "VERIFIED"}
    _require(_matches_closed_schema(audit, audit_schema),
             "codex-exact-bootstrap-review-stale", "collector record violates closed schema")
    _write_exclusive(base / "reviewer-body.json", body_raw, root=root)
    _write_exclusive(base / "independent-audit.json", canonical_bytes(audit), root=root)
    return {"verdict": body["verdict"], "auditSha256": _sha(canonical_bytes(audit))}


def read_codex_app_server_thread(
    project_root: Path, *, executable: str, expected_binary_sha256: str, thread_id: str,
    process_env: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Use only the documented local stdio handshake and thread/read method."""
    root = Path(project_root).absolute()
    environment = dict(os.environ) if process_env is None else process_env
    selected = (Path(executable) if Path(executable).is_absolute()
                else Path(shutil.which(executable, path=environment.get("PATH", "")) or ""))
    _require(selected.is_file() and selected.name == "codex"
             and isinstance(thread_id, str) and bool(thread_id),
             "codex-exact-bootstrap-review-unavailable", "selected App Server binary is unavailable")
    binary = selected.resolve(strict=True)
    _require(_sha(binary.read_bytes()) == expected_binary_sha256,
             "codex-exact-bootstrap-review-unavailable", "selected App Server binary differs")
    try:
        process = subprocess.Popen(
            [str(binary), "app-server", "--listen", "stdio://"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            cwd=root, env=environment, bufsize=0,
        )
    except OSError as exc:
        raise LifecycleError("codex-exact-bootstrap-review-unavailable",
                             "local App Server could not start") from exc
    deadline = time.monotonic() + 15.0
    buffered = bytearray()
    total = 0
    try:
        _require(process.stdin is not None and process.stdout is not None,
                 "codex-exact-bootstrap-review-unavailable", "local App Server pipes unavailable")
        with selectors.DefaultSelector() as selector:
            selector.register(process.stdout, selectors.EVENT_READ)

            def send(message: dict[str, Any]) -> None:
                process.stdin.write(canonical_bytes(message) + b"\n")
                process.stdin.flush()

            def receive(request_id: int) -> dict[str, Any]:
                nonlocal total
                while time.monotonic() < deadline:
                    while b"\n" in buffered:
                        line, _, rest = buffered.partition(b"\n")
                        buffered[:] = rest
                        if not line:
                            continue
                        try:
                            message = json.loads(line)
                        except (ValueError, UnicodeDecodeError) as exc:
                            raise LifecycleError("codex-exact-bootstrap-review-unavailable",
                                                 "invalid App Server JSONL") from exc
                        _require(isinstance(message, dict),
                                 "codex-exact-bootstrap-review-unavailable", "invalid App Server message")
                        if message.get("id") == request_id:
                            _require("error" not in message and isinstance(message.get("result"), dict),
                                     "codex-exact-bootstrap-review-unavailable",
                                     "App Server refused the request")
                            return message["result"]
                        _require("id" not in message,
                                 "codex-exact-bootstrap-review-unavailable",
                                 "unexpected App Server response")
                    events = selector.select(max(0.0, deadline - time.monotonic()))
                    _require(bool(events), "codex-exact-bootstrap-review-unavailable",
                             "local App Server timed out")
                    chunk = os.read(process.stdout.fileno(), 65_536)
                    _require(bool(chunk), "codex-exact-bootstrap-review-unavailable",
                             "local App Server closed before responding")
                    total += len(chunk)
                    _require(total <= 4_194_304, "codex-exact-bootstrap-review-unavailable",
                             "local App Server response exceeded the bound")
                    buffered.extend(chunk)
                raise LifecycleError("codex-exact-bootstrap-review-unavailable",
                                     "local App Server timed out")

            send({"method": "initialize", "id": 1,
                  "params": {"clientInfo": {"name": "agent_lifecycle_kit",
                                            "title": "Agent Lifecycle Kit", "version": "2.16.0"}}})
            receive(1)
            send({"method": "initialized", "params": {}})
            send({"method": "thread/read", "id": 2,
                  "params": {"threadId": thread_id, "includeTurns": True}})
            result = receive(2)
        _require(_sha(binary.read_bytes()) == expected_binary_sha256,
                 "codex-exact-bootstrap-review-unavailable", "selected App Server binary changed")
        return result
    except (OSError, ValueError, TypeError) as exc:
        raise LifecycleError("codex-exact-bootstrap-review-unavailable",
                             "local App Server read failed") from exc
    finally:
        if process.poll() is None:
            process.terminate()
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=2)
        if process.stdin is not None:
            process.stdin.close()
        if process.stdout is not None:
            process.stdout.close()


def _recompute_bootstrap_subject(
    root: Path, base: Path, contract: dict[str, Any], subject: dict[str, Any],
) -> None:
    """Reopen the private PRE subject; a matching reviewer JSON is insufficient."""
    support = base / "support"
    names = ("before-wip-inventory.json", "after-wip-inventory.json",
             "c34.stdout", "c34.stderr", "c34-result.json", "c34-cases.json",
             "c34-execution.json",
             "c35.stdout", "c35.stderr", "c35-result.json", "c35-cases.json",
             "c35-execution.json",
             "cost.json", "admission.json")
    raw = {name: _read_private(support / name, root=root) for name in names}
    try:
        before = json.loads(raw["before-wip-inventory.json"])
        after = json.loads(raw["after-wip-inventory.json"])
        cost = json.loads(raw["cost.json"])
        admission = json.loads(raw["admission.json"])
    except (ValueError, UnicodeDecodeError) as exc:
        raise LifecycleError("codex-exact-bootstrap-subject-invalid",
                             "bootstrap support is malformed") from exc
    _require(isinstance(before, dict) and isinstance(after, dict)
             and isinstance(cost, dict) and isinstance(admission, dict),
             "codex-exact-bootstrap-subject-invalid", "bootstrap support is incomplete")
    for inventory in (before, after):
        _require(isinstance(inventory.get("inventorySubject"), dict)
                 and inventory.get("canonicalInventorySubjectSha256")
                 == canonical_digest(inventory["inventorySubject"]),
                 "codex-exact-bootstrap-subject-invalid", "WIP inventory digest differs")
    b, a = before["inventorySubject"], after["inventorySubject"]
    _require(subject["wholeWipBeforeAfterInventoryDigest"] == {
                 "before": before["canonicalInventorySubjectSha256"],
                 "after": after["canonicalInventorySubjectSha256"]},
             "codex-exact-bootstrap-subject-stale", "reviewed WIP inventory differs")

    def git(*args: str, allow_missing: bool = False) -> bytes | None:
        try:
            result = subprocess.run(["git", *args], cwd=root, capture_output=True,
                                    timeout=15, check=False)
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise LifecycleError("codex-exact-bootstrap-subject-unavailable",
                                 "Git source could not be reopened") from exc
        _require(len(result.stdout) <= 4_194_304 and len(result.stderr) <= 65_536,
                 "codex-exact-bootstrap-subject-unavailable", "Git source exceeds bound")
        if allow_missing and result.returncode != 0:
            return None
        _require(result.returncode == 0,
                 "codex-exact-bootstrap-subject-unavailable", "Git source read failed")
        return result.stdout

    head = git("rev-parse", "HEAD")
    _require(isinstance(head, bytes) and head.decode("ascii").strip() == a.get("gitHead") == b.get("gitHead"),
             "codex-exact-bootstrap-subject-stale", "WIP HEAD changed")
    diff = git("diff", "--binary", "--", "src", "tests", "policy", "tools")
    _require(isinstance(diff, bytes)
             and a.get("trackedDiff", {}).get("sha256") == _sha(diff)
             and a["trackedDiff"].get("bytes") == len(diff),
             "codex-exact-bootstrap-subject-stale", "tracked WIP diff changed")
    rows = a.get("trackedModified", []) + a.get("untracked", [])
    before_rows = b.get("trackedModified", []) + b.get("untracked", [])
    _require(isinstance(rows, list) and isinstance(before_rows, list)
             and 0 < len(rows) <= 512 and len(rows) == len(before_rows)
             and all(isinstance(row, dict) and isinstance(row.get("path"), str) for row in rows + before_rows),
             "codex-exact-bootstrap-subject-invalid", "WIP path inventory is invalid")
    current = {row["path"]: row for row in rows}
    prior = {row["path"]: row for row in before_rows}
    _require(len(current) == len(rows) and len(prior) == len(before_rows)
             and set(current) == set(prior),
             "codex-exact-bootstrap-subject-stale", "WIP path set changed")
    status = git("status", "--porcelain=v1", "-uall", "--", "src", "tests", "policy", "tools")
    _require(isinstance(status, bytes)
             and {line[3:].decode("utf-8") for line in status.splitlines()} == set(current),
             "codex-exact-bootstrap-subject-stale", "WIP status has an unreviewed path")
    owned = set(contract["ownership"]["temporaryLeadWritePaths"])
    for relative, row in current.items():
        path = Path(relative)
        _require(not path.is_absolute() and ".." not in path.parts
                 and path.parts[0] in {"src", "tests", "policy", "tools"},
                 "codex-exact-bootstrap-subject-invalid", "WIP path escapes the checkout")
        target = root / path
        info = target.lstat()
        _require(stat.S_ISREG(info.st_mode) and info.st_size <= 8_388_608
                 and row.get("currentBytes") == info.st_size
                 and row.get("currentSha256") == _file_sha(target),
                 "codex-exact-bootstrap-subject-stale", "reviewed WIP bytes changed")
        if relative not in owned:
            _require(row.get("currentSha256") == prior[relative].get("currentSha256")
                     and row.get("currentBytes") == prior[relative].get("currentBytes"),
                     "codex-exact-bootstrap-subject-scope", "non-owned WIP changed")
    six = {}
    for relative in contract["ownership"]["temporaryLeadWritePaths"]:
        _require(relative in current, "codex-exact-bootstrap-subject-scope",
                 "temporary owned path is missing")
        head_bytes = git("show", f"HEAD:{relative}", allow_missing=True)
        six[relative] = {"beforeExists": head_bytes is not None,
                         "beforeSha256": _sha(head_bytes) if head_bytes is not None else None,
                         "afterSha256": current[relative]["currentSha256"]}
    _require(subject["sixPathBeforeAfterSha256"] == six,
             "codex-exact-bootstrap-subject-stale", "six owned source bases/afters differ")

    outputs = []
    mapped_cases: set[str] = set()
    for command in contract["validation"]["commands"]:
        ident = command["id"].lower()
        try:
            result = json.loads(raw[f"{ident}-result.json"])
            cases = json.loads(raw[f"{ident}-cases.json"])
            execution = json.loads(raw[f"{ident}-execution.json"])
        except (ValueError, UnicodeDecodeError) as exc:
            raise LifecycleError("codex-exact-bootstrap-subject-invalid",
                                 "validation support is malformed") from exc
        parts = shlex.split(command["command"])
        _require(parts[:3] == ["PYTHONDONTWRITEBYTECODE=1", "PYTHONPATH=src", "python3"]
                 and parts[3:5] == ["-m", "unittest"] and parts[-1] == "-q"
                 and len(parts) >= 7
                 and canonical_digest(command["command"]) == command["canonicalDigest"],
                 "codex-exact-bootstrap-subject-invalid", "locked validation command is invalid")
        modules = parts[5:-1]
        source_names, source_hashes = _source_test_ids(root, modules)
        python_value = execution.get("pythonResolvedPath") if isinstance(execution, dict) else None
        python_path = Path(python_value) if isinstance(python_value, str) else Path()
        try:
            python_ok = (python_path.is_absolute() and python_path.resolve(strict=True) == python_path
                         and _file_sha(python_path) == execution.get("pythonSha256"))
        except (OSError, LifecycleError):
            python_ok = False
        try:
            started_at = datetime.fromisoformat(execution["startedAtUtc"])
            ended_at = datetime.fromisoformat(execution["endedAtUtc"])
            time_ok = (started_at.tzinfo is not None and ended_at.tzinfo is not None
                       and started_at <= ended_at)
        except (KeyError, TypeError, ValueError):
            time_ok = False
        stderr = raw[f"{ident}.stderr"]
        count = re.search(rb"Ran ([0-9]+) tests? in .*\n\nOK\s*\Z", stderr, re.S)
        mapping = cases.get("localCaseMapping") if isinstance(cases, dict) else None
        _require(isinstance(result, dict) and isinstance(cases, dict)
                 and isinstance(execution, dict) and count is not None
                 and result.get(ident) == f"PASS_{int(count.group(1))}_TESTS"
                 and result.get(f"{ident}StderrSha256") == _sha(stderr)
                 and cases.get("commandId") == command["id"]
                 and cases.get("testNames") == source_names
                 and cases.get("sourceTestFileSha256") == source_hashes
                 and len(source_names) == int(count.group(1))
                 and isinstance(mapping, dict)
                 and all(isinstance(group, list) and bool(group)
                         and set(group) <= set(source_names) for group in mapping.values())
                 and execution.get("source") == "SUBPROCESS_CAPTURE"
                 and execution.get("contractCommand") == command["command"]
                 and execution.get("commandDigest") == command["canonicalDigest"]
                 and execution.get("argv") == parts[2:]
                 and execution.get("environment") == {
                     "PYTHONDONTWRITEBYTECODE": "1", "PYTHONPATH": "src"}
                 and execution.get("cwd") == str(root)
                 and execution.get("exitCode") == 0
                 and execution.get("stdoutSha256") == _sha(raw[f"{ident}.stdout"])
                 and execution.get("stderrSha256") == _sha(stderr)
                 and execution.get("testNames") == source_names
                 and execution.get("sourceTestFileSha256") == source_hashes
                 and type(execution.get("processId")) is int and execution["processId"] > 0
                 and time_ok
                 and python_ok,
                 "codex-exact-bootstrap-subject-stale", "validation command, output or case provenance differs")
        mapped_cases.update(mapping)
        outputs.append({"commandDigest": command["canonicalDigest"],
                        "outputSha256": canonical_digest({
                            "stdoutSha256": _sha(raw[f"{ident}.stdout"]),
                            "stderrSha256": _sha(stderr)}),
                        "caseDigest": canonical_digest(cases)})
    _require(mapped_cases == {case["id"] for case in contract["validation"]["cases"]},
             "codex-exact-bootstrap-subject-stale", "PRE case mapping is incomplete")
    _require(subject["C34C35CommandOutputCaseDigests"] == outputs,
             "codex-exact-bootstrap-subject-stale", "C34/C35 reviewed support differs")
    _require(admission.get("status") == "ADMITTED_PREAPPROVED_BY_USER"
             and admission.get("bootstrapAdmissionId") == subject["bootstrapAdmissionId"]
             and admission.get("implementationOriginAdmissionId")
             == cost.get("implementationOriginAdmissionId")
             and admission.get("implementationOriginAdmissionId")
             == "r166-pre-ws01-route-bootstrap"
             and type(admission.get("priorUnknownHolds")) is int
             and type(admission.get("tokenCap")) is int
             and admission["priorUnknownHolds"] >= 0
             and 0 < admission["tokenCap"] <= contract["accounting"]["totalModelTokensCap"]
             and admission["priorUnknownHolds"] + admission["tokenCap"]
             == admission.get("admittedUnknownHolds")
             == cost.get("heldUnknownTokens")
             and cost.get("priorUnknownHolds") == admission["priorUnknownHolds"]
             and cost.get("windowCap") == admission["tokenCap"]
             and cost.get("admissionSha256") == _sha(raw["admission.json"])
             and admission.get("actualModelTokens") is None
             and admission.get("costStatus") == "UNAVAILABLE",
             "codex-exact-bootstrap-subject-stale", "admitted cost source or arithmetic differs")
    _require(subject["privateSupportReceiptDigests"] == {name: _sha(value) for name, value in raw.items()}
             and cost.get("costStatus") == subject["costStatus"]
             and cost.get("heldUnknownTokens") == subject["heldUnknownTokens"]
             and cost.get("actualModelTokens") is None,
             "codex-exact-bootstrap-subject-stale", "private support or held cost differs")
    _require(subject["reviewedInputDigest"] == canonical_digest({
                 key: value for key, value in subject.items() if key != "reviewedInputDigest"}),
             "codex-exact-bootstrap-subject-stale", "reviewed input digest is not source-derived")


def require_bootstrap_audit(
    project_root: Path, *, plan_digest: str, lock_sha256: str,
    selected_binary_sha256: str,
    fresh_thread_read: Callable[[str], dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Verify a separately delivered audit and the lead's SHA-bound join.

    This checks ALK evidence integrity. It does not promote local tests to
    selected-host proof or make the coordinator's unavailable cost known.
    """
    root = Path(project_root).absolute()
    base = root / "work/release-2-16/evidence/route-bootstrap"
    audit_path = base / "independent-audit.json"
    body_path = base / "reviewer-body.json"
    receipt_path = base / "receipt.json"
    assignment_path = base / "review-assignment.json"
    try:
        audit_raw = _read_private(audit_path, root=root)
        body_raw = _read_private(body_path, root=root)
        review_raw = _read_private(base / "review-text.raw", root=root)
        request_raw = _read_private(base / "structured-turn-request.json", root=root)
        transport_raw = _read_private(base / "structured-turn-response.json", root=root)
        fit_raw = _read_private(base / "second-turn-context-fit.json", root=root)
        receipt_raw = _read_private(receipt_path, root=root)
        assignment_raw = _read_private(assignment_path, root=root)
        audit = json.loads(audit_raw)
        request = json.loads(request_raw)
        transport = json.loads(transport_raw)
        fit = json.loads(fit_raw)
        receipt = json.loads(receipt_raw)
        assignment = json.loads(assignment_raw)
        body = json.loads(body_raw)
        review_text = review_raw.decode("utf-8")
    except (OSError, ValueError, UnicodeDecodeError) as exc:
        raise LifecycleError("codex-exact-bootstrap-audit-missing", "independent bootstrap evidence is unavailable") from exc
    contract = json.loads((root / "tasks/release-2-16/route-bootstrap-contract.json").read_text())
    schema = contract["artifacts"]["independentAudit"]["closedSchema"]
    body_schema = contract["artifacts"]["reviewerBody"]["closedSchema"]
    _require(_matches_closed_schema(audit, schema) and _matches_closed_schema(body, body_schema),
             "codex-exact-bootstrap-audit-invalid", "review body or collector violates the closed schema")
    _require(audit["schemaVersion"] == "alk-route-bootstrap-independent-audit.v3"
             and audit["verdict"] == "PASS"
             and audit["r69LockSha256"] == lock_sha256
             and audit["r69PlanDigest"] == plan_digest
             and audit["phase"] == "PRE_WS01" and audit["rb11RuntimeStatus"] == "NOT_RUN"
             and audit["collectorStatus"] == "VERIFIED"
             and body["schemaVersion"] == "alk-route-bootstrap-reviewer-body.v3"
             and body["verdict"] == "PASS" and body["findings"] == []
             and body["phase"] == "PRE_WS01" and body["rb11RuntimeStatus"] == "NOT_RUN"
             and review_raw in (b"NO_CURRENT_FINDINGS", b"NO_CURRENT_FINDINGS\n")
             and len(review_raw) <= contract["auditJoin"]["delivery"]["contextFit"]["rawReviewMaxUtf8Bytes"]
             and body["reviewTextSha256"] == audit["reviewTextSha256"] == _sha(review_raw),
             "codex-exact-bootstrap-audit-mismatch", "audit authority or verdict differs")
    subject_keys = set(body_schema["properties"]["subject"]["required"])
    subject = {key: audit[key] for key in subject_keys}
    _recompute_bootstrap_subject(root, base, contract, subject)
    _require(body["subject"] == subject
             and isinstance(assignment, dict) and isinstance(assignment.get("subject"), dict)
             and all(assignment["subject"].get(key) == value for key, value in subject.items())
             and assignment.get("reviewerActorId") == audit["reviewerActorId"]
             and assignment.get("reviewerSessionId") == audit["reviewerSessionId"]
             and assignment.get("leadActorId") == audit["leadActorId"]
             and assignment.get("leadSessionId") == audit["leadSessionId"]
             and audit["reviewerActorId"] != audit["leadActorId"]
             and audit["reviewerSessionId"] != audit["leadSessionId"]
             and audit["producerProvenance"]["reviewAssignmentSha256"] == _sha(assignment_raw)
             and audit["producerProvenance"]["codexBinarySha256"]
             == assignment["subject"].get("codexBinarySha256")
             == selected_binary_sha256,
             "codex-exact-bootstrap-audit-provenance", "review subject or producer lineage differs")
    provenance = audit["producerProvenance"]
    _require(_sha(body_raw) == audit["reviewerBodySha256"] == provenance["rawStructuredBodySha256"]
             and _sha(review_raw) == provenance["rawReviewTextSha256"],
             "codex-exact-bootstrap-review-stale", "raw reviewer item digest differs")
    _require(isinstance(request, dict) and isinstance(request.get("params"), dict)
             and type(request.get("id")) is int and request["id"] > 0
             and request.get("method") == "turn/start"
             and request["params"].get("threadId") == provenance["reviewThreadId"]
             and request["params"].get("outputSchema") == body_schema
             and _sha(canonical_bytes(body_schema)) == provenance["outputSchemaSha256"]
             and _sha(_STRUCTURED_REVIEW_INSTRUCTION.encode("utf-8"))
             == provenance["fixedPromptTemplateSha256"]
             and request_raw == build_structured_review_request(
                 request_id=request["id"], thread_id=provenance["reviewThreadId"],
                 review_turn_id=provenance["reviewTurnId"],
                 review_item_id=provenance["reviewItemId"],
                 review_text=review_text, subject=subject,
                 output_schema=body_schema, cwd=root)
             and _sha(request_raw) == provenance["structuredRequestSha256"]
             and len(request_raw) == provenance["structuredRequestBytes"]
             and request["id"] == provenance["structuredRequestId"]
             and _sha(canonical_bytes(request["params"]["input"]))
             == provenance["structuredInputSha256"],
             "codex-exact-bootstrap-review-stale", "second-turn request or full subject differs")
    _require(isinstance(transport, dict)
             and transport.get("requestId") == request["id"]
             and transport.get("responseId") == request["id"]
             and transport.get("turnId") == provenance["structuredTurnId"]
             and transport.get("writeCompleted") is True
             and transport.get("writtenBytes") == len(request_raw)
             and transport.get("writtenRequestSha256") == _sha(request_raw)
             and provenance["structuredResponseId"] == request["id"]
             and provenance["structuredWrittenBytes"] == len(request_raw)
             and provenance["structuredWriteCompleted"] is True
             and provenance["structuredWrittenRequestSha256"] == _sha(request_raw),
             "codex-exact-bootstrap-review-stale", "second-turn write or response differs")
    _require(isinstance(fit, dict) and fit.get("selectedBinarySha256") == selected_binary_sha256
             and fit.get("selectedModel") is not None
             and _sha(fit_raw) == provenance["secondTurnContextFitSha256"],
             "codex-exact-bootstrap-review-context-unknown", "context fit source differs")
    _require(fresh_thread_read is not None,
             "codex-exact-bootstrap-review-unavailable", "fresh App Server thread/read is required")
    try:
        fresh = fresh_thread_read(provenance["reviewThreadId"])
        projection = _review_projection(fresh, provenance, request)
    except (OSError, ValueError, TypeError, KeyError) as exc:
        raise LifecycleError("codex-exact-bootstrap-review-unavailable",
                             "fresh App Server review read failed") from exc
    first_items = [item for turn in fresh["thread"]["turns"][:-1]
                   for item in turn["items"]]
    expected_fit = assess_structured_review_context_fit(
        first_turn_total_tokens=fit.get("firstTurnTotalTokens"),
        first_turn_items=first_items, request_bytes=request_raw,
        model_context_window=fit.get("modelContextWindow"))
    _require(all(fit.get(key) == value for key, value in expected_fit.items())
             and fresh["thread"].get("model") == fit["selectedModel"],
             "codex-exact-bootstrap-review-context-unknown", "context fit no longer matches")
    _require(projection["reviewText"].encode("utf-8") == review_raw
             and projection["structuredBody"].encode("utf-8") == body_raw
             and canonical_digest(projection) == provenance["threadReadSha256"],
             "codex-exact-bootstrap-review-stale", "live two-turn review differs from retained items")
    six = audit["sixPathBeforeAfterSha256"]
    expected_paths = contract["ownership"]["temporaryLeadWritePaths"]
    _require(isinstance(six, dict) and set(six) == set(expected_paths),
             "codex-exact-bootstrap-audit-scope", "audit write inventory differs")
    for relative, row in six.items():
        _require(isinstance(row, dict) and set(row) == {"beforeExists","beforeSha256","afterSha256"}
                 and isinstance(row["beforeExists"], bool)
                 and (row["beforeSha256"] is None or isinstance(row["beforeSha256"], str))
                 and isinstance(row["afterSha256"], str)
                 and _sha((root / relative).read_bytes()) == row["afterSha256"],
                 "codex-exact-bootstrap-audit-stale", "audited ALK code bytes changed")
    _require(isinstance(receipt, dict)
             and receipt.get("planDigest") == plan_digest
             and receipt.get("lockSha256") == lock_sha256
             and receipt.get("independentAuditSha256") == _sha(audit_raw)
             and receipt.get("reviewerBodySha256") == _sha(body_raw)
             and receipt.get("independentAuditVerdict") == "PASS"
             and receipt.get("bootstrapAdmissionId") == audit["bootstrapAdmissionId"]
             and receipt.get("bootstrapId") == audit["bootstrapId"]
             and receipt.get("sixPathBeforeAfterSha256") == six
             and receipt.get("wholeWipBeforeAfterInventoryDigest") == audit["wholeWipBeforeAfterInventoryDigest"]
             and receipt.get("C34C35CommandOutputCaseDigests") == audit["C34C35CommandOutputCaseDigests"]
             and receipt.get("privateSupportReceiptDigests") == audit["privateSupportReceiptDigests"]
             and receipt.get("costStatus") == audit["costStatus"]
             and receipt.get("heldUnknownTokens") == audit["heldUnknownTokens"]
             and receipt.get("reviewedInputDigest") == audit["reviewedInputDigest"],
             "codex-exact-bootstrap-lead-join-invalid", "lead receipt is not joined to independent audit")
    return {"status":"PASS", "auditSha256":_sha(audit_raw),
            "receiptSha256":_sha(receipt_raw), "reviewedInputDigest":audit["reviewedInputDigest"]}


def prepare_exact_prompt(
    *, project_root: Path, input_request: Path | None, route_id: str | None,
    requested_claim: str | None, state: dict[str, Any], task: dict[str, Any],
    manifest: dict[str, Any], lock_path: Path, source_revision: str,
    operation_id: str, executable_identity: dict[str, Any], executable: str,
    process_env: dict[str, str] | None = None, state_path: Path | None = None,
    manifest_path: Path | None = None,
) -> dict[str, Any]:
    """Seal and check one task-bound ALK request before any child is started."""
    root = Path(project_root).absolute()
    _require(route_id == ROUTE_ID and requested_claim == CLAIM and input_request is not None,
             "codex-exact-route-required", "explicit supported route, claim and private request are required")
    run_id = _part(state.get("runId"), "runId")
    task_id = _part(task.get("id"), "taskId")
    attempt = task.get("attempt")
    _require(type(attempt) is int and attempt > 0 and task.get("status") == "RUNNING",
             "codex-exact-attempt-unverified", "active task attempt is not verified")
    attempt_id = _part(str(attempt), "attemptId")
    _require(state.get("sourceRevision") == source_revision,
             "codex-exact-source-revision-mismatch", "source revision changed")
    sealed: Path | None = None
    reserved: list[Path] = []
    try:
        reconcile_prelaunch_intents(root, active_staging_request=Path(input_request))
        _assert_no_cleanup_blockers(root)
        attempt_evidence = (root / "work/release-2-16/evidence/codex-exact-prompt"
                            / run_id / task_id / attempt_id)
        _require(not (attempt_evidence / "prelaunch-intent.json").exists(),
                 "codex-exact-attempt-reused", "this task attempt already has a prelaunch intent")
        sealed, request = _seal_request(root, Path(input_request), run_id, task_id, attempt_id)
        plan_digest = canonical_digest(manifest)
        lock_digest = _sha(Path(lock_path).read_bytes())
        for key, expected in (
            ("routeId", ROUTE_ID), ("requestedClaim", CLAIM), ("runId", run_id),
            ("taskId", task_id), ("attemptId", attempt_id), ("planDigest", plan_digest),
            ("lockDigest", lock_digest), ("sourceRevision", source_revision),
            ("operationId", operation_id),
        ):
            _require(request.get(key) == expected, "codex-exact-request-binding-mismatch",
                     f"{key} differs from the active attempt")
        packet_rel = request.get("packetPath")
        _require(isinstance(packet_rel, str) and packet_rel.startswith("work/release-2-16/")
                 and ".." not in Path(packet_rel).parts,
                 "codex-exact-packet-path-invalid", "packet path is outside release work")
        packet_raw = read_authority_bytes(root / packet_rel, root=root, max_bytes=65_536)
        _require(_sha(packet_raw) == request.get("packetSha256"),
                 "codex-exact-packet-stale", "packet bytes changed")
        packet = json.loads(packet_raw)
        _require(packet.get("plan", {}).get("planDigest") == plan_digest
                 and packet.get("task", {}).get("id") == task_id,
                 "codex-exact-packet-binding-mismatch", "packet lineage differs")
        selection = request.get("selection")
        summary = request.get("summary")
        _require(isinstance(selection, dict) and isinstance(summary, dict),
                 "codex-exact-fit-input-missing", "source selection or summary is missing")
        contract_raw = read_authority_bytes(
            root / "tasks/release-2-16/alk-input-fit-contract.json", root=root,
            max_bytes=1_048_576)
        profile_raw = read_authority_bytes(
            root / "profiles/small-context-profile.v1.json", root=root,
            max_bytes=65_536)
        contract = json.loads(contract_raw)
        profile = json.loads(profile_raw)
        _require(contract.get("commonEnvelope", {}).get("reservedOutputEstimatedTokens") == 3072,
                 "codex-exact-output-reserve-mismatch", "planned output reserve is not 3072 tokens")
        contract_sha, profile_sha = _sha(contract_raw), _sha(profile_raw)
        binding = {key: selection.get(key) for key in
                   ("runId", "taskId", "attemptId", "planDigest", "manifestSha256", "candidateDigest", "estimatorId")}
        fit = assess_local_input_fit(
            root, contract, profile, packet, summary, selection,
            role=str(request.get("role")), host_adapter_id="codex",
            host_version=str(request.get("hostVersion", "")), host_mode=str(request.get("hostMode", "")),
            estimator_id=str(request.get("estimatorId", "")), instruction=request.get("instruction"),
            schema=request.get("schema"), current_binding=binding,
            latest_user=str(request.get("latestUser", "")), window="16k",
        )
        _require(fit["status"] == "PASS_ALK_COMPONENTS_ONLY" and all(
            check["status"] == "PASS" for check in fit["checks"]),
            "codex-exact-fit-refused", "ALK-controlled input exceeds a limit")
        rendered = render_context(profile, packet, summary,
                                  latest_user=str(request.get("latestUser", "")), window="16k")
        model_input = {"renderedEnvelope": rendered["envelope"],
                       "selectedSource": selection["selected"],
                       "instruction": request["instruction"], "schema": request["schema"]}
        final_raw = canonical_bytes(model_input)
        final_sha = _sha(final_raw)
        _require(request.get("selectedSource") == selection["selected"]
                 and fit["inputComponentDigests"]["fullAlkModelInput"] == final_sha,
                 "codex-exact-final-prompt-mismatch", "final prompt differs from fit receipt")
        _require(Path(executable).name == "codex" and executable_identity.get("status") == "PASS",
                 "codex-exact-binary-unavailable", "selected Codex binary is unavailable")
        selected_env = dict(os.environ) if process_env is None else process_env
        model, codex_home, snapshot_digest, catalog, diagnostic, config_manifest_sha = _selected_host_evidence(
            root, request, executable_identity, final_sha, run_id, task_id, attempt_id,
            executable, selected_env,
            str(request.get("role", "")))
        inventory_path, pending_path, inventory_sha = create_prestart_raw_inventory(
            root, run_id=run_id, task_id=task_id, attempt_id=attempt_id,
            sealed_request=sealed, state=state, plan_digest=plan_digest)
        selected_binary = _selected_binary_path(executable, executable_identity, selected_env)
        argv = [str(selected_binary), "exec", "--json", "--ephemeral", "-m", model, "-C", str(root), "-"]
        evidence = root / "work/release-2-16/evidence/codex-exact-prompt" / run_id / task_id / attempt_id
        start_path = evidence / "process-start.json"
        input_path = evidence / "process-input.json"
        _reserve(start_path, root=root)
        reserved.append(start_path)
        _reserve(input_path, root=root)
        reserved.append(input_path)
        intent = {"schemaVersion":"alk-codex-prelaunch-intent.v1", "runId":run_id,
                  "taskId":task_id, "attemptId":attempt_id, "role":request.get("role"),
                  "routeId":ROUTE_ID, "requestedClaim":CLAIM, "planDigest":plan_digest,
                  "packetSha256":request["packetSha256"], "finalPromptSha256":final_sha,
                  "plannedStdinBytes":len(final_raw), "commandIdentityHash":command_identity_hash(argv),
                  "binarySha256":executable_identity["executableContentSha256"],
                  "catalogObservation":catalog,
                  "diagnosticObservation":diagnostic,
                  "configManifestSha256":config_manifest_sha,
                  "codexHomePathSha256":_sha(os.fsencode(codex_home)),
                  "codexHomeContentDigest":snapshot_digest,
                  "rawInventorySha256": inventory_sha,
                  "rawCleanupPendingPath": str(pending_path.relative_to(root)),
                  "startReceiptPath":str(start_path.relative_to(root)),
                  "inputReceiptPath":str(input_path.relative_to(root)), "hostLaunchStarted":False}
        intent_path = evidence / "prelaunch-intent.json"
        _write_exclusive(intent_path, canonical_bytes(intent), root=root)
        reserved.append(intent_path)

        def verify_before_start() -> None:
            _recheck_active_workflow_state(root, state_path, state, run_id, task_id, attempt)
            _require(_selected_binary_path(executable, executable_identity, selected_env)
                     == selected_binary,
                     "codex-exact-binary-mismatch", "selected binary path changed")
            _require_current_manifest(root, manifest_path, manifest, plan_digest)
            _require(_sha(Path(lock_path).read_bytes()) == lock_digest,
                     "codex-exact-plan-stale", "lock changed before start")
            _recheck_alk_fit_sources(
                root, request, packet_rel, request["packetSha256"],
                contract_sha, profile_sha, plan_digest, task_id,
                selection, summary, binding, fit["receiptDigest"])
            _require_fresh_catalog(
                root, executable, executable_identity, model, selected_env, catalog)
            _require(_snapshot_digest(Path(codex_home), root=root) == snapshot_digest,
                     "codex-exact-config-mismatch", "private CODEX_HOME changed before start")
            _require(verify_prestart_raw_inventory(
                root, inventory_path=inventory_path, pending_path=pending_path,
                state=state, plan_digest=plan_digest) == inventory_sha,
                "codex-exact-raw-inventory-stale", "sealed raw inventory changed")
            _require(_read_private(intent_path, root=root) == canonical_bytes(intent)
                     and start_path.stat().st_size == 0 and input_path.stat().st_size == 0,
                     "codex-exact-receipt-reservation-lost", "prelaunch intent or receipt reservation changed")
            _require(_sha(_read_private(evidence / "config-snapshot-manifest.json", root=root))
                     == config_manifest_sha,
                     "codex-exact-config-mismatch", "ALK config-source manifest changed")

        def on_started(event: dict[str, Any]) -> None:
            verify_prestart_raw_inventory(
                root, inventory_path=inventory_path, pending_path=pending_path,
                state=state, plan_digest=plan_digest)
            _require(event["commandIdentityHash"] == intent["commandIdentityHash"]
                     and event.get("argv") == argv
                     and event.get("cwd") == str(root)
                     and event.get("environmentSha256")
                     == canonical_digest({**selected_env, "CODEX_HOME": codex_home})
                     and event["plannedStdinSha256"] == final_sha
                     and event["plannedStdinBytes"] == len(final_raw)
                     and event["codexHome"] == codex_home
                     and _snapshot_digest(Path(codex_home), root=root) == snapshot_digest,
                     "codex-exact-start-mismatch", "observed child differs from prelaunch intent")
            body = {**intent, "schemaVersion":"alk-codex-process-start.v1",
                    "hostLaunchStarted":True, "observedPid":event["pid"],
                    "processIdentityHash":event["processIdentityHash"],
                    "groupIdentityHash":event["groupIdentityHash"],
                    "observedArgv": event["argv"],
                    "observedCwd": event["cwd"],
                    "observedCodexHome": event["codexHome"],
                    "observedEnvironmentSha256": event["environmentSha256"],
                    "observedConfigSourceSha256": config_manifest_sha,
                    "observedCodexHomeContentDigest": snapshot_digest,
                    "childInternalEffectiveConfig": "UNPROVEN",
                    "stdinStatus":"PENDING"}
            _replace_reserved(start_path, body, root=root)

        def on_input(event: dict[str, Any]) -> None:
            body = {"schemaVersion":"alk-codex-process-input.v1", "runId":run_id,
                    "taskId":task_id, "attemptId":attempt_id, "role":request.get("role"),
                    "routeId":ROUTE_ID, "requestedClaim":CLAIM, "planDigest":plan_digest,
                    "packetSha256":request["packetSha256"], "finalPromptSha256":final_sha,
                    **event}
            _replace_reserved(input_path, body, root=root)
            _record_transport_witness(
                root, evidence, run_id=run_id, task_id=task_id,
                attempt_id=attempt_id, role=str(request.get("role")),
                final_sha=final_sha, config_manifest_sha=config_manifest_sha,
                diagnostic=diagnostic, event=event)
            _require(event["status"] == "COMPLETE" and event["acceptedBytes"] == len(final_raw)
                     and event["acceptedSha256"] == final_sha and event["closeSucceeded"] is True,
                     "codex-exact-input-incomplete", "OS pipe did not accept complete final prompt")

        return {"argv":argv, "stdinText":final_raw.decode("utf-8"),
                "codexHome":codex_home, "onStarted":on_started, "onInput":on_input,
                "verifyBeforeStart":verify_before_start,
                "sealedRequest":sealed, "sealedSha256":_sha(canonical_bytes(request)),
                "finalPromptSha256":final_sha, "fitReceiptDigest":fit["receiptDigest"],
                "startReceiptPath":start_path, "inputReceiptPath":input_path,
                "rawInventoryPath": inventory_path, "rawCleanupPendingPath": pending_path,
                "runId":run_id, "taskId":task_id, "attemptId":attempt_id,
                "role":request.get("role")}
    except Exception:
        if sealed is None:
            # An earlier invocation may own this attempt's sealed raw. This
            # invocation can remove only its own unsealed staging request.
            cleanup_no_start(root, None, Path(input_request))
        else:
            for path in reserved:
                path.unlink(missing_ok=True)
            cleanup_prestart_raw(
                root, run_id=run_id, task_id=task_id, attempt_id=attempt_id,
                staging_source=Path(input_request), proven_no_start=True)
        raise
