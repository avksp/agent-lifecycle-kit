"""Public bounded process boundary with decomposed capture and receipt helpers."""

from __future__ import annotations

import hashlib
import os
import select
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, Callable

from agent_lifecycle.adapter_sessions.process_capture import _CaptureState, _write_stdin
from agent_lifecycle.adapter_sessions.process_control import (
    DEFAULT_CLEANUP_GRACE_SECONDS,
    DEFAULT_OUTPUT_BYTES,
    _bounded_failure,
    _build_process_result,
    _invalid_limit_failure,
)
from agent_lifecycle.adapter_sessions.process_groups import ProcessGroupOwner, popen_group_kwargs
from agent_lifecycle.adapter_sessions.process_telemetry import ProcessTelemetry
from agent_lifecycle.contracts import canonical_digest


def run_process(
    argv: list[str],
    *,
    env: dict[str, str],
    timeout_seconds: float,
    cwd: Path | None = None,
    stdin_text: str | None = None,
    max_input_bytes: int | None = None,
    max_output_bytes: int | None = None,
    operation_id: str | None = None,
    attempt_id: str | None = None,
    adapter_id: str | None = None,
    cancel_event: threading.Event | None = None,
    cleanup_grace_seconds: float = DEFAULT_CLEANUP_GRACE_SECONDS,
    retry: dict[str, Any] | None = None,
    on_started: Callable[[dict[str, Any]], None] | None = None,
    on_input: Callable[[dict[str, Any]], None] | None = None,
) -> dict[str, Any]:
    """Run one shell-free child while retaining bounded cleanup and receipts."""

    input_bytes = (stdin_text or "").encode("utf-8")
    output_limit = max_output_bytes if max_output_bytes is not None else DEFAULT_OUTPUT_BYTES
    from agent_lifecycle.contracts.process_execution_schemas import command_identity_hash

    command_hash = command_identity_hash(argv)
    invalid = _invalid_limit_failure(
        input_bytes=input_bytes,
        output_limit=output_limit,
        max_input_bytes=max_input_bytes,
        command_hash=command_hash,
        operation_id=operation_id,
        attempt_id=attempt_id,
        adapter_id=adapter_id,
        retry=retry,
    )
    if invalid is not None:
        return invalid
    if (on_started is None) != (on_input is None):
        return _bounded_failure(
            "adapter-process-observation-incomplete",
            input_bytes=len(input_bytes), output_bytes=0, process_started=False,
            details={}, command_hash=command_hash, operation_id=operation_id,
            attempt_id=attempt_id, adapter_id=adapter_id, retry=retry,
        )
    try:
        process = subprocess.Popen(
            argv,
            shell=False,
            env=env,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=cwd,
            **popen_group_kwargs(),
        )
    except OSError as exc:
        return _bounded_failure(
            "adapter-process-start-failed",
            input_bytes=len(input_bytes),
            output_bytes=0,
            process_started=False,
            details={"errorType": type(exc).__name__},
            command_hash=command_hash,
            operation_id=operation_id,
            attempt_id=attempt_id,
            adapter_id=adapter_id,
            retry=retry,
        )

    owner = ProcessGroupOwner(process)
    telemetry = ProcessTelemetry(pid=process.pid, group_id=owner.group_id)
    process_hash = _process_identity_hash(process.pid, telemetry.started_ns)
    group_hash = canonical_digest({"mode": owner.mode, "processIdentityHash": process_hash})
    capture = _CaptureState(output_limit)
    start_observation: dict[str, Any] | None = None
    input_observation: dict[str, Any] | None = None
    if on_started is not None:
        start_observation = {
            "pid": process.pid, "processIdentityHash": process_hash,
            "groupIdentityHash": group_hash, "commandIdentityHash": command_hash,
            "argv": list(argv), "cwd": str(cwd) if cwd is not None else None,
            "codexHome": env.get("CODEX_HOME"),
            "environmentSha256": canonical_digest(env),
            "plannedStdinBytes": len(input_bytes),
            "plannedStdinSha256": hashlib.sha256(input_bytes).hexdigest(),
            "stdinStatus": "PENDING", "operationId": operation_id,
            "attemptId": attempt_id, "adapterId": adapter_id,
        }
        try:
            on_started(start_observation)
        except Exception as exc:
            return _observed_failure(process, owner, capture, command_hash, process_hash,
                                     group_hash, input_bytes, output_limit, timeout_seconds,
                                     cleanup_grace_seconds, operation_id, attempt_id, adapter_id,
                                     retry, "adapter-process-start-observation-failed", exc,
                                     start_observation, None)
    readers = capture.start(process)
    if on_input is None:
        _write_stdin(process, input_bytes)
    else:
        input_observation = _write_observed_stdin(process, input_bytes, timeout_seconds,
                                                  telemetry.started_ns / 1_000_000_000,
                                                  cancel_event, operation_id, attempt_id, adapter_id,
                                                  process_hash)
        try:
            on_input(input_observation)
        except Exception as exc:
            return _observed_failure(process, owner, capture, command_hash, process_hash,
                                     group_hash, input_bytes, output_limit, timeout_seconds,
                                     cleanup_grace_seconds, operation_id, attempt_id, adapter_id,
                                     retry, "adapter-process-input-observation-failed", exc,
                                     start_observation, input_observation, readers)
        if input_observation["status"] != "COMPLETE":
            return _observed_failure(process, owner, capture, command_hash, process_hash,
                                     group_hash, input_bytes, output_limit, timeout_seconds,
                                     cleanup_grace_seconds, operation_id, attempt_id, adapter_id,
                                     retry, "adapter-process-input-incomplete", None,
                                     start_observation, input_observation, readers)
    timed_out = False
    cancelled = False
    while process.poll() is None:
        telemetry.sample()
        if capture.output_limit_exceeded.is_set():
            break
        if cancel_event is not None and cancel_event.is_set():
            cancelled = True
            break
        elapsed = time.monotonic() - telemetry.started_ns / 1_000_000_000
        if elapsed >= max(0.01, timeout_seconds):
            timed_out = True
            break
        time.sleep(0.02)
    if process.poll() is None:
        cleanup = owner.terminate(grace_seconds=max(0.05, cleanup_grace_seconds))
    else:
        process.wait()
        cleanup = owner.verify()
        if cleanup.get("status") != "PASS":
            cleanup = owner.terminate(grace_seconds=max(0.05, cleanup_grace_seconds))
    capture.finish(process, readers, cleanup_grace_seconds)
    telemetry_values = telemetry.finish()
    result = _build_process_result(
        process,
        capture=capture,
        telemetry_values=telemetry_values,
        cleanup=cleanup,
        timed_out=timed_out,
        cancelled=cancelled,
        timeout_seconds=timeout_seconds,
        output_limit=output_limit,
        max_input_bytes=max_input_bytes,
        input_bytes=input_bytes,
        command_hash=command_hash,
        process_hash=process_hash,
        group_hash=group_hash,
        operation_id=operation_id,
        attempt_id=attempt_id,
        adapter_id=adapter_id,
        retry=retry,
        cleanup_grace_seconds=cleanup_grace_seconds,
    )
    owner.close()
    if start_observation is not None:
        result["startObservation"] = _public_start_observation(start_observation)
        result["inputObservation"] = input_observation
    return result


def _write_observed_stdin(
    process: subprocess.Popen[Any], data: bytes, timeout_seconds: float,
    started_at_monotonic: float,
    cancel_event: threading.Event | None, operation_id: str | None,
    attempt_id: str | None, adapter_id: str | None, process_hash: str,
) -> dict[str, Any]:
    """Measure bytes accepted by the OS pipe; this is not host consumption."""
    accepted = hashlib.sha256()
    count = 0
    error: str | None = None
    close_ok = False
    deadline = started_at_monotonic + max(0.01, timeout_seconds)
    stream = process.stdin
    if stream is None:
        error = "stdin-unavailable"
    else:
        try:
            fd = stream.fileno()
            os.set_blocking(fd, False)
            while count < len(data):
                if (cancel_event is not None and cancel_event.is_set()) or time.monotonic() >= deadline:
                    error = "cancelled-or-timeout"
                    break
                if not select.select([], [fd], [], min(0.02, max(0.0, deadline - time.monotonic())))[1]:
                    continue
                try:
                    written = os.write(fd, data[count:count + 8192])
                except BlockingIOError:
                    continue
                if written <= 0:
                    error = "short-write"
                    break
                accepted.update(data[count:count + written])
                count += written
        except (BrokenPipeError, OSError) as exc:
            error = type(exc).__name__
        try:
            stream.close()
            close_ok = True
        except OSError as exc:
            error = error or type(exc).__name__
    return {
        "status": "COMPLETE" if count == len(data) and close_ok and error is None else "PARTIAL_OR_FAILED",
        "acceptedBytes": count, "acceptedSha256": accepted.hexdigest(),
        "expectedBytes": len(data), "closeSucceeded": close_ok, "errorType": error,
        "processIdentityHash": process_hash, "operationId": operation_id,
        "attemptId": attempt_id, "adapterId": adapter_id,
        "hostConsumptionProven": False,
    }


def _observed_failure(
    process: subprocess.Popen[Any], owner: ProcessGroupOwner, capture: _CaptureState,
    command_hash: str, process_hash: str, group_hash: str, input_bytes: bytes,
    output_limit: int, timeout_seconds: float, cleanup_grace_seconds: float,
    operation_id: str | None, attempt_id: str | None, adapter_id: str | None,
    retry: dict[str, Any] | None, code: str, error: Exception | None,
    start_observation: dict[str, Any] | None, input_observation: dict[str, Any] | None,
    readers: list[threading.Thread] | None = None,
) -> dict[str, Any]:
    if readers is None:
        readers = capture.start(process)
    if process.stdin is not None and not process.stdin.closed:
        try:
            process.stdin.close()
        except OSError:
            pass
    cleanup = owner.terminate(grace_seconds=max(0.05, cleanup_grace_seconds))
    capture.finish(process, readers, cleanup_grace_seconds)
    result = _build_process_result(
        process, capture=capture,
        telemetry_values=ProcessTelemetry(pid=process.pid, group_id=owner.group_id).finish(),
        cleanup=cleanup, timed_out=False, cancelled=False,
        timeout_seconds=timeout_seconds, output_limit=output_limit, max_input_bytes=None,
        input_bytes=input_bytes, command_hash=command_hash, process_hash=process_hash,
        group_hash=group_hash, operation_id=operation_id, attempt_id=attempt_id,
        adapter_id=adapter_id, retry=retry, cleanup_grace_seconds=cleanup_grace_seconds,
    )
    result["status"] = "FAIL" if cleanup.get("status") == "PASS" else "BLOCKED"
    result["processReceipt"] = None
    result["blockers"].append({"code": code, "errorType": type(error).__name__ if error else None,
                                "costStatus": "UNAVAILABLE"})
    result["startObservation"] = _public_start_observation(start_observation) if start_observation else None
    result["inputObservation"] = input_observation
    result["startedFailure"] = True
    owner.close()
    return result


def _public_start_observation(value: dict[str, Any]) -> dict[str, Any]:
    return {key: value[key] for key in (
        "processIdentityHash", "groupIdentityHash", "commandIdentityHash",
        "plannedStdinBytes", "plannedStdinSha256", "stdinStatus",
        "operationId", "attemptId", "adapterId",
    )}


def _process_identity_hash(pid: int, started_ns: int) -> str:
    from agent_lifecycle.contracts.process_execution_schemas import process_identity_hash

    return process_identity_hash(pid=pid, started_ns=started_ns)
