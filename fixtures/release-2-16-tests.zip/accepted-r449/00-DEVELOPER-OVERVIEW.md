# Release 2.16 ordinary audit successor

The user approved r448/A: keep independent source and integration review, stop
making an unqualified custom R11 evidence transport a prerequisite for the release.
The current native launcher explicitly requires that transport's fresh composite.
Replace that proof seam with a bounded ordinary review record and fresh task/source
checks. Disable the experimental route, preserve actual runtime protections.

What users gain: a release route based on independent review of actual ALK code
through existing adapter capabilities. What is no longer promised: automatic proof
that every source byte and call was seen by a model inside one special request.
This does not add protected closure or full Codex input/accounting guarantees.

This package is an S2 specification amendment. Product implementation is forbidden
until a coherent reviewed successor plan is frozen. The current execution checkout,
its83 locked entries,1330 indexed sources and all old evidence stay unchanged.
No repeat graph/packing experiment is needed. Existing goal and budget authorization
continue; no new product clarification is needed for the approved scope.

Keep the change small: ordinary report/verifier, existing preflight seam, explicit
experimental denial, affected tests, exact authority migration. No new queue,
general packing engine, host modification or external service. The risks to review
are false admission from stale/procedural evidence, accidentally removing runtime
requirements with protocol tests, leaving a legacy worker bypass, and resetting
cost/history during migration. SPECIFICATION.md addresses them explicitly.
