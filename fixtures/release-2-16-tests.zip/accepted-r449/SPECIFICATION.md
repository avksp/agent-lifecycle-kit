# Ordinary independent audit for Release 2.16

Status: S2 specification candidate, not frozen authority or implementation approval.
Authority for the scope change: the user's explicit r448/A answer, recorded in
USER-DECISION.json. r448/A replaces the retained automatic full byte/call/pair
transport proof; it does not simply rename the old r443/A modular transport.

## Outcome and boundaries

Release 2.16 proceeds through independent review of fixed source scopes and final
integration, using existing host file-reading capabilities. It no longer requires
building the special R11 SHARED/SOURCE transport, deterministic raw-host composite
and all-thread freshness reader before the first native task. The unqualified
experimental route is disabled. All other product, host, task and release gates
remain. This is ordinary procedural review evidence, not protected closure or a
proof of every byte delivered to the model.

R01 — Keep the five collector source areas from approved r443/A, the observer/
terminal area, and an independent final integration review. The scope assignment
must name exact current files, changed implementation/tests, relevant dependencies
and cross-area obligations. Include all current bootstrap WIP; no required file or
interaction may be omitted merely because the old transport is disabled. The final
review inspects the actual start/observe/collect/close/native sequence and every
accepted area result. An unavailable or incomplete review is INCOMPLETE, never PASS.

R02 — Coordinator publication uses actual independently returned review results
from the existing host, retaining the original result bytes and available review
trace. The reviewer is different from the implementation author/coordinator for
that scope; final integration is a separate invocation and depends on every area.
The coordinator checks the result against the actual observed tool response, not
an author-provided JSON claiming PASS. Publication records host/session/invocation
identity, raw digest, assigned scope and source digests. Runtime verification checks
these persisted joins. Since the same OS account can rewrite them, this is an
explicit procedural trust boundary, not an unforgeable origin/identity guarantee.
No new host API, external service, OS account or key is required. Unsupported
protected-close claims continue to refuse under the existing capability policy.

R03 — Capture a sorted file inventory with normalized root-relative paths, regular
file type, UTF-8 byte length and SHA-256 before review and immediately before
acceptance. Source documents are data, not instructions. Every assigned file and
boundary obligation appears in the review coverage declaration. A declaration
describes the independent audit's coverage; it is not proof of host context or raw
delivery. Missing/extra/duplicate coverage, changed input, absent actual review,
FAIL, INCOMPLETE, open HIGH/MEDIUM findings or unresolved required obligations deny.
LOW findings require an explicit existing-policy disposition, not silent loss.

R04 — A review subject binds the frozen plan digest and raw lock digest, applicable
audit-policy digest, scope membership, source/dependency digests and requirement/
test-case applicability. Area reports bind their assigned subsets. Integration
binds an exact ordered set of area report/raw-result digests and the current union.
Accepted area evidence may be reused only when its complete source/dependency and
requirement inputs are identical and its actual origin/verdict remain valid. A
changed source invalidates affected areas and dependent integration, not every
unrelated successful audit. No parent negative verdict is inherited as positive.

R05 — Before native spawn, the existing `require_bootstrap_audit` seam delegates
to the ordinary-audit verifier selected by the installed successor policy. It
checks current manifest/lock/policy, current source/coverage, all area approvals,
integration approval, applicable test evidence and the existing reserved task/run/
attempt/operation intent and selected executable/profile identity. The ordinary
audit may review a general bootstrap source state; a separately produced fresh
gate receipt binds that accepted result to this actual task attempt and current
binary/profile. It is not permission for arbitrary future tasks. Re-read the
authority/source/task/financial inputs at the last pre-spawn boundary; any race,
unknown input or stale join denies and uses existing prestart cleanup. No callback,
caller-provided success flag, old R11 VERIFIED or fallback to another route grants
admission. Preserve explicit Codex route/claim, LIMITED ALK input admission,
qualified stdin/process observation and all other launcher gates. Other adapters
retain their previously approved capability boundaries.

R06 — Active special transport producers, funders, dispatchers, composite
publishers/installers and fresh-host readers refuse with a stable
`r11-experimental-disabled` error before mutation, reservation, thread/model start
or native grant. Public wrappers and directly reachable internal worker/supervisor
entrypoints need coverage, including helper calls that bypass a public wrapper.
Read-only historical inspection, source-analysis helpers, coordinator cost-head
accounting and attempt terminal-state primitives are not disabled by name pattern.
Their exact allow/deny inventory must be derived from code and reviewed in the
successor plan. No environment flag, copied old receipt or legacy contract may
re-enable the experimental path. Future re-enablement requires a separately
reviewed authority; this release does not implement it.

R07 — Do not rewrite existing expenses, held unknown usage, attempts or review
history. Preserve actual/null distinctions, reserve-before-start, finite budgets,
original absolute deadlines, no automatic retries and no late upgrade of DENY.
Preserve the current coordinator ledger and its parent ancestry across authority
migration; do not require opening another experimental R11 batch just to record
ordinary review cost. Existing limits are ceilings, not an obligation to spend:
max33 review invocations, per-role360000 tokens/reserve100000,1800 seconds; batch
11880000 tokens/59400 seconds; one start per admitted role. Initial/current ALK
requests retain245760 bytes,8192 output reserve and16384 context safety where the
existing supported limited check applies. File reads use bounded host operations
within the same finite role budget. Unavailable total host input/usage remains
UNAVAILABLE; these numbers do not become an enforcement claim about hidden host
context. Retries need an explicit scoped admission and invalidate only affected
evidence, with the previous spend retained.

R08 — The observer/timeout defect remains mandatory: terminal attempt state,
absolute deadlines, no uncertain-start retry and no late callback/result promotion
must be verified on actual affected paths. `r362 FAIL` remains immutable. Its open
finding closes only through applicable regression evidence and a new independent
finding disposition; changing the proof route does not close it. Retention remains
30 days after full close, scheduled ALK maintenance, with original applicability
and filesystem requirements. H04, A5 and protected closing retain the user's
capability-scoped decisions and all applicable positive/refusal proofs.

R09 — C34/C35 membership and selectors must be migrated explicitly. Every current
case is classified as (a) retained product/runtime regression, (b) replaced proof-
protocol assertion with named successor case, or (c) experimental-only test whose
route is disabled and tested for refusal. Do not label all96/16 old cases PASS or
N/A. Native-positive, accounting, process, input-fit, crash/recovery and retention
requirements survive. New tests must exercise missing/forged-by-author publication,
changed-source/task/lock/profile/financial joins, affected-evidence reuse,
integration omissions, timeout/late-result denial and every disabled dispatch
entrypoint. Historical test evidence stays with its original source identity.

R10 — One successor package replaces every active manifest/route/delivery/schema/
validation/roster/ownership/native selector consistently. Old contracts, oracles,
schemas and accepted-r412 artifacts may remain byte-identical historical inputs;
they cannot be active authority for the ordinary route. Use explicit typed field
migration and a check for forbidden old active selectors, not a prose override or
global text substitution. The retained launch transport, retention maintenance,
limited-fit and task DAG must not be removed with the old audit-delivery block.
Before reviewed installation, r69q and native DENY remain in force.

R11 — Keep immutable authority, mutable run results and implementation separate.
Use the existing private/no-follow authority I/O and canonical hashing utilities;
do not build another general review orchestrator/packing engine. The ordinary
receipt stores scope/result/provenance joins and a fresh task decision only.
Plan/lock review never constitutes implementation, host or release PASS. Freeze
and installation must reject absent or mismatched independent plan approval.

R12 — Final release requires applicable product tests, independent area and
integration audits, task/native proofs, adapter capability/refusal evidence,
retention and platform/package checks and final audit. This amendment only changes
the special review transport obligation. Actual remaining requirements are taken
from the preserved release plan, not inferred complete from this specification.

## Minimal implementation boundary

Add one small ordinary-audit module and its tests; use the existing Codex
`require_bootstrap_audit` and shared preflight seam to call it. Retain process/
attempt primitives and accounting machinery. Disable the experimental invocation
surface in `bootstrap_r11.py`; do not delete historical evidence or refactor the
entire collector. Update affected existing tests and documentation. All changes
stay inside ALK, under one serial lead grant that expires before WS216-01 and then
belongs to WS216-02. No concurrent overlapping author/reviewer writes.

## Acceptance and evidence

The companion CONTRACT.json maps each requirement to an acceptance, proposed
owned change and evidence output. MIGRATION-INVENTORY.json records current live
top-level selector families and exact hashes; it is an input to the successor,
not a claim that every leaf has already been rewritten. Before freeze, the exact
full manifest, test-case disposition, API allow/deny inventory and actual field
patches must exist and receive plan review. This specification review can authorize
drafting that package; it cannot freeze an incomplete migration.
