# Release 2.16.0 notes draft

## Revision69b corrected DRAFT — exact limited native qualification

The active current-Codex profile and all three 16k workstream selectors use `ALK_CONTROLLED_OUTBOUND_INPUT_FIT` only. The retained config artifact binds credential-free ALK-controlled source bytes/SHA; Codex internal effective-config equality remains `UNPROVEN` for this claim. `route-bootstrap-contract.json#validation.limitedNativeMatrix` is the executable 24-row, six-role evidence contract: a separately admitted maximum of six selected Codex positive calls, 12 predispatch refusals without a model and six controlled local started-failure fixtures. Each row binds role, polarity, command template, producer, oracle, run/task/attempt/claim/lock and receipt path. Local fault rows cannot count as selected Codex native positive; original strong IF09/IF12 remain `NOT_RUN` for this limited profile. The exact r69b preview and review/lock are still pending; r68e remains installed authority and native WS01 is `DENY`.

## Revision69 current DRAFT — current-Codex limited outbound proof

This isolated plan candidate has parent r68e verified lock SHA `a619308da56efc1fe0c23a65de9b8c04074e79e93d7247f02958b5a831af6c66` and accepted S2 specification SHA `c69a24fa6170ba4a509048c2d4cf218f970f793431bc2cce6e08ce8687dec018`. It is not reviewed or locked. All historical revision paragraphs below describe their then-current states; the r69 rules in `route-bootstrap-contract.json#limitedFitApplicability` and `alk-input-fit-contract.json#r69FitDisposition` govern this candidate. r68e remains installed authority; native WS01 DENY, Release NOT_READY.

The proposed current-Codex positive claim covers only ALK-constructed bytes accepted by the OS stdin pipe associated with the selected child, not model-visible input or child consumption. Per-role fresh diagnostic and catalog are prelaunch candidates, not future native equivalence. Strong host-fit/financial requests refuse before dispatch. After observed Popen, only complete same-attempt pipe write/close plus joined native success/usage can pass the new limited case; failure retains unknown cost. Original strong IF09/IF12 remain NOT_RUN for this limited profile. All other accounting, H05/A5, 12-adapter, privacy, 30-day cleanup, hourly scheduler, security/platform/publication and final-audit gates remain.


## Draft r61 Codex scoped-route disclosure

If separately qualified, the ALK-owned exact-prompt Codex route may report only ALK_CONTROLLED_INPUT_FIT for its reviewed version/mode. Host-owned input and U are excluded; stronger claims refuse. This DRAFT is not a shipped feature or release approval.

## Draft 2.16 Codex input-fit scope disclosure

If r58 is independently accepted and its native cases pass, the current Codex route may report `ALK_CONTROLLED_INPUT_FIT`: ALK-selected input components are bounded and checked before dispatch. Complete host request 16k fit, hidden history/tool/format tokens, provider output enforcement and whole-call financial bounds are not claimed. Stronger requests refuse. This is planned release wording, not a shipped capability or PASS result.

## Revision52 prepared FROZEN-shape candidate — Choice B current-Codex capability-scoped closing

The user selected Choice B. On the current full-access Codex route ALK must refuse protected adoption, root/epoch-0 publication, closing activation/grant and protected dispatch before write or process start. Positive CC04–CC16, DS14, DA15 and joined DS/DA/DR/DD cases remain NOT_RUN/UNPROVEN under their original IDs; distinct OR01–OR19 native negatives and independently reviewed applicability are required for a limited release. All 53 retained WS01 local cases, CC01–CC03, late settlement, H04/H05, A5 for all12 adapters, platform/security/publication and numeric caps remain mandatory. A qualified future route must pass the original positive native cases before enabling protected closing. This prepared candidate has no accepting review, lock, native proof, task acceptance or release permission; r48 remains current.


## Revision22 — A5 according to existing host capabilities

User-approved scope: strong A5 is enabled only for an existing route with proven
continuous input protection. Other routes refuse that mode and may meet release
acceptance with a reviewed limitation plus actual source-bound refusal proof.
The positive A5 invariant is unchanged; no endpoint-hash fallback, silent downgrade
or immutable-input/write-scope exemption is allowed on a limited route. Ordinary
source/result/ownership/audit and independently required security/validity checks
remain mandatory; any operation requiring unavailable protection remains refused.

`cf01-a5-capability-scope.json` is the normative applicability authority for all12
adapter routes. Older unconditional A5 prerequisite statements below apply to the
STRONG_A5 branch; limited routes instead require a complete refusal integration
contract before freeze and actual route/consumer qualification before release.
H04 support does not establish A5 support. Unknown remains UNPROVEN, not PASS.
The accepted r19/r20/r21 design is retained. This r22 amendment needs scoped
independent review; full candidate readiness, H05, actual fit and all implementation,
storage/platform/final release gates remain open. Historical revision narratives
below are retained as history and do not override this current applicability rule.

## Revision 12 — reviewed findings and current authority

r11 full-plan independent review returned CHANGES_REQUIRED (3 High,4 Medium).
r12 addresses S2-R11-H01/H02/M01/M02 in DRAFT; these are author corrections,
not independently closed findings. h04-artifact-contracts.json defines closed
artifact/request/result types, immutable expectation joins, exact comparison and
refusal rules, bounded producers and qualification milestones. The profile-case
file maps all21 profile oracles and all13 original core/native assertions.
WS01 produces pure resolver proof in its own EV; WS02 produces exact-final-profile
refusal after integration. Expected bindings are explicitly UNPINNED, not PASS.
Before freeze populate and independently review all12 exact target/source/claim
and recipe expectations. Runtime qualification follows implementation and precedes
release. Existing CF02/CF01 transitive design, H05 independent coverage and actual
packet/budget fit remain open; no lock, execution or release approval exists.
Full H04 on current Codex remains optional; all12 scoped profile acceptance remains
mandatory. Earlier revision text is historical where it conflicts with this block.

## Revision 11 — current H04 authority

DRAFT. The user removed mandatory full H04 in current Codex. [h04-adapter-boundaries.md](h04-adapter-boundaries.md), h04-adapter-profile-cases.json and manifest revision11 control adapter-specific acceptance for all12. Every accepted profile requires both applicable capability/limitation evidence and exact-profile ALK resolver refusal proof. FULL_FINANCIAL remains strict but optional per supported profile. Earlier conflicting H04 statements below are historical; other release gates and original evidence remain unchanged. Independent specification review permits migration only; full-plan review, implementation and runtime qualification remain pending.


Planned: exact typed evidence-to-ID matching; shared strict audit validation;
source/configuration/oracle-bound evidence; honest reviewer provenance; lossless
validated raw review import with unknown usage preserved. Canonical receipt and
guarantee changes include explicit compatibility/migration guidance.

Revision 4 is a DRAFT rebased on v2.15.0. Implementation and production readiness
are not claimed. Full retained gates and independent acceptance remain required.

Planning revision 7 proposes versioned evidence receipts and a distinct lossless raw/v2 review import contract. These are unimplemented DRAFT changes; attestation integration and independent freeze review remain pending.

Planning revision 7 specifies proposed reviewer attestation verification using existing Ed25519, a pinned issuer policy and exact reviewer/session/assignment/subject claims. Production trust-context integration and independent review remain pending.

Draft revision 7 specifies native provenance rejection and phase mapping. A test-authority verifier PASS does not qualify native ATTESTED operation; production issuer/caller integration remains deferred pending independent scope review.

Draft revision 9 separates per-workstream command evidence from the retained final release gates and aligns provenance acceptance with TEST_AUTHORITY-only verifier success and native ATTESTED rejection. These planning corrections remain subject to independent review.

Planning revision 9 defines source-pinned runtime activation before the first
acceptance and exact independent-review/native-lock preparation. These are pending
plan contracts, not shipped runtime or review evidence.


## Revision-10 controlling accounting/recovery amendment

Revision10 is DRAFT. release-prerequisites.md and the manifest define the added minimal accounting/recovery scope, serial ownership, prospective token ceilings and unresolved prerequisites. accounting-and-recovery-cases.json retains original H04 AC01–AC13 and CF CC01–CC16. All earlier unchanged-scope/cap statements apply to their historical revisions; original acceptance, command, quality/security and publication gates remain. This amendment is not an accepting review, implementation proof, freeze or native authorization.
