> **r69k R10 FROZEN shape pending exact review.** r352 independently accepted the corrected 50-file DRAFT subject (body SHA `93cecf316b40a6564bf877bb5f3d253544f6c0576116c78a05b49088013e8079`) with fullReview=true and no findings. This candidate changes only status, review metadata and top historical notices; the FROZEN-shape report and canonical lock are absent. The verified installed r69j parent lock `c96f464a845c7e69a4fd08af705d55cffb3a4db328cf1eb5a1eef17b9d4d894b` remains authority. Older notices and DRAFT text below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69k R10 isolated DRAFT; independent plan S2 pending.** r348 independently accepted corrected R10 specification SHA `14e5fbba22aa6258ba051abccffec3a0b07b97a9e7174d20491889dbaa43bfda` for plan drafting only. This candidate raises the one-turn request cap to 245760 bytes and binds r69k successor to verified r69j parent. The installed r69j lock `c96f464a845c7e69a4fd08af705d55cffb3a4db328cf1eb5a1eef17b9d4d894b` remains authority; r69k has no independent plan review or lock. Older notices below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69j R9 FROZEN shape pending exact review.** r333 independently accepted the exact corrected DRAFT subject (raw reviewer body SHA `858e61c9211e114ed3392f1dd8425654857265e573b6a09312e4a6a98dededa2`) and closed R331-S2-M01. This candidate changes only status, review metadata and top historical notices; the FROZEN-shape report and canonical lock are absent. Older notices below are historical. Installed r69i parent lock `721d7e3fa60723d59708efddfe2166347af5abc0981d47153527b00382f0bd67` remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69j R9 isolated DRAFT; independent plan S2 pending.** r329 accepted exact R9 specification SHA `965d2c4c02d4dc80b9538288355294391feb94a0f3bd1e6899c0a3b070bf5d03` for plan drafting only. Candidate v3 support oracle `671ed21d004beedecb80e1785a478e1eb95375a3593df3cd0a731a0151a3b84e` and v8 source oracle `d19e5edb56f4908c949f4239763038915f27798f54e8cdbbc13db6a361f93834` are not installed. Parent r69i verified lock `721d7e3fa60723d59708efddfe2166347af5abc0981d47153527b00382f0bd67` remains installed in execution57. No r69j plan-review report or lock exists; WS216-01 native DENY and Release NOT_READY. Older notices below are historical.

> **r69i R8-R3 FROZEN shape pending exact review.** r301 independently accepted the exact DRAFT subject (raw reviewer body SHA `f96bbe126d9f2dd7bbcf996608a4cbf978d9ff8c39227deab75453878f4ab9fd`). This candidate changes only status, review metadata and top historical notices; its future independent report path is declared but the FROZEN-shape report and canonical lock are absent. Older DRAFT notices below are historical. Installed r69h lock `a1d7a69a05f5887b72165613ebb116bf59f2bf52b59d6f851c66b977c284976c` remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69i R8-R3 isolated DRAFT; independent plan S2 pending.** r299 independently accepted exact R8-R3 specification SHA `bef13eb0608b604ffb88a659abe8b0d940046b52ff5ca2f732eecd48ed924cb7` and source oracle SHA `5f7b3cee3f074ebfbf4129bd4058d38116ef8385be20e6fbcd965158bc07a4fe` for plan drafting only. This candidate overlays the `codex_exact_prompt.py` FULL-source row with typed AST slices and local dependency closure; all other R7/v6 requirements remain. Parent r69h verified lock `a1d7a69a05f5887b72165613ebb116bf59f2bf52b59d6f851c66b977c284976c` stays installed in execution57. This r69i candidate has no plan-review report or lock; WS216-01 native DENY and Release NOT_READY. Older r69h/r69g notices below are historical.

> **r69h R7 FROZEN shape pending exact review.** r288 independently accepted the prior DRAFT subject (raw reviewer body SHA `1a5a331060a81d40e9be6a366856ad4742004567520d91526883485ccd4e6399`). This candidate changes only status, review metadata and overview notices; its future independent report path is declared but the FROZEN-shape report and canonical lock are absent. The older DRAFT notice below is historical. Installed r69g remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69h isolated R7 DRAFT — current delivery authority.** r286 independently accepted R7 specification SHA `b54ebc77c4cc89aed0d809a4d193a15a61e7132a651f6db18f6dc98051732ab1` and oracle v6 SHA `aa25670dc55f6c1fb28ba249b9f24dc6115e470e13e0a6d75166ed2023edb702` for plan drafting only. The copied specification preserves its historical pre-adoption status; this candidate now pins R7/v6. Installed r69g lock `673715e292661c13b6d9c7222434d60b2c0247a54a61d45cf5bd3861c3043a99` remains authoritative. r282's R5/v4 DRAFT review was CHANGES_REQUIRED; this amended DRAFT has no independent plan acceptance or lock. Older delivery notices below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69g FROZEN shape pending exact review.** r254 independently accepted the prior DRAFT subject (raw reviewer body SHA 023d7fd1873d6094ef474f6ddc68e908fc28cc5dbf62e3d0f2891707fbeb58a4). This FROZEN-shaped candidate changes status/review metadata and overview notices only; its report path is declared but the independent FROZEN-shape report and canonical lock are absent. Older DRAFT notices below are historical. Installed r69f remains authoritative; WS216-01 native is DENY.

> **r69g DRAFT delivery successor.** Installed r69f lock SHA 45a280b5dfc5e83e88d6c1f4d635b9ace7e5d1adaf3f9795a1215288bfe54dd5 remains authoritative. Exact independently READY_TO_DRAFT S2 specification SHA 6e7981627ffa616a7fabba856dca343e6f43c5eeda773d0eb87a572bdc7a0e1a is copied as `review-delivery-spec.md`. The current candidate replaces the reviewer-body producer with a same-thread `turn/start.outputSchema` item after `review/start` text; it requires the clean sentinel, full-subject saved request, dual-item collector/fresh read and unchanged PRE limits. Older r69 review-delivery paragraphs below describe historical candidates and do not override `route-bootstrap-contract.json#auditJoin.delivery`. No native WS216-01 from this DRAFT.

# Scope decisions, revision 7

## Revision69 current DRAFT — current-Codex limited outbound proof

This isolated plan candidate has parent r68e verified lock SHA `a619308da56efc1fe0c23a65de9b8c04074e79e93d7247f02958b5a831af6c66` and accepted S2 specification SHA `c69a24fa6170ba4a509048c2d4cf218f970f793431bc2cce6e08ce8687dec018`. It is not reviewed or locked. All historical revision paragraphs below describe their then-current states; the r69 rules in `route-bootstrap-contract.json#limitedFitApplicability` and `alk-input-fit-contract.json#r69FitDisposition` govern this candidate. r68e remains installed authority; native WS01 DENY, Release NOT_READY.

The proposed current-Codex positive claim covers only ALK-constructed bytes accepted by the OS stdin pipe associated with the selected child, not model-visible input or child consumption. Per-role fresh diagnostic and catalog are prelaunch candidates, not future native equivalence. Strong host-fit/financial requests refuse before dispatch. After observed Popen, only complete same-attempt pipe write/close plus joined native success/usage can pass the new limited case; failure retains unknown cost. Original strong IF09/IF12 remain NOT_RUN for this limited profile. All other accounting, H05/A5, 12-adapter, privacy, 30-day cleanup, hourly scheduler, security/platform/publication and final-audit gates remain.


## Revision67 limited current-Codex claim

Current Codex remains on user Choice B `ALK_CONTROLLED_INPUT_FIT` after exact r67 review/lock and task-bound proof. Complete-host-fit, whole-call U and FULL_FINANCIAL remain unproven; stronger claims refuse. Adapter code is unchanged.

## Revision66 audit and preview correction

The current-Codex claim stays `ALK_CONTROLLED_INPUT_FIT` only. The r155 two-finding correction adds no new host guarantee: an independent pre-WS01 bootstrap audit result must be verified before first-task preflight, and active `r66FitDisposition` points to an exact r66 local 16k preview while native scoped proof remains PENDING. Earlier r65/r64 fit dispositions are historical for this draft. Full financial or complete-host claims still refuse; no adapter code or shipped profile changes.


## Revision65 DRAFT current-Codex route sequencing

Choice B remains a limited `ALK_CONTROLLED_INPUT_FIT` claim on `codex-exact-prompt-v1`. The accepted pre-WS216-01 ALK bootstrap is a sequencing repair inside ALK, not adapter modification, not WS216-02 early acceptance and not a broader host guarantee. `r65FitDisposition` and `r65RuntimeArtifacts` supersede r64 route artifact wording only after an exact r65 review/lock; until then r64 is locked authority and current WS216-01 native admission is DENY. Host-owned complete input, host consumption of stdin and whole-call U remain unavailable; stronger/hard financial claims refuse.


## Revision64 exact reviewed-lock applicability

User Choice B carries through r64 without a broader claim. Only `r64FitDisposition` governs the limited current-Codex exact-prompt route after separate exact review and lock; the r63 disposition is historical. Host-owned full input and whole-call U remain UNAVAILABLE, stronger claims refuse, and no adapter source is changed.

## Revision61 route scope

User Choice B and ALK-only modification authority permit a limited current-Codex exact-prompt route if independently proved. This is not an adapter implementation change, full-host fit, provider output cap or FULL_FINANCIAL. Missing proof refuses without silent downgrade.

## Revision60 reviewed-lock applicability

The approved current-Codex Choice B is carried from r59 without expanding its claim. `r60FitDisposition` is the active scoped prelaunch rule only after exact independent review and lock. Full-host fit and FULL_FINANCIAL remain unavailable without their own proof; other capability-scoped H04/A5/protected-closing decisions and all release gates are unchanged.

## Revision59 precise current-Codex fit applicability

The approved Choice B does not silently waive a general host-fit gate. For current Codex only, the r59 limited profile claims exact ALK-controlled input selection/caps and explicitly excludes unmeasured host-owned input; the exact r59 receipt and later native proof are required. A complete-host-fit or FULL_FINANCIAL request must still refuse without full-input/U proof. r57/r58 and older 16k host-input wording is historical only for this scoped r59 claim; other release requirements remain.

## Revision58 user-approved Codex fit limitation

The user selected r121 Option B for current Codex. Release 2.16 may eventually offer a reviewed and natively proved `ALK_CONTROLLED_INPUT_FIT` profile, with complete-host 16k fit, host-owned history/tools/format and whole-call U explicitly excluded. This does not grant FULL_FINANCIAL or protected closing, and it does not silently downgrade a stronger request. The exact r58 DRAFT still needs independent full S2 review, a distinct lock, native oracles and all retained release gates; r57 stays authoritative.

## Revision55 storage route disposition

Choice B is unchanged. Current Codex uses explicit legacy-v5 ordinary financial mode and refuses protected adoption/closing before effects; it never silently upgrades. Qualified future v6 route must use complete guarded migration or qualified new v6 initialization, preserving all financial history and late settlement. No adapter change or new current-route protected capability is authorized.


## Revision54 correction candidate — independent full S2 review pending

Revision54 preserves user-selected Choice B. The v6 positive protected writer/root/B-stage design is unavailable on current Codex without a qualified independent operator; v5 ordinary guarded financial work and late settlement are not implicitly migrated or denied. No adapter change or new current-route permission is authorized.


## Revision53 draft scope decision

The user-selected Choice B is unchanged: current Codex has no separate qualified operator and must refuse protected adoption/closing, while ordinary guarded work and late settlement continue. r53 specifies a complete positive-route wire and ALK-owned root/publisher contract for future qualified routes without changing adapters or granting current Codex capability. r52 is locked; this draft has no review, lock or release authority.


## Revision52 prepared FROZEN-shape candidate — Choice B current-Codex capability-scoped closing

The user selected Choice B. On the current full-access Codex route ALK must refuse protected adoption, root/epoch-0 publication, closing activation/grant and protected dispatch before write or process start. Positive CC04–CC16, DS14, DA15 and joined DS/DA/DR/DD cases remain NOT_RUN/UNPROVEN under their original IDs; distinct OR01–OR19 native negatives and independently reviewed applicability are required for a limited release. All 53 retained WS01 local cases, CC01–CC03, late settlement, H04/H05, A5 for all12 adapters, platform/security/publication and numeric caps remain mandatory. A qualified future route must pass the original positive native cases before enabling protected closing. This prepared candidate has no accepting review, lock, native proof, task acceptance or release permission; r48 remains current.


## Revision48 prepared adoption-input candidate

The reviewed correction from r47 DRAFT is now prepared for independent r48 review, with the same capability-scoped adapter policy and all runtime/release gates. A FROZEN-shape manifest alone grants no new execution authority; r46 remains the locked predecessor until r48 receives its own accepting report and lock.

## Revision47 DRAFT adoption input decision

The new closed AdoptionInput and separate AdoptionSelection specify exact legacy state/events, existing complete accounting scope and independently pinned root/epoch0 selection for `adopt_run`. Syntax and digest checks are data only; DA15 still requires proof of the operator route. The supported v1 adoption attaches an existing qualified original budget scope and does not create a zero opening, extend caps or bypass host capability limits. This is a draft contract change pending a distinct candidate and independent review.

## Revision23 — concrete A5 limited implementation candidate

`cf01-a5-implementation-contract.json` now defines the proposed closed records,
frozen policy/state/adoption join, ordinary planning request binding, exact ALK
launch/refusal and consumer hooks, all12 saved expectation targets, exact owners
and 12 future oracle groups. Status: DRAFT_REQUIRES_INDEPENDENT_DELTA_REVIEW.
The accepted r22 capability policy and r19-r21 authority/storage/resource/deadline
semantics remain unchanged. This amendment supersedes only their unresolved A5
integration placeholders; it does not claim full-plan acceptance or runtime proof.

Ordinary standalone context binds the actual explicit operation/input; it is not
a bearer authorization and needs no invented authority file or workflow attempt.
Frozen workflow requirements remain independently authoritative. Accepted attempts
retain original A5 classification/evidence/cost and use a separate adoption binding.
No strong-positive v1 variant exists. Every proposed strong request refuses.

R216-IMMUTABLE-INPUT maps to AC216-A5-SCHEMA / WS216-01 / EV216-SCHEMA and existing
AC216-A5-CAPABILITY / WS216-02 / EV216-CLOSING-WINDOW. All six r22 policy categories
are covered by A501-A512 in the contract. Future commands are declared in the
manifest, NOT_RUN. H05, measured packet/native-budget fit, independent delta and
whole-candidate review/freeze, implementation and actual all12/platform/final
qualification remain open. Existing caps are retained, never presumed sufficient.


## Revision22 — A5 according to existing host capabilities

User-approved scope: strong A5 is enabled only for an existing route with proven
continuous input protection. Other routes refuse that mode and may meet release
acceptance with a reviewed limitation plus actual source-bound refusal proof.
The positive A5 invariant is unchanged; no endpoint-hash fallback, silent downgrade
or immutable-input/write-scope exemption is allowed on a limited route. Ordinary
source/result/ownership/audit and independently required security/validity checks
remain mandatory; any operation requiring unavailable protection remains refused.

`cf01-a5-capability-scope.json` is the normative applicability authority for all12
adapter routes. Older unconditional A5 prerequisite statements below apply to the
STRONG_A5 branch; limited routes instead require a complete refusal integration
contract before freeze and actual route/consumer qualification before release.
H04 support does not establish A5 support. Unknown remains UNPROVEN, not PASS.
The accepted r19/r20/r21 design is retained. This r22 amendment needs scoped
independent review; full candidate readiness, H05, actual fit and all implementation,
storage/platform/final release gates remain open. Historical revision narratives
below are retained as history and do not override this current applicability rule.

## Revision18 — D-DEADLINE configured consumers and current time

cf-d-deadline-contract.json joins the four closing-window design contracts. Actual
runtime gate input is per-task controllerGates and its producer/phase configuration,
not securityGates prose. Only an independently declared compatible execution-only
predicate may consume signed closing permission; run/attempt wall budgets, evidence
freshness, lease/grace/I-O and opaque custom gates retain their original bounds.

The supplied historical receipt identifies project planning/immutable-gate.py and
its execution-deadline failure. Its old FAIL is preserved; historical script source
semantics/current runtime qualification remain unproven. No gate was rerun or
project script/host patched. New contract templates are reviewable before freeze;
actual compiled registry/source/clock identities must be qualified after implementation.

New workflow timestamps use canonical UTC microseconds. D-AUTH and D-DEADLINE share
the same fresh final decision observation; replay/projection never renews time.
Late useful results and all actual costs remain recordable, with reuse classified
separately from permission. Final-audit acceptance or a prepared proof file alone
cannot bypass finalization gates or commit COMPLETE after an invalid decision.

16NOT_RUN cases contribute8WS01 rule/clock-storage and8WS02 consumer/integration witnesses.
Seven exact ownership paths and two planned validation groups retain old owners and
native caps. The joined DRAFT needs independent review, then implementation/native
proof. CF01-A5/H05/actual fit/all12adapter/storage/platform/final gates remain open.

## Revision17 — D-RESOURCE prospective policy and current claim

cf-d-resource-contract.json defines the minimal ACCOUNTING_REPORTED_TOKENS_V1
policy effect in the existing journal, joined with D-STATE and D-AUTH. Signed
additional allowance A yields cumulative ceiling C=S+A at the exact signed anchor.
It never adds unused old allowance. Task/run/window constraints evaluate one charge;
old costs, caps, reserves, protection and violations remain. Source bound failure
or unknown opening cannot be repaired by raising a budget.

Activation records policy/window/nonce together. Reservation and once-claim both
validate current resource and authority state; claim includes the already reserved
U once. Each closeout transfer/refund stays with its original owner/window. A new
signed window may retire an earlier entitlement but cannot roll over unused A,
claim an old unclaimed permit or reset spend. Legacy billableTokens/invocations/
wallSeconds remain distinct unchanged guards; unsupported extension is unavailable.

20NOT_RUN cases contribute16WS01 resource witnesses and4WS02 integration witnesses.
Five exact ownership paths and two validation groups are added within unchanged
native ceilings. These are author design contracts, not implementation or evidence
of native enforcement. Configured D-DEADLINE consumers and their exact guard state
must be bound next, then the combined design needs independent review. CF01-A5,
H05/actual fit, all12adapter qualification and final release gates remain open.

## Revision16 — D-AUTH issuer, revocation and commit contract

cf-d-auth-contract.json defines an independently pinned operator root, a signed
per-run issuer snapshot and a separately signed closing grant. It reuses ALK's
Ed25519 implementation through a planned contracts extraction with compatibility
exports. A name, receipt hash, external pathname or TEST_AUTHORITY is insufficient
owner proof. Native bootstrap qualification remains required as DA15.

The existing SQLite writer transaction orders authority publication, nonce use,
workflow activation and financial claim. A revocation takes effect when its signed
snapshot commits locally. A prior committed claim is in flight and cannot be
promised cancelled by this protocol. Current authority/time and financial state
are rechecked at claim; historical replay cannot issue a new permit. Expiry during
projection or commit does not extend permission or cause checks to restart.

Sixteen NOT_RUN cases contribute12WS01 authority/storage witnesses and4WS02
integration/native witnesses. Eight additional exact ownership paths and two
planned validation groups preserve all previous owners, cases and finite ceilings.
This is a concrete design candidate, not implementation or independent acceptance.
D-RESOURCE must close the exact approval-policy schema/transaction/claim join next;
configured D-DEADLINE, CF01-A5, H05/actual fit and final review remain open.
Only ALK is changed by the planned implementation; all12adapter capability limits,
FULL_FINANCIAL semantics and30-day financially-closed detail retention are retained.

## Revision15 — D-STATE transaction and recovery contract

cf-d-state-contract.json selects one authoritative SQLite transaction for workflow
state/event/result, closing window, nonce use and qualified prospective policy.
JSON state/event files become derived, generation-bound projections. Existing
Journal transaction/version/writer admission is a primitive to extend, not proof
that this workflow feature already exists. A typed WS01 WorkflowStore port owns
storage/adoption/replay/publication; WS02 integrates state/kernel/events and every
permission consumer. No new database, JSONL authority implementation or benchmark
is introduced by this plan. Four exact paths and one planned command are added.

An operation committed before a lost reply returns the same durable semantic
result on replay. Pending/mismatched projection denies new dispatch. A claimed or
uncertain model invocation never restarts during storage recovery. Late expenses
remain recordable without renewing authority. Trusted JOURNAL_REQUIRED binding
prevents fallback to old JSON or a new empty accounting scope. Adoption requires
qualified legacy observation, known quiescent writers and preserved history.

The22 NOT_RUN cases separate18WS01 storage witnesses from4WS02 integration cases.
D-STATE is a concrete DRAFT design, not independently accepted or implemented.
D-AUTH commit-bound verification, D-RESOURCE same-transaction policy port, configured
D-DEADLINE consumers, CF01-A5, H05/actual fit and final candidate review remain open.
FULL_FINANCIAL limitations and30-day financially-closed retention remain unchanged.

## Revision14 — CF01/CF02 exact integration map

cf-integration-map.json is the current source/owner/oracle authority for this
integration. Fourteen rows separate source-read facts, reused accepted core proof,
declarations and proposed interfaces. Thirteen exact paths are added to the serial
WS01/WS02 ownership; no directory wildcard or product edit is authorized by DRAFT.
WS01 provides a pure closing-policy/state/finalization seam before WS02 native
activation. Direct CLI, Python and continuation routes must converge on the same
authoritative action/time/resource guard; ordinary task work cannot bypass it.

S2-R11-P01 is PARTIALLY_ADDRESSED, not closed. Existing neutrality signature code
is a domain-specific primitive, not a workflow owner grant. Kernel event append
and state replacement are separate; neither this nor accounting SQLite proves an
atomic activation/nonce/policy transition. The exact authority route, all-writer
transaction/recovery interface, configured execution-deadline/watchdog producers
and prospective resource policy API remain prefreeze design dependencies.
No literal execution-deadline consumer was found in the bounded repository source
search; dynamic/installed/configured consumers remain unproven, not nonexistent.

Evidence TTL, worker leases, process grace and capture deadlines cannot be extended
by a new execution permission. Expired permission does not discard valid evidence
or prevent late financial settlement; those actions do not grant new paid work.
CF01 A5/G-AUTH/G-OBS/G-TIME/G-CONSUME/G-SCOPE, H05 coverage and measured fit remain
open. No actor, receipt, counter, lock or runtime PASS is manufactured here.

## Revision 13 — pinned expectation inputs and staged runtime identity

All12 expectation templates are now populated in h04-adapter-profile-cases.json:
descriptor/capability hashes, selected versions with provenance, saved official
source snapshots, each documented candidate's ceiling/oracle, role and original
case obligations, and bounded qualification recipes. These are EXPECTED_NOT_OBSERVED
inputs pending independent review; no runtime profile is accepted by this revision.

r12's requirement for actual host executable/configuration hashes before freeze
is replaced by TARGET13 in h04-artifact-contracts.json. Before freeze review the
fixed targets, source hashes and claim/qualification policy. After implementation
bind exact existing runtime identity for every native-positive claim. A reviewed
source-bound limitation may use explicitly null runtime hashes and must reject
all native-positive/financial claims through actual ALK refusal. This grants no
host compatibility or permission to modify/install a host. Every documented
candidate still requires an individual justified disposition; no convenience fallback.

Native experiments require concrete admitted argv/configuration and source-bound
oracles before execution. The12x100000 ordinary planning allocations consume1.2M
of existing WS02 ordinary2M; remaining800000 covers integration/validation. WS02
protected250000 is shared once, not copied per profile. Request/time/tool/evidence
and validation-run fit remain unproven; this allocation changes no native cap.
Retained CF02/CF01 integration design, H05 coverage, actual fit and final independent
review still block freeze. No code/tests/native transition or release approval.

## Revision 12 — reviewed findings and current authority

r11 full-plan independent review returned CHANGES_REQUIRED (3 High,4 Medium).
r12 addresses S2-R11-H01/H02/M01/M02 in DRAFT; these are author corrections,
not independently closed findings. h04-artifact-contracts.json defines closed
artifact/request/result types, immutable expectation joins, exact comparison and
refusal rules, bounded producers and qualification milestones. The profile-case
file maps all21 profile oracles and all13 original core/native assertions.
WS01 produces pure resolver proof in its own EV; WS02 produces exact-final-profile
refusal after integration. Expected bindings are pinned templates, not runtime PASS; TARGET13 controls runtime qualification.
Before freeze populate and independently review all12 exact target/source/claim
and recipe expectations. Runtime qualification follows implementation and precedes
release. Existing CF02/CF01 transitive design, H05 independent coverage and actual
packet/budget fit remain open; no lock, execution or release approval exists.
Full H04 on current Codex remains optional; all12 scoped profile acceptance remains
mandatory. Earlier revision text is historical where it conflicts with this block.

## Revision 11 — current H04 authority

DRAFT. The user removed mandatory full H04 in current Codex. [h04-adapter-boundaries.md](h04-adapter-boundaries.md), h04-adapter-profile-cases.json and manifest revision11 control adapter-specific acceptance for all12. Every accepted profile requires both applicable capability/limitation evidence and exact-profile ALK resolver refusal proof. FULL_FINANCIAL remains strict but optional per supported profile. Earlier conflicting H04 statements below are historical; other release gates and original evidence remain unchanged. Independent specification review permits migration only; full-plan review, implementation and runtime qualification remain pending.


## Plan and execution artifact separation, revision 3

Keep planArtifactRoot at tasks/release-2-16; set artifactRoot to
work/release-2-16, matching existing state, event and runtime ownership paths.
Default task compile writes workflow/task-packets under artifactRoot. It must
never create directories inside the locked plan inventory. Do not allowlist
runtime directories or bypass package-integrity checks to make compilation pass.
The former shared root was reproduced with a genuine reviewed temporary r7
package: initial integrity PASS, three compiled packets, then
plan-directory-undeclared for workflow. The predecessor 2.14 uses separate roots.
This is a plan preparation correction, not implementation or a new acceptance
claim. Keep review budget and all release acceptance gates unchanged.

Historical revision-3 rationale, 2026-09-05. Previous audit/probe artifacts are archived evidence only and are not mandatory inputs to the self-contained revision-7 execution contract.

## Actual negative evidence

EV216-SCHEMA mutates each required audit field and accepted enum independently. EV216-BINDING tests one unrelated receipt reused for two evidence IDs, wrong run/task/attempt/plan/source identity and stale digest. EV216-PROVENANCE tests self-asserted independence and replayed external identity. Test the actual accepting workflow routes, not only a schema helper.

Confirmed again on the 2.15 source: raw Review Mesh import drops a non-list findings value and defaults missing usage to zero. This is not a demonstrated quorum bypass: roundParticipation remains ineligible. Fix import validity now, reserving complete session accounting for 2.21. Choose an explicit compatible raw-input contract; a raw input is not agent-review-mesh-result.v1. Do not replace schema names in documentation without reconciling fields and import behavior.

## Release and validation obligations

N-06: publication includes the actual version consumers in publication_contract.py, onboarding/index/CLI documentation, and a NEW release-2-16-accounting fixture. Point the current publication contract at the new fixture; do not rewrite old accounting evidence. Keep measured controller, audit and implementation time/tokens distinct; unavailable data is UNAVAILABLE, not zero.

Full discovery runs with -s tests -t .; focused tests use existing suites where present and declared new modules otherwise. A test in the write-set authorizes extending coverage, never weakening predecessor assertions. No new tests namespace may be invisible to discovery. Full quality, hygiene/history, workflow-transition, stdlib, docs, architecture, security, model-profile and publication gates are retained. The stricter hard-symbols=80 threshold is retained. Its old 2.14 PASS is historical, not a new 2.15 measurement; it is not raised to CI's 120. Update the quality command base SHA together with baseRevision on rebase. New failures require scoped repair or plan revision, never threshold reduction.

## Pre-freeze governance

1. Verify the accepted predecessor source and implementation/release evidence; a pending manual PyPI environment approval alone is not a core-code dependency.
2. Rebase the package, update baseRevision and command SHA pins, and reconcile every shared domain/publication path. Do not overwrite predecessor tests or schema additions.
3. Before the final reviewer snapshot, reserve the canonical review-report path in planFiles and set the required planReview binding for the intended final revision using the existing reviewed-lock protocol. Revision 38 has that prepared binding but no actual review report or lock; its expected manifest verdict is not an accepting reviewer result. Complete candidate status/binding preparation BEFORE review; no post-review manifest edit is allowed.
4. Snapshot canonical manifest identity and individual package-file byte hashes. Before the report and lock, run structural checks without claiming full frozen-package verification. After lock creation, run plan verify with this package directory as --package-root, not the repository root. An empty refs-check is not proof of source coverage.
5. Obtain an independent full S2 audit of those candidate bytes. If any reviewed input changes, prepare a new candidate/revision and repeat review. The report binds the manifest; the final lock binds the report plus package inventory, avoiding a fabricated self-approval or a circular hash requirement.
6. Only the reviewed-lock API may create a lock after the required accepting evidence exists. Verify filesystem inventory immediately before adoption. Planning self-checks are not S2 evidence.

Plan checklists and machine PASS do not authorize implementation. Analysis artifacts in tasks/ remain local and ignored; reproducible CI fixtures belong under tracked tests/, never plans/, out/ or .claude/.

## Revision-7 transfer and source reconciliation

Accepted predecessor: v2.15.0 / 8480ef61cccfacb92928cbc68f8849a59001d5b5.
The local 4ea1041 candidate has the same Git tree; do not claim commit equality.
The quality --base-sha is updated with baseRevision. No completed 2.15 audit or
platform cycle is rerun for this planning change. Its proof remains historical
input; the future 2.16 implementation needs its own applicable candidate evidence.

The expected descriptor uses the existing acceptance.evidence[].validation field.
WS216-01 owns its bounded runtime/schema validation and tests. The actual frozen
manifest is the source of expectation; worker-supplied payload metadata is not.
Receipt kinds are built-in and versioned, with no arbitrary executable predicate
or remote schema fetch. The revision-7 README pins proposed fields/limits and legacy compatibility.
Independent review must validate them before freeze; unsupported required forms fail.

Required fixture matrix extends the existing suites: one receipt/five IDs;
missing/duplicate/wrong lineage; changed component/config/oracle/merge tree;
identical-content explicit applicability; omitted payload fields; fake producer;
negative async observation before readiness/incomplete coverage; valid completed
observation and seeded delayed violation; raw invalid enum/container/budget;
conflicting bindings; known FAIL retained; unknown-versus-zero usage;
same-actor/same-session and forged/stale/wrong-subject attestation. Test actual
audit and task/final accepting consumers, not only schema helpers.

Use tests/audit/fixtures/release_216_evidence_contracts.json and generated temporary
component-a/component-b repositories. The fixture JSON is test data, not a signed
release proof. No specific external project checkout, service or incident receipt
is a prerequisite. An inert asynchronous producer proves observation behavior;
semantic oracle sufficiency and live external identity remain separate guarantees.

## Budget and review admission

Existing native implementation caps and maxPlanReviewRounds=4 remain unchanged.
They are not proof that the enlarged contract or the current host context fits.
budgetPolicy.modelTokenBudgetForPlanValidation=0 covers deterministic planning
checks; the prior one-review envelope is exhausted and its incomplete report is historical.
The separately authorized r5 correction envelope permits no reviewer launch.
Before any reviewer launch, record finite call/total-token/time limits, actual
full-input telemetry or its absence, root/reviewer allocation and closing reserve.
Never infer a provider hard cap from a local estimate or reset previous expenses.
Resolve insufficient implementation caps in the reviewed candidate before freeze.

Preparation performs only local deterministic plan checks. It does not start
workers, product tests, external reviewers, a native run or publication. A pending
review-resource decision is explicit and does not justify a fabricated verdict.

## Revision-7 decisions and remaining blockers

README is the normative contract definition. The manifest now declares all six
required evidence descriptors, exact command digests and case IDs. The ALK-owned
fixture must implement those IDs; their declaration is not a test result. The
current 2.15 structural checker accepting descriptor bytes is not proof that its
audit runtime enforces the new type; review the candidate-runtime activation and
bootstrap sequence before native adoption. No guard bypass is authorized.

The revision-7 README now specifies the proposed reviewer trust-root/attestation
wire schemas, cryptographic verification API, freshness and replay behavior. It
reuses core canonical bytes and existing Ed25519 without interpreting neutrality
receipts as reviewer attestations. Exact qualified host/workflow trusted_context
sourcing remains unconfirmed. A fixture is a test authority, not production
external-issuer evidence. H01 stays PARTIALLY_ADDRESSED_IN_DRAFT and H02 OPEN.

Finalization now has an explicit WS216-01 write owner. The planned
test_finalization_audit_outcomes module is a new discoverable test addition; the
independent review must still prove all final accepting entry points are covered.
Native 100000/task and 300000/run caps remain unchanged and unproven sufficient.
Final planReview bindings and report inventory must be prepared by the existing
reviewed-lock protocol before a future accepting snapshot; r5 has no fabricated
review or lock. No changes to the nine-file package after that snapshot may be
accepted without a new bound review.

## Revision-7 scope decision

The prior claim that a reviewer-specific trusted verifier already existed was not
established. R6 proposes a thin new review/provenance.py consumer and typed public
issuer binding over existing Ed25519. It is still DRAFT design, not an existing
capability or a new signing/identity service. WS216-02 owns the new module, tests
and public fixture; WS216-01 retains its final/task audit seams.

An ATTESTED claim authenticates the configured issuer's reviewer/session assertion
for this assignment and subject; it does not prove human identity or model quality.
Without an independently qualified caller context it is unsupported. The positive
fixture tests a deliberately configured test issuer; production readiness still
requires applicable external issuer/caller evidence. Independent S2 review must
assess this exact scope clarification and native consumer coverage before freeze.

R218-CRYPTO remains separate hardening. No dependency, threshold relaxation or
replacement of existing signature algorithms/signed neutrality bytes is added.

## Revision-7 controlling integration decision

The README native trusted-context section supersedes r6 ownership and unproven positive-route assumptions. Current inspected native calls have no qualified authority source; production ATTESTED is explicitly deferred, pending independent review of that scope decision. No host service, env-based trust shortcut, new policy switch or external project dependency is added. Shared provenance schema/verifier/tests move exclusively to WS216-01 to avoid forward imports; remaining freeze/adoption/review consumers belong to WS216-02. Historical revision descriptions above are not the current write set. Native 100000/task and 300000/run caps remain unchanged and their fit remains open.

## Revision-8 command and provenance consistency correction

This revision addresses S2-R7-H01 and S2-R7-M01 in the DRAFT, pending independent
verification. The authoritative command selection is README's workstream rule and
acceptance.evidence[].validation.requirements.commandDigests; validation.commands
retains every original final command and adds two scoped commands. Existing
contextRefs provide the frozen selection inputs without claiming a new compiler
feature. Ownership, serial dependencies, native execution caps and all case IDs
are unchanged. The final provenance gate and evidence text now require the same
TEST_AUTHORITY positive and native ATTESTED rejection obligations. The earlier
statement that the pure-verifier positive awaited discovery of an external verifier
is superseded; a qualified production native route remains explicitly deferred.

No finding is independently closed. S2-R7-H02 freeze binding, H03 runtime bootstrap,
H04 measured budget fit and H05 full source/test coverage remain open. Prior r4
findings are not automatically closed. This bounded correction does not authorize
product implementation, native freeze/adoption or another audit.


## Revision-9 controlling decision: H03/H02

README's execution authority/native binding section supersedes the earlier open-
ended bootstrap and freeze-preparation descriptions. P is pinned to the accepted
2.15 source and only performs bootstrap/administrative operations; C1 is activated
before WS216-01 implementation audit/acceptance without changing native state or
adopted lineage. Negative controls go through the actual accepting route in an
isolated fixture. No new controller, ownership path, policy switch or runtime
attestation service is introduced. C1/C2/C3 values must be measured from actual
source, never inferred from installed plugin version.

At revision 9, DRAFT planReview required a pending independent review; its full
native candidate binding was to be prepared by the explicit recipe before an
accepting review. Revision 38 now has that prepared FROZEN-shape binding, but no
actual report or lock. Its expected READY_TO_FREEZE verdict is not reviewer output.
Only the independent reviewer creates the report; native lock-create then binds
its bytes together with the unchanged normative source snapshot. No digest
self-cycle, unlisted report exemption, status-only approval or post-review
metadata edit is permitted. H03/H02 design contracts and pre-review H04 input-fit
and H05 design coverage need exact-candidate acceptance; executable evidence and
release proof remain later gates. The r9 envelope itself did not authorize these
future transitions.


## Revision-10 controlling accounting/recovery amendment

Revision10 is DRAFT. release-prerequisites.md and the manifest define the added minimal accounting/recovery scope, serial ownership, prospective token ceilings and unresolved prerequisites. accounting-and-recovery-cases.json retains original H04 AC01–AC13 and CF CC01–CC16. All earlier unchanged-scope/cap statements apply to their historical revisions; original acceptance, command, quality/security and publication gates remain. This amendment is not an accepting review, implementation proof, freeze or native authorization.

## r69l R11 PRE bootstrap successor (DRAFT)

For the current prospective PRE bootstrap, `r69l-r11-bootstrap-delta.md`, the r69l route/manifest, v9/v4 oracles and v5 schemas supersede earlier r69j/r69k one-turn, six-path, 70-path and v4-only PRE wording. Earlier text remains historical for its pinned revision and for unchanged task/release gates. The installed r69k lock remains authority until a separate full DRAFT/FROZEN S2, exact report, canonical lock and controlled transfer. The r362 FAIL remains open; no product/native/release PASS is inferred.
