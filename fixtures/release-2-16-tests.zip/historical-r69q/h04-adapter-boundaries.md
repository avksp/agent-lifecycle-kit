# Release 2.16 revision 13 — adapter-specific H04 acceptance

## Revision22 — A5 according to existing host capabilities

User-approved scope: strong A5 is enabled only for an existing route with proven
continuous input protection. Other routes refuse that mode and may meet release
acceptance with a reviewed limitation plus actual source-bound refusal proof.
The positive A5 invariant is unchanged; no endpoint-hash fallback, silent downgrade
or immutable-input/write-scope exemption is allowed on a limited route. Ordinary
source/result/ownership/audit and independently required security/validity checks
remain mandatory; any operation requiring unavailable protection remains refused.

`cf01-a5-capability-scope.json` is the normative applicability authority for all12
adapter routes. Older unconditional A5 prerequisite statements below apply to the
STRONG_A5 branch; limited routes instead require a complete refusal integration
contract before freeze and actual route/consumer qualification before release.
H04 support does not establish A5 support. Unknown remains UNPROVEN, not PASS.
The accepted r19/r20/r21 design is retained. This r22 amendment needs scoped
independent review; full candidate readiness, H05, actual fit and all implementation,
storage/platform/final release gates remain open. Historical revision narratives
below are retained as history and do not override this current applicability rule.

## Revision 13 — pinned expectation inputs and staged runtime identity

All12 expectation templates are now populated in h04-adapter-profile-cases.json:
descriptor/capability hashes, selected versions with provenance, saved official
source snapshots, each documented candidate's ceiling/oracle, role and original
case obligations, and bounded qualification recipes. These are EXPECTED_NOT_OBSERVED
inputs pending independent review; no runtime profile is accepted by this revision.

r12's requirement for actual host executable/configuration hashes before freeze
is replaced by TARGET13 in h04-artifact-contracts.json. Before freeze review the
fixed targets, source hashes and claim/qualification policy. After implementation
bind exact existing runtime identity for every native-positive claim. A reviewed
source-bound limitation may use explicitly null runtime hashes and must reject
all native-positive/financial claims through actual ALK refusal. This grants no
host compatibility or permission to modify/install a host. Every documented
candidate still requires an individual justified disposition; no convenience fallback.

Native experiments require concrete admitted argv/configuration and source-bound
oracles before execution. The12x100000 ordinary planning allocations consume1.2M
of existing WS02 ordinary2M; remaining800000 covers integration/validation. WS02
protected250000 is shared once, not copied per profile. Request/time/tool/evidence
and validation-run fit remain unproven; this allocation changes no native cap.
Retained CF02/CF01 integration design, H05 coverage, actual fit and final independent
review still block freeze. No code/tests/native transition or release approval.

Дата: 2026-09-22. Тип: S2 specification amendment. Решение о scope принято пользователем; техническая спецификация DRAFT_REQUIRES_REVIEW. Не freeze, не реализация и не runtime qualification.

## Решение пользователя и приоритет

«требование полного H04 в текущем Codex по причине не готовности самого Codex я снимаю. Нужно проверять пригодность в рамках возможности каждого адаптера. Мы можем менять и адаптировать только ALK. Границы приеримости должны быть найдены для всех адаптеров.»

Это отменяет обязательность полного H04 в текущем Codex как универсального условия Release 2.16. Прежние заключения о нехватке гарантий остаются техническими доказательствами, но основанный только на этом универсальный блокер больше не применяется. Новое обязательство: исчерпывающая по инвентарю ALK квалификация границ для всех 12 адаптеров.

Менять можно ядро и принадлежащий ALK интеграционный код, профили/конфигурации ALK и документацию. Нельзя менять исходники, форкать, собирать, устанавливать новую версию либо подменять внешний хост ради получения гарантии. Штатный API/hook хоста допустим; создание второго внешнего контроллера текущего координатора не подразумевается.

Сохраняются запрет платного Responses API, внешних сообщений и обнуления расхода/резервов. Доказательства и принятые результаты не аннулируются. Исторические документы не переписываются задним числом. Глобальная память не меняется.

## Пользовательский результат

Для конкретной пары adapter + host version/configuration ALK показывает:
1. Какие расходы доступны для учёта, в какой единице, с какой полнотой и происхождением.
2. Где ALK/хост способен отказать до расхода, какой предел исполняется и каковы последствия сбоя.
3. Какие роли и маршруты охвачены, исключены или ещё не квалифицированы.
4. Какие режимы разрешены и какой запрос на гарантию будет отклонён.

Наличие VERIFIED в старом adapter descriptor не квалифицирует H04. Поддержка учёта, ограничения и охвата — независимые измерения, а не одна лестница зрелости.

## Режимы и границы утверждений

- LIFECYCLE_ONLY: прежняя применимая функциональность ALK; финансовые гарантии не заявлены. Отсутствующие расходы UNAVAILABLE/null, никогда ноль.
- OBSERVATION: импорт/накопление только квалифицированных квитанций с единицей, coverage и стабильной идентичностью. Неполный учёт явно обозначен. Сам по себе не обещает предотвращение расхода.
- ALK_INVOCATION_ADMISSION: ALK может отказать до запуска принадлежащей ему операции/процесса. Это не контроль уже работающего координатора, внутренних ходов, retry или compaction хоста. Для обещания финансового потолка этой операции нужен доказанный U всего её выполнения; без U разрешено заявлять только границу запуска.
- HOST_PARTIAL_CONTROL: документированный и квалифицированный native лимит или hook действует в точно названном scope. Обязательны единица, тип лимита, фактический маршрут и сценарий ошибки; лимит completion, количества шагов или стоимости SDK-сессии не равен общему task+run лимиту.
- FULL_FINANCIAL: название и исходные HIF01–HIF05 сохраняют строгий смысл. Все роли, вызовы и финансовое закрытие действительно охвачены. Только доказанный профиль может включать этот режим. Ни один текущий кандидат этим документом не повышается.

Режимы могут сочетаться по покрытию; например OBSERVATION + HOST_PARTIAL_CONTROL. Нельзя автоматически заменить запрошенный FULL_FINANCIAL частичным режимом. При несовпадении требований операции с принятым профилем ALK отказывает до принадлежащей ему отправки с причиной ADAPTER_BUDGET_CAPABILITY_UNAVAILABLE. Этот новый reason code — проектируемый контракт, ещё не существующий endpoint или код реализации.

## Критерии приёмки Release 2.16

R-H04-A01 / AC-H04-A01: инвентарь содержит ровно все 12 adapter IDs из репозитория. Для каждого есть версия/диапазон, режим запуска, провайдер/транспорт при их влиянии, источник гарантий и scope; неизвестная версия не наследует возможности latest docs.

R-H04-A02 / AC-H04-A02: профиль раздельно описывает учёт, контроль, охват. Для coordinator/worker/check/auditor/retry/compaction/closeout каждый значимый маршрут получает COVERED, EXCLUDED или UNQUALIFIED с доказательством/причиной. UNQUALIFIED нельзя выдать за принятую поддержку.

R-H04-A03 / AC-H04-A03: все заявленные положительные гарантии имеют квалификацию для конкретного runtime/configuration. Документация обосновывает кандидат, offline fixture проверяет ALK-логику, но ни то ни другое само по себе не является доказательством поведения установленного хоста.

R-H04-A04 / AC-H04-A04: подтверждённое ограничение — допустимый результат приёмки адаптера, а не глобальный блокер. Оно должно указывать, какой именно механизм недостаточен/неприменим, минимальный поддержанный режим и как ALK предотвращает завышенное обещание. Не требуется доказывать отсутствие всех мыслимых интерфейсов хоста.

R-H04-A05 / AC-H04-A05: unsupported и unqualified различаются. Суждение «не проверено» остаётся незавершённой квалификацией выбранного режима. Можно завершить узкий консервативный профиль, явно исключающий неподтверждённые функции, если сам этот профиль и отказ более сильного режима проверены. Вне заявленного профиля исследование всех возможных функций не требуется.

R-H04-A06 / AC-H04-A06: принятые гарантии общего журнала ALK сохраняются: фактический расход, атомарные task/run резервы, once-only settle, recovery, UNAVAILABLE, запрет сброса после compact. Отсутствие telemetry не является доказанным нулём. Новая политика применимости не меняет арифметику полного режима.

R-H04-A07 / AC-H04-A07: отрицательные проверки включают несовместимую версию/режим, отказ ALK, недоступность журнала, падение/timeout hook, позднюю/дублированную квитанцию, повтор и неохваченный маршрут. Принятый профиль указывает фактическое поведение, включая fail-open; такую ветку нельзя обозначить обязательным финансовым барьером.

R-H04-A08 / AC-H04-A08: расходы текущего координатора нельзя считать подконтрольными ALK только потому, что ALK запускает дочерних исполнителей. Неохваченный хвост финального ответа сохраняется pending/unknown до квалифицированной квитанции.

R-H04-A09 / AC-H04-A09: частичный профиль не создаёт полное финансовое закрытие запуска. 30-дневная очистка подробностей начинается после существующего подтверждённого полного закрытия; неизвестные/незавершённые расходы исключаются. Операционное завершение допускается как отдельное состояние без подмены financial closure. Если финансовое закрытие недоступно этому профилю, это явная граница retention, а не автоматическое разрешение очистки.

R-H04-A10 / AC-H04-A10: отчёт и интерфейс ALK показывают реально принятый scope и исключения. Запрос более сильной гарантии отклоняется, silent downgrade запрещён. Профиль Codex с ограничениями может быть принят на тех же условиях, что и остальные 11.

R-H04-A11 / AC-H04-A11: релиз требует принятого профиля для каждого из 12 адаптеров, сохранённых доказательств общего ядра и оставшихся независимых CF01/CF02/H05/quality/security/platform/publication gates. Универсального условия «Codex FULL_FINANCIAL» больше нет. Это изменение не объявляет релиз готовым.

## Статусы доказательств

DOCUMENTED_CANDIDATE — штатная возможность описана источником, версия runtime ещё не квалифицирована.
QUALIFIED_SUPPORTED — применимая положительная гарантия доказана для указанного профиля.
QUALIFIED_LIMITATION — граница выбранного профиля доказана и поддержана поведением ALK; это допустимый завершённый результат.
UNQUALIFIED — нужного доказательства для выбранного режима нет.
SUPERSEDED_REQUIREMENT — прежнее обязательство снято пользователем; не PASS технической проверки.

h04-adapter-profile-cases.json содержит 12 кандидатов и минимальные доработки только ALK. Все имеют qualificationStatus=DOCUMENTED_CANDIDATE; ни один не выдаётся за QUALIFIED_SUPPORTED/QUALIFIED_LIMITATION. Исторические 12-host findings переиспользованы без нового общего поиска.

## План применения

P01: независимая проверка этой S2-спецификации и точного изменения приёмки. Сохранить findings; без freeze.
P02: миграция нормативного r10 DRAFT в согласованный r11: R216-ACCOUNTING, AC/EV216-ACCOUNTING-ENFORCEMENT, матрица применимости исходных AC01–AC13, ownership и валидаторы evidence. Исходные кейсы не удаляются и не получают фиктивный PASS; full end-to-end обязателен при заявлении FULL_FINANCIAL, общий core проверяется независимо от хоста. NOT_APPLICABLE допустим только с принятым профилем и обоснованием scope.
P03: общий ALK resolver профиля/запрошенных гарантий и проверка отказа; версия/конфигурация входит в binding. Контракты журнала и уже принятые core tests переиспользовать. Изменять только затронутые случаи.
P04: квалифицировать все 12 по h04-adapter-profile-cases.json; не ждать успеха одного хоста для описания остальных. Каждый пакет ограничен новым доказательством/применимым профилем; широкие повторные поиски и платные Responses-вызовы исключены.
P05: интегрировать только доказанные возможности ALK и провести затронутые проверки. Затем отдельные оставшиеся release gates.

Этот участок завершает решение scope, кандидат спецификации и 12 профилей. Он не маскирует неизменённый r10 как уже мигрированный план и не замораживает его. Изменение user direction уже действует независимо от последующего технического review.

## Риски и остановка исследования

Версионное несовпадение, исключённый маршрут или fail-open завершают оценку именно этой гарантии: записать ограничение и перейти к минимальному профилю. Продолжать искать другой интерфейс только если он конкретно документирован и нужен заявленному режиму. Нет требования любой ценой получить FULL_FINANCIAL у каждого хоста.



The earlier staged migration roadmap in this specification records its preparation context; the r11 binding below retains its H04 ownership and acceptance rules. Its status sentence describes revision 11, not the current manifest.


## Normative r11 execution and evidence binding

The independent S2 specification review permitted PLAN MIGRATION at revision 11, not freeze or runtime acceptance. At that revision the normative manifest was DRAFT/PENDING full-plan review. Revision38 was accepted and locked for its exact historical bytes; its run cannot authorize this successor. The current revision40 is a prepared FROZEN-shape review candidate with its own report/lock absent; this status does not relax H04 ownership, evidence or profile gates. The user scope decision is effective. Old requirements for full H04 on current Codex are superseded.

The release must resolve every capability candidate listed for each of the twelve adapters: QUALIFIED_SUPPORTED, QUALIFIED_LIMITATION, or a reviewed exclusion with exact version/mode/source reason. Choosing LIFECYCLE_ONLY for convenience cannot silently discard a documented candidate. A positive claim requires applicable runtime evidence; a conservative limitation requires evidence for its selected profile and ALK refusal, not an impossible proof that no other host interface exists. Unselected host capabilities remain outside the claim.

### Resolver binding required for final acceptance

Raw per-adapter evidence may be gathered after normative review, but no profile becomes accepted before its ALK resolver refusal proof is validated. The release profile validator joins (a) the frozen expected adapter/version/mode/claims and selected sources, (b) source-bound qualification evidence for those claims or limitations, and (c) resolver test evidence for that exact profile digest and ALK candidate. Missing, stale, mismatched, self-declared PASS, or synthetic-only native-positive evidence fails. The requested guarantee is compared before every ALK-owned dispatch. Unknown versions never inherit latest-doc capabilities. Neither an operator's choice nor the profile's own status creates proof.

Each final profile records adapterId, profileId/revision/digest, host version/range and executable identity, launch mode, provider/transport if relevant, source/unit/coverage and immutable evidence refs, accounting/control/coverage guarantees, exclusions, failure behavior, original-case applicability, resolverEvidenceRef, qualificationEvidenceRefs, and reviewer disposition. Required role routes: coordinator, worker, check, auditor, retry, compaction, closeout; each is COVERED, EXCLUDED or UNQUALIFIED. UNQUALIFIED cannot back a positive accepted claim. Unknown total expense remains null/UNAVAILABLE. Profile totals cannot be represented as complete run totals when any run route is excluded or unknown.

### Exact producer and validation contract

WS216-01 owns support_profiles.py, its pure validation/resolver contract tests and the adapter-profile fixture. WS216-02 owns the twelve-entry catalog, validator, host-launch integration and associated tests, as listed in manifest/write-set. WS216-03 preserves publication gates. No external host code/config/install is owned. Additional per-host hooks are NOT implicitly authorized by directory ownership: add exact reviewed paths before implementing one. Current code has not been changed by this plan migration.

The new unit command validates ALK semantics only. validate_accounting_adapter_profiles.py is a PLANNED offline evidence consumer; it starts no model or native host, accepts --manifest/--profiles-root/--evidence, and emits the EV216-ACCOUNTING-ENFORCEMENT command-observation receipt only after validating all required case IDs and profile evidence. Its successful exit is insufficient without exact case dispositions and inputs. Missing positive runtime evidence fails the affected positive claim; a qualified narrower limitation may satisfy the selected-profile gate.

Limits: exactly12profiles, <=262144 bytes per profile, <=8388608 bytes per referenced evidence artifact, <=64 evidence/source references per profile. Paths resolve under the declared evidence root; reject escaping/symlink-outside paths, missing files, duplicate IDs, invalid enum/type, mixed version/transport/claim bindings, incomplete inventories and mismatched digests. Evidence authority comes from the independently expected plan contract and source bindings, not arbitrary report fields. Original acceptance/receipt/security validators remain applicable.

Core original AC01–AC13 assertions retain their exact source texts and history. Core witnesses remain mandatory regardless of selected host profile. FULL_FINANCIAL additionally requires native end-to-end PASS for every original accounting.ac01..ac13, including all roles/coordinator/final reply. For a narrower profile, list each original native case disposition with selected guarantee, scope, evidence and reason; QUALIFIED_LIMITATION/NOT_APPLICABLE_TO_SELECTED_GUARANTEE never rewrites the original case as PASS. The original AC10 phrase H04 open concerns the full financial guarantee, not a universal release blocker under r11. Merely writing N/A is not qualifying evidence.

Task/run caps and historical accounting remain cumulative. The prior proposed native execution envelope is not enlarged by r11 and is NOT measured fit. Qualification is split into bounded one-profile packets; measure actual input, include every actor in one admitted budget and protect closeout. A packet/host that cannot fit the existing finite envelope stays unadmitted until a prospective bounded amendment; compact is not a reset. No extra implementation/host-model allowance is created here.

### Freeze and release gates

Before freeze: complete transitive owner/producer/consumer mapping, actual packet/budget fit, H05 source/test coverage and unchanged CF01/CF02 prerequisites; obtain real accepting full-plan review and exact matching lock. No review result is fabricated. All12 profiles must resolve their selected claims and link validated resolver refusal plus applicable evidence before release. CF01/CF02, supported Windows/Linux/macOS, quality/security, source pinning and publication gates remain required. Local core evidence is reusable only under its exact applicability.


## Revision 12 — reviewed findings and current authority

r11 full-plan independent review returned CHANGES_REQUIRED (3 High,4 Medium).
r12 addresses S2-R11-H01/H02/M01/M02 in DRAFT; these are author corrections,
not independently closed findings. h04-artifact-contracts.json defines closed
artifact/request/result types, immutable expectation joins, exact comparison and
refusal rules, bounded producers and qualification milestones. The profile-case
file maps all21 profile oracles and all13 original core/native assertions.
WS01 produces pure resolver proof in its own EV; WS02 produces exact-final-profile
refusal after integration. Expected bindings are pinned templates, not runtime PASS; TARGET13 controls runtime qualification.
Before freeze populate and independently review all12 exact target/source/claim
and recipe expectations. Runtime qualification follows implementation and precedes
release. Existing CF02/CF01 transitive design, H05 independent coverage and actual
packet/budget fit remain open; no lock, execution or release approval exists.
Full H04 on current Codex remains optional; all12 scoped profile acceptance remains
mandatory. Earlier revision text is historical where it conflicts with this block.

### Revision12 binding refinements

Use h04-artifact-contracts.json as the typed artifact/producer/comparison authority;
use h04-adapter-profile-cases.json assertionMap for the exact mandatory core versus
conditional native partition. Original source case bodies/statuses/hashes stay intact.
Four resolver-core witnesses belong to WS01; their command and profile fixture are
required by EV216-ACCOUNTING-CORE. They do not qualify the final WS02 catalog.
The21 final cases each bind a concrete oracle and producer; no generic PASS field
substitutes for the reviewed expectation, observations and exact-source refusal.

Expectation entries must be pinned before freeze, with concrete target versions,
executable/configuration and official snapshot digests, selected claims/routes,
candidate IDs and bounded qualification recipes. Current entries are populated expectation templates, pending independent review. Target identity verification and actual evidence joins
occur after implementation, following the reviewed recipe; no future runtime PASS
is required as a prerequisite for implementing the resolver. Unsupported selected
guarantees may become qualified limitations; unqualified candidates remain open.
