# R9 candidate — shared case roster for one-turn bootstrap support

Status: **S2 DRAFT / NOT REVIEWED / NOT NORMATIVE / NOT INSTALLED**. This candidate responds only to the [r327 support-oracle gap](../r327-post-finding-bootstrap/DECISION.md). The installed execution57 r69i plan/lock, R7 delivery spec, v7 source-exposure oracle and v2 support-membership oracle remain authority. WS216-01 native DENY, Release 2.16 NOT_READY.

## Problem and boundary

r326 repaired the two source defects from r325; current C34 55/55 and C35 11/11 are valid. The newly staged r327 subject has no qualifying reviewer request. Its 227986-byte diagnostic request fits only because its WIP and test support blocks omit frozen v2 fields. Restoring the literal required WIP row objects and both complete test receipts with separate case-ID arrays projects approximately 234148 bytes, 4772 over the fixed 229376-byte cap before actual thread ID. The timed loader receipts in that calculation are length placeholders, not evidence. In current support, C34's canonical case list is 7414 bytes and C35's is 1281 bytes; each list would otherwise appear in both the execution and discovery views.

A [nonqualifying size prototype](SIZE-ESTIMATE.json) replaced only the three support values in the current packet with the proposed shared-roster representation and a literal 70-row WIP block. It measured 226486/229376 bytes, leaving 2890 bytes with a measurement thread ID. This is **feasibility evidence only**: loader-discovery UTC fields were same-length placeholders, there is no reviewed R9 authority, and the prototype was not sent to a model. Actual current receipts, real thread ID and fresh model fit must be remeasured after implementation.

This R9 changes only how **duplicate case IDs** are represented inside each inline C34/C35 support block. It does not change source selection, source packet bytes, exact transport, reviewer body/collector, 70-path WIP requirements, raw outputs, case membership, suite-only interpretation, budgets, context reserves, or release gates. It does not change Codex or any adapter.

## Normative transport projection

For each `C34CommandCaseOutcome` and `C35CommandCaseOutcome`, the inline CONTENT value is a canonical JSON object with these fields:

```json
{
  "schemaVersion": "alk-bootstrap-test-support-shared-roster.v1",
  "commandId": "C34",
  "caseRoster": ["full sorted unique test IDs"],
  "caseRosterSha256": "sha256 of canonical caseRoster JSON bytes",
  "executionReceipt": {"all frozen execution fields except testNames": "...", "testNamesRef": "caseRoster"},
  "loaderDiscoveryReceipt": {"all frozen discovery fields except discoveredCaseIds": "...", "discoveredCaseIdsRef": "caseRoster"},
  "stdoutRawBase64": "complete raw stdout encoded once",
  "stderrRawBase64": "complete raw stderr encoded once"
}
```

`commandId` is exactly C34 or C35 and the blocks cannot be swapped. The only permitted reference value is the literal string `caseRoster`. The projection has no other omission or implicit default. An independent ALK checker expands `executionReceipt.testNamesRef` into `testNames=caseRoster` and `loaderDiscoveryReceipt.discoveredCaseIdsRef` into `discoveredCaseIds=caseRoster`, removes the two reference keys, and verifies both expanded objects against the complete private receipts using canonical JSON byte equality. It separately verifies the raw SHA of each private support file, canonical roster digest, exact source hashes and module lists, sorted uniqueness and count, pinned baseline plus only reviewed `test_r69h_*` additions, command digest/argv, stdout/stderr base64 decoding and raw SHA, and one quiet suite-level `Ran N tests … OK` result without skip/expected-failure annotations. The case IDs are discovery identity, not proof that every individual case executed or passed.

The existing 14-key private support roster remains exact. `c34-execution.json`/`c35-execution.json` remain complete and retain `testNames`. `c34-cases.json`/`c35-cases.json` must retain their existing source/case mapping and additionally contain a **separately observed** `loaderDiscoveryReceipt` with the frozen v2 fields: module names, source-file SHA, discovered IDs/count, `unittest.TestLoader.loadTestsFromNames`, actual start/end UTC, and pre/post source equality. Discovery does not execute tests. The checker rejects inferred or recycled timestamps, missing/extra case IDs, duplicate IDs, changed source between discovery and packet, missing support key, changed private file, wrong reference, changed output or unresolved roster baseline.

The WIP block is repaired under the **existing** v2 rule, not this amendment: canonical JSON contains `schemaVersion`, `gitHead`, `installedLockSha256`, `productPathCount=70`, `trackedDiffSha256`, and 70 sorted unique row objects, each with explicit `path`, `gitKind`, `fileKind`, `bytes`, and `sha256`. Before/after inventory and six-path identity stay bound by their SHA and the existing source/WIP checker. No symbolic `=` or array-index row is allowed for these mandatory WIP fields.

The inline source manifest still lists every delivered range and its source path, before/current full-file identity, delivered bytes/SHA, generation rule and inclusion reason. CONTENT/IDENTITY_ONLY claims remain explicit; an identity-only digest never implies semantic inspection. The complete canonical subject JSON and its computed full SHA remain in the same input. ALK saves and writes exact serialized request bytes, compares ordered completed input and final item after two stable `thread/read` calls, and refuses tools, changed source, malformed body or stale cost.

## Limits, refusals and acceptance

The serialized one-turn request stays at most **229376 UTF-8 bytes**. Fresh selected-model evidence must satisfy `requestBytes + 8192 output reserve + 16384 safety <= modelContextWindow`; actual child window and host-hidden input remain UNPROVEN. No compression that the tool-free reviewer must decompress is permitted. If the full mandatory packet cannot fit, return REVIEW_INCOMPLETE before model start; do not trim source/support, raise the cap silently, consume the protected closeout reserve or auto-retry. Keep r69i's 300000-token bootstrap hold, 200000 work allocation, 100000 protected closeout, measured usage or full unknown hold, and cumulative prior unknown holds.

Acceptance requires: (1) independently reviewed R9 spec; (2) isolated successor plan DRAFT/FROZEN S2 reviews and canonical verified lock with a pinned v3 support-membership oracle and corresponding v8 source-oracle reference; (3) ALK-only implementation in the existing six temporary owned paths plus support construction, with negative fixtures for wrong/missing roster ref, reordered/duplicate/mismatched IDs, changed source, forged discovery times, missing support, swapped C34/C35, wrong base64/SHA, incomplete output, over-cap and stale fresh read; (4) exact current C34/C35 receipts, full request/selected-host fit and one independent reviewer-authored v4 PASS with closed collector; (5) separate fresh first-native gate and task-bound LIMITED outbound preflight. None of these conditions can be inferred from this draft or r325's complete FAIL. RB11-RUNTIME, WS216-02/03, all-12/H04/H05/A5, security/platform/publication/final audit remain open.

Write ownership for the plan stage is an isolated Release 2.16 normative plan worktree; installed execution57 lock and product WIP are read-only. Later ALK adaptation is serially limited to the existing frozen temporary lead-owned paths and evidence builders; no adapter or Codex write. The successor plan must name exact owners and artifact paths before freeze. Rollback is refusal to install the successor lock and retention of r69i authority; prior model bodies and test receipts remain immutable historical evidence.
