# Release 2.16 pre-freeze fit and post-lock proof contract (revision 40 candidate)

## Revision69 current DRAFT — current-Codex limited outbound proof

This isolated plan candidate has parent r68e verified lock SHA `a619308da56efc1fe0c23a65de9b8c04074e79e93d7247f02958b5a831af6c66` and accepted S2 specification SHA `c69a24fa6170ba4a509048c2d4cf218f970f793431bc2cce6e08ce8687dec018`. It is not reviewed or locked. All historical revision paragraphs below describe their then-current states; the r69 rules in `route-bootstrap-contract.json#limitedFitApplicability` and `alk-input-fit-contract.json#r69FitDisposition` govern this candidate. r68e remains installed authority; native WS01 DENY, Release NOT_READY.

The proposed current-Codex positive claim covers only ALK-constructed bytes accepted by the OS stdin pipe associated with the selected child, not model-visible input or child consumption. Per-role fresh diagnostic and catalog are prelaunch candidates, not future native equivalence. Strong host-fit/financial requests refuse before dispatch. After observed Popen, only complete same-attempt pipe write/close plus joined native success/usage can pass the new limited case; failure retains unknown cost. Original strong IF09/IF12 remain NOT_RUN for this limited profile. All other accounting, H05/A5, 12-adapter, privacy, 30-day cleanup, hourly scheduler, security/platform/publication and final-audit gates remain.


## Revision68 current draft: source-bound RB11 and maintenance handoff

This is the exact r68 draft successor to the reviewed r176 specification SHA `b4a00c69751e67bfc81c277d38e0f2904c7f862ef461bdc596feb4019a1dc413` and current r67b lock SHA `56766d2d39988723484ce412523bbb34ab6ac6ae31f9e5deae1c96a779b6e561`. r67b remains operative until a separately accepted full S2 review, matching report and canonical r68 lock. No present product test or native/model result transfers to newly added cases.

Pre-WS01 lead owns only the six unchanged bootstrap paths; C34/C35 and independent audit cover RB01–RB12-PRE, with RB11-PRE limited to pure fully-closed eligibility/refusal. RB11-RUNTIME is `NOT_RUN` at that audit. WS01 owns journal/finalization/private authority and durable raw cleanup after SQL collection; WS02 owns the existing lifecycle CLI and new maintenance test; WS03 owns the operational document and installed hourly target schedule. Combined RB11 `PASS` is final-release-only after all three runtime owners and a supported-platform target probe. The old two-command prestart limit does not consume poststart commands.

The maintenance command uses a pinned private authority SHA and accepts no independent journal/root override. Started raw details delete only after authoritative full financial closure plus 30 days; unresolved runs have no purge clock. An immutable raw inventory and per-run pending obligation survive SQL collection and partial/crash unlink, with hash-only totals/dedup/closure state retained. The journal write-admission boundary covers fresh closure, due and financial-exception checks through bounded unlink and obligation result. Windows/macOS/Linux targets prove equivalent private path, identity and race-safe deletion behavior or refuse before unlink, retain PENDING/OVERDUE and block retention readiness. Same-user Codex does not gain a protected-close claim.

The independent bootstrap review uses a separately admitted local Codex App Server candidate, distinct review thread, completed item/turn, raw-text SHA and live `thread/read` verification. Documentation and installed schema are only interface candidates; runtime qualification is `NOT_RUN`. Selected-host positive IF09/IF12, all12 adapters, H04/H05/A5, numeric, security/platform/publication and final independent audit remain required. The current Codex claim is only `ALK_CONTROLLED_INPUT_FIT`; full host input/U/FULL_FINANCIAL and protected close remain unavailable. Missing native or review proof denies launch, and missing retention target proof blocks release.

## Revision67 exact scoped-fit preview

Regenerate exact r67 packet, source and six-role context preview before independent review. 4k/8k refuse; local16k is conditional on selected-host proof. The limited ALK_CONTROLLED_INPUT_FIT profile does not establish complete host input or whole-call U.

## Revision66 exact current preview disposition

`r66FitDisposition.localWindowDisposition["16k"]` denotes only exact r66 local preview PASS, with selected-host/native scoped proof PENDING; its `previewPath` must match this candidate manifest SHA/digest and 18 ordered refs. The r65 preview and r64 preview are historical and cannot qualify r66 bytes. 4k/8k refusal, six-role bound, private/process proof, 300,000-token pre-run coordinator allocation and all 3,000,000/12,000,000 planning ceilings remain.


## Revision65 DRAFT source and budget fit

The new `route-bootstrap-contract.json`, C35 process cleanup command, two WS216-02 future write paths and two-phase artifacts change exact r64 source/packet bytes. Rebuild r65 source-bound public packet and all-role local preview before plan review; prior r64 4k/8k refusal remains and 16k is conditional on selected-host evidence, not inferred from local bytes. The pre-WS01 bootstrap has a separate coordinator ceiling 300,000 model tokens (200,000 work, protected 100,000 closeout), at most 40 requests, two targeted commands and 1,800 seconds; full reserve stays held if actual telemetry is unavailable. It does not expand 3,000,000 task/12,000,000 run planning ceilings or prove inclusive H04 enforcement. Native launch still requires r65 lock and fresh selected task/attempt route fit. The current public packet index has 18 ordered context refs, adding `route-bootstrap-contract.json`; IF04 and the exact pre-review preview must bind this revision.


## Revision64 exact FROZEN-shape scoped fit preview

The accepted r63 preview binds DRAFT bytes only. Rebuild exact r64 25-source packet/six-role/final-prompt preview before independent review. `r64FitDisposition` and `r64RuntimeArtifacts` are current only after exact reviewed r64 lock; 4k/8k refuse, local16k remains conditional on selected route/native evidence. Complete-host fit, FULL_FINANCIAL and whole-call U remain unproven; IF04 binds the exact ordered current 17 context refs.

## Revision61 current-Codex exact-prompt conditional fit

The r61 scoped route supersedes r60 only for `ALK_CONTROLLED_INPUT_FIT` and only after exact independent review/lock. A local packet/envelope preview is not final canonical prompt or native proof. Prelaunch stdin transport, private config snapshot, role inclusion/caps and output reserve must be proven before runner; 4k/8k and stronger complete-host/FULL_FINANCIAL requests refuse.

## Revision60 exact FROZEN-shape fit preview required

The r59 preview binds DRAFT bytes only. Rebuild exact r60 source/packet/six-role ALK envelope preview over the current 25 source files before independent review. The r60 current-Codex limited prelaunch rule is `r60FitDisposition`; older r57–r59 complete-host input requirements are historical only for this scoped `ALK_CONTROLLED_INPUT_FIT` claim. 4k/8k still refuse, 16k remains conditional on independently reviewed lock, exact native packet, selected-route receipt and native evidence. Complete-host fit/FULL_FINANCIAL require stronger proof; host input/U remain UNAVAILABLE. IF04 requires the exact current 17-entry ordered list.

## Revision59 current-Codex scoped-fit precedence and IF04 inventory

For the current r59 DRAFT, `r59FitDisposition` is the sole prelaunch rule for a current-Codex `ALK_CONTROLLED_INPUT_FIT` claim. The r57/r58 and revision28–57 full-host-input instructions below are historical for that limited claim; they still govern any complete-host 16k fit or stronger financial claim. An r59 scoped 16k route requires the exact reviewed lock, native packet/ALK component and cap receipt, selected Codex identity and fresh diagnostic prompt inventory, available window and planned output reserve. It does not prove host-owned prompt/history/tool/format tokens. 4k/8k remain refused; missing scoped data or stronger claims refuse before launch, and host failures preserve costs. The live IF04 source-index oracle requires exact ordered equality with all 17 current `contextRefs`, not a historical fixed count. Global source validity, native comparison, H04/H05 and release gates below remain operative.

## Revision58 Choice B limited Codex input-fit boundary

The user approved a narrower current-Codex `ALK_CONTROLLED_INPUT_FIT` profile, not a complete-host fit guarantee. The r57 full-host requirement below remains historical and applies to any future complete-fit claim. For r58 prefreeze, remeasure exact source/packet/ALK role envelopes for the current DRAFT: 4k/8k refuse, 16k may be conditional only. Before scoped native admission require a distinct accepted r58 lock, matching public packet/preview, exact ALK component caps, same-route fresh Codex diagnostic prompt inventory, selected binary/version/model/config/cwd, available host catalog window at least 16,384 and explicit 3,072 planned output reserve. This route accepts residual unmeasured host-owned prompt/history/tools/format tokens; never label local estimates or observed completion as full 16k fit. Refuse missing/mismatch/stronger requests prelaunch, and classify host overflow/truncation as failure retaining costs. H04 whole-call U remains separate and UNAVAILABLE.

## Revision57 exact candidate fit preview required

The r56 local preview is historical after changing the manifest to r57 FROZEN shape. Rebuild `work/release-2-16/enforcement-decision/r77-r57-freeze/r57-exact-pre-review-preview.json` over the exact 25 files. 4k/8k routes remain refused; 16k remains denied pending actual selected host/version input and reserve fit before native launch. Host-owned input and whole-call U remain UNAVAILABLE. This shape supplies no H04 or native proof.

## Revision56 source-bound conditional fit

Rebuild exact r56 local preview at `work/release-2-16/enforcement-decision/r76-r56-case-binding/r56-exact-pre-review-preview.json`; the r55 preview is historical. 4k/8k routes remain denied, 16k remains denied until selected actual host/version input and reserve fit before native launch. Host-owned input and whole-call U remain UNAVAILABLE; local preview grants no H04 or native acceptance.

## Revision55 source-bound conditional fit

Rebuild exact r55 local source/renderer preview at `work/release-2-16/enforcement-decision/r75-r55-plan-rework/r55-exact-pre-review-preview.json`. The r54 4k/8k FAIL and conditional 16k PASS are historical. Until r55 preview and actual selected host/version input before native launch, deny native 16k; host-owned input and whole-call U remain UNAVAILABLE. This planning edit grants no H04 or native acceptance.


## Revision54 correction candidate — independent full S2 review pending

Revision54 resolves r53 M04 by permitting only a reviewed conditional refusal at prefreeze: exact local source/renderer preview (`r74-r54-plan-rework/r54-exact-pre-review-preview.json`) measures all three workstreams: 4k/8k FAIL/refuse, 16k local PASS but remains denied until the selected actual host/version input and reserve fit are proven before native launch. Host-owned input and whole-call U are UNAVAILABLE, never zero. No local preview substitutes for H04 or native acceptance.


## Revision53 fit remeasurement required

The r52 preview does not measure the two new r53 normative inputs or revised WS01/WS02/WS03 context refs. An exact r53 local preview (`r73-r53-plan-draft/r53-exact-pre-review-preview.json`) measures 4k-strict and 8k FAIL for all three workstreams and 16k PASS locally for all three; 16k remains conditional on actual host/version input. Rebuild the exact r54 source-bound local preview before freeze. The plan may freeze only a conditional refusal: 4k/8k routes deny, and 16k denies until actual host/version input and reserve fit are proven before native launch. Host-owned input and whole-call U remain UNAVAILABLE. Small-window routes remain refused. This candidate is unreviewed; r52 stays locked.


## Revision52 current-candidate fit authority

Exact revision52 pre-review preview measures WS216-01/02/03 4k-strict and 8k FAIL, 16k local PASS conditional on the actual existing host/version and native/host input. All three workstreams must refuse the measured smaller-window routes; historical r27 WS216-03 PASS used different selected inputs and empty tool output. No local preview establishes target-host qualification or cumulative H04 enforcement.


Revision36's independent review found that its preview saved only failed renderer checks. Revision38 supplied a complete preview and received an accepting review, but those exact bytes do not cover revision40. Revision40 must save all per-window `receipt.checks`, counts and limits, plus explicit non-token cap outcomes, before its own accepting review. A failed or missing preview remains a pre-review blocker even when its overall 16k route estimate passes.

Revision34's structurally valid lock was superseded without adoption because an exact candidate-bound preview had not been saved before its independent accepting review. Revision36 later presented a preview, but not all required check details. Revision40 must present its own complete exact preview, six-role/fixture inventory and cap receipts to its independent reviewer before any accepting report. A later native fit result cannot retrospectively fill this pre-review gate.

This contract resolves the order of measurement, review, freeze and native proof. It does not lower any task/run cap, H04 guarantee, H05 coverage obligation, adapter qualification, test, platform or release gate. An estimate is never a provider-enforced limit. Missing use or host input is `UNAVAILABLE`, never zero.

## Revision31 — local-profile process start

The `managedTask` input-fit receipt must be checked in the existing WS216-02-owned `launch_preflight.py` immediately before its `context.runner` call, including direct `launch_from_local_profile` entry through `unified_start.py`; checking `continuation.py` or `launch_execution.py` alone is insufficient. IF05/IF07 negative routes require no process start on missing, stale, wrong or over-limit receipt. The reachable `planningTask` path is a limited non-run operation: it cannot inherit Release 2.16 task/run fit or FULL_FINANCIAL, and a stronger request refuses before `run_planning_launch` (IF08). These are planned ALK-only integration obligations, not current behavior.


## Revision30 — mandatory ALK input-fit design before accepting review

The pinned `alk-input-fit-contract.json` is the candidate ALK-controlled source-selection and six-role inclusion/refusal design. All 17 revision60 `contextRefs` are index entries; explicit source excerpts need complete-file hash, range, selected-byte hash and candidate/host/window/estimator binding before an ALK-built model dispatch. Each dispatch allows at most two excerpts, 1,024 UTF-8 bytes each and 2,048 total, then must pass every component and total envelope check. IF01–IF04 belong to WS216-01 pure selection/limits under C18; IF05–IF08 belong to WS216-02 dispatch/consumer integration under C20. Future test outputs remain `PLANNED/NOT_RUN`. A missing component, unknown host input/U, over-limit receipt or unqualified route refuses the affected claim; no host-owned bypass is presented as ALK control.

For prefreeze measurement, bind representative exact source slices and conservative allowed maxima for worker, validator, auditor, retry, coordinator and closing inputs to that contract. The 16k profile caps rendered envelope at 12,288 estimated tokens plus 3,072 reserved output, with active packet 5,000, state summary 1,800, evidence summary 1,500 and tool output 1,024 component caps. The exact renderer still decides actual candidate bytes; numerical component caps do not prove a future request or actual host fit. Any insufficient route must refuse or use a separately reviewed split. Post-lock native and post-implementation host checks remain required.

## Revision28 — small-context route for the current unsplit workstreams

The read-only r27 source-derived projection at `work/release-2-16/enforcement-decision/r27-h05-narrow-review/context-source-summary-projection.json` (SHA-256 `adb744a8a0df0f34730e5a8ae61e8d5c216c15b18efe5fd9b0f55f1f96f57e3b`) used the current packet builder, state-summary builder and `profiles/small-context-profile.v1.json`. For WS216-01 and WS216-02, the 4k-strict window fails active-packet and state-summary caps; the default 8k window fails the state-summary cap (973 and 964 estimated tokens against 900). Both pass the local 16k profile checks. WS216-03 passes the local 4k-strict, 8k and 16k checks. These are candidate-side estimates with empty tool output, not whole host-input measurements or proof of target-host availability.

The current **unsplit** WS216-01 and WS216-02 packets must refuse 4k-strict and default 8k dispatch. Their proposed route is a 16k target only when the existing host/version actually supports that window and the exact candidate, reserved output, selected source/state/evidence/tool components and applicable native/host limits pass. If no such qualified route exists, stop dispatch and propose a separately reviewed split or other plan revision; never silently truncate context, downgrade requirements or relabel a local PASS as actual fit. WS216-03 may use a smaller window only after the same exact candidate and host qualification. Bind each route selection and refusal to workstream, host/version, window/profile, candidate digest and measured input inventory; remeasure affected inputs after revision. This route decision changes no reported-token task/run ceiling and grants no H04 enforcement claim.

## Exact candidate and preview, before accepting review

Bind manifest revision, SHA-256, plan digest, all declared plan-file bytes, repository HEAD and tracked diff, ALK packet-builder/serializer version, context renderer/estimator version, and role/profile matrix. Produce a read-only `DRAFT_PREVIEW` for every workstream from the same packet builder and canonical serializer used by `compile_task_packets`. The preview may omit only the public compiler's FROZEN/lock prerequisite; it must not write a lock, run state or native packet or use an unreviewed preview as execution authority. Record packet bytes, hashes and every cap check. If a projected FROZEN/report-bound field cannot be known before review, mark it `PENDING_POST_LOCK_COMPARISON` and conservatively reserve its maximum specified size. The preview is not actual native compilation.

Before review, inventory the ALK-controlled dispatch component types for every role: worker, validator, auditor, retry, coordinator and closing work. Measure exact existing renderable candidate bytes (including packets), selected source fixtures and conservative allowed-size envelopes for future-generated context, state/evidence summaries, tool outputs, instructions, schemas and output reserve. Record hashes/byte counts for actual candidate bytes and provenance, inclusion rule, task/run attribution, estimator version and bounded maxima for planned components; mark unavailable future values `PLANNED/NOT_RUN`, never fabricated exact inputs. Compare packet/context and non-token limits plus the proposed 3,000,000/task and 12,000,000/run reported-token planning ceilings, including attempt/closeout reserves. Keep host-owned hidden prompt/history/request formatting and missing receipts separately `UNAVAILABLE`. Do not label local estimates as actual full model-input tokens or proof of provider-enforced fit.

Before review, every proposed hard financial profile must bind official, version-specific host documentation for compulsory pre-dispatch control, enforceable whole-call U, authoritative final usage and the claimed role scope; the ALK design must map those interfaces to task/run admission, settlement, owners and positive/negative oracles. If host support or U is undocumented, mark FULL_FINANCIAL inapplicable for that route. A narrower profile must specify its exact limitation and ALK refusal design for stronger requests, with owner and executable oracle planned; actual refusal is proved after implementation. Documentation and design are prefreeze feasibility evidence, not runtime qualification. Independently review H05 **design coverage** before freeze: each requirement/AC/EV must map to primary source, planned positive/negative test oracle, command/case ID and owner; future outputs stay `PLANNED/NOT_RUN` and gaps remain explicit. Later H05 **executed coverage** requires actual source/test identities and results after implementation. The independent reviewer receives exact candidate identity, input inventory, measurement receipts, profile/refusal matrix and both H05 mappings. No accepting review is valid if these are missing or a proposed cap is treated as enforcement.

## After an accepting review and real lock

Bind the independent accepting report to the final manifest and declared plan files, freeze the reviewed candidate, create its reviewed lock, and run the public native compiler. Compare native packet bytes/hashes, input inventory assumptions, context caps and budget fit with the reviewed preview. Any material mismatch reopens only affected fit and exact-byte review before adoption. A passing preview alone never permits native admission.

## During execution and final release

After implementation and before accepting each profile or releasing it, execute ALK admission/refusal, authoritative usage, cumulative reconciliation and exact-profile positive/negative oracles on the version-bound supported host route; record actual source-bound usage/receipts, reservation and settlement, including retries, coordinator and closing work. Preserve prior overruns and unknown openings. Execute H05 source/test coverage against actual files and results, adapter route/refusal proof, platform, storage, security and final audits. Observed `turn.completed` or thread token counters are post-use evidence, not proof of a future U. A profile with unknown U cannot gain FULL_FINANCIAL from a successful completed turn. The release remains blocked until all its mandatory accepted-profile gates have actual evidence.
