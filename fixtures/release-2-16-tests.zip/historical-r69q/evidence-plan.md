> **Current r69q exact FROZEN role-delivery candidate.** Current delivery authority is r69q-role-delivery-delta.md and r69q-role-contract.json. Superseded v4/v5 delivery/count/budget/roster/status passages below are historical ONLY for that enumerated delta; all unchanged product/ownership/security/native/release requirements remain mandatory. Exact DRAFT/FROZEN review and canonical lock required before transfer; installed r69p remains authority. C34 candidate96/C35=16; no implementation or host proof. WS216-01 DENY; Release NOT_READY. r413 exact r69q DRAFT accepted fullReview=true READY_TO_FREEZE, report SHA 4770d7fc3ecd16b5d2da2609ca3635ec2cdfce71eae066541643d24c00b9797d. Exact FROZEN shape requires its matching independent report, canonical lock and verified transfer; implementation/host/native/release proof not granted by plan status.

> **r69k R10 FROZEN shape pending exact review.** r352 independently accepted the corrected 50-file DRAFT subject (body SHA `93cecf316b40a6564bf877bb5f3d253544f6c0576116c78a05b49088013e8079`) with fullReview=true and no findings. This candidate changes only status, review metadata and top historical notices; the FROZEN-shape report and canonical lock are absent. The verified installed r69j parent lock `c96f464a845c7e69a4fd08af705d55cffb3a4db328cf1eb5a1eef17b9d4d894b` remains authority. Older notices and DRAFT text below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69k R10 isolated DRAFT; independent plan S2 pending.** r348 independently accepted corrected R10 specification SHA `14e5fbba22aa6258ba051abccffec3a0b07b97a9e7174d20491889dbaa43bfda` for plan drafting only. This candidate raises the one-turn request cap to 245760 bytes and binds r69k successor to verified r69j parent. The installed r69j lock `c96f464a845c7e69a4fd08af705d55cffb3a4db328cf1eb5a1eef17b9d4d894b` remains authority; r69k has no independent plan review or lock. Older notices below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69j R9 FROZEN shape pending exact review.** r333 independently accepted the exact corrected DRAFT subject (raw reviewer body SHA `858e61c9211e114ed3392f1dd8425654857265e573b6a09312e4a6a98dededa2`) and closed R331-S2-M01. This candidate changes only status, review metadata and top historical notices; the FROZEN-shape report and canonical lock are absent. Older notices below are historical. Installed r69i parent lock `721d7e3fa60723d59708efddfe2166347af5abc0981d47153527b00382f0bd67` remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69j R9 isolated DRAFT; independent plan S2 pending.** r329 accepted exact R9 specification SHA `965d2c4c02d4dc80b9538288355294391feb94a0f3bd1e6899c0a3b070bf5d03` for plan drafting only. Candidate v3 support oracle `671ed21d004beedecb80e1785a478e1eb95375a3593df3cd0a731a0151a3b84e` and v8 source oracle `d19e5edb56f4908c949f4239763038915f27798f54e8cdbbc13db6a361f93834` are not installed. Parent r69i verified lock `721d7e3fa60723d59708efddfe2166347af5abc0981d47153527b00382f0bd67` remains installed in execution57. No r69j plan-review report or lock exists; WS216-01 native DENY and Release NOT_READY. Older notices below are historical.

> **r69i R8-R3 FROZEN shape pending exact review.** r301 independently accepted the exact DRAFT subject (raw reviewer body SHA `f96bbe126d9f2dd7bbcf996608a4cbf978d9ff8c39227deab75453878f4ab9fd`). This candidate changes only status, review metadata and top historical notices; its future independent report path is declared but the FROZEN-shape report and canonical lock are absent. Older DRAFT notices below are historical. Installed r69h lock `a1d7a69a05f5887b72165613ebb116bf59f2bf52b59d6f851c66b977c284976c` remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69i R8-R3 isolated DRAFT; independent plan S2 pending.** r299 independently accepted exact R8-R3 specification SHA `bef13eb0608b604ffb88a659abe8b0d940046b52ff5ca2f732eecd48ed924cb7` and source oracle SHA `5f7b3cee3f074ebfbf4129bd4058d38116ef8385be20e6fbcd965158bc07a4fe` for plan drafting only. This candidate overlays the `codex_exact_prompt.py` FULL-source row with typed AST slices and local dependency closure; all other R7/v6 requirements remain. Parent r69h verified lock `a1d7a69a05f5887b72165613ebb116bf59f2bf52b59d6f851c66b977c284976c` stays installed in execution57. This r69i candidate has no plan-review report or lock; WS216-01 native DENY and Release NOT_READY. Older r69h/r69g notices below are historical.

> **r69h R7 FROZEN shape pending exact review.** r288 independently accepted the prior DRAFT subject (raw reviewer body SHA `1a5a331060a81d40e9be6a366856ad4742004567520d91526883485ccd4e6399`). This candidate changes only status, review metadata and overview notices; its future independent report path is declared but the FROZEN-shape report and canonical lock are absent. The older DRAFT notice below is historical. Installed r69g remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69h isolated R7 DRAFT — current delivery authority.** r286 independently accepted R7 specification SHA `b54ebc77c4cc89aed0d809a4d193a15a61e7132a651f6db18f6dc98051732ab1` and oracle v6 SHA `aa25670dc55f6c1fb28ba249b9f24dc6115e470e13e0a6d75166ed2023edb702` for plan drafting only. The copied specification preserves its historical pre-adoption status; this candidate now pins R7/v6. Installed r69g lock `673715e292661c13b6d9c7222434d60b2c0247a54a61d45cf5bd3861c3043a99` remains authoritative. r282's R5/v4 DRAFT review was CHANGES_REQUIRED; this amended DRAFT has no independent plan acceptance or lock. Older delivery notices below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69g FROZEN shape pending exact review.** r254 independently accepted the prior DRAFT subject (raw reviewer body SHA 023d7fd1873d6094ef474f6ddc68e908fc28cc5dbf62e3d0f2891707fbeb58a4). This FROZEN-shaped candidate changes status/review metadata and overview notices only; its report path is declared but the independent FROZEN-shape report and canonical lock are absent. Older DRAFT notices below are historical. Installed r69f remains authoritative; WS216-01 native is DENY.

> **r69g r251 S2 correction.** The closed receipt requires matching second request/response IDs, the exact written request SHA, completed second-turn input item and full ordered two-turn input/output sequence SHA; fresh read must recompute them. Selected-host pre-send context fit includes the larger of completed first-turn total tokens and all first-turn item transcript UTF-8 bytes, plus second-request bytes, 8,192 output and 16,384 safety tokens. Missing input or fit is DENY. The installed r69f lock has no `acceptedSpecSha256` key at any JSON path; exact lock SHA and field witness are in `route-bootstrap-contract.json#parent`.

> **r69g r248 S2 correction.** PASS requires exact `NO_CURRENT_FINDINGS` (optional one newline) and zero findings, including P3. The second request must be the exact saved bytes actually written and correlated with response ID, completed turn/input item, ordered dual-item thread read and fresh reread. Its raw review is capped at 32,768 UTF-8 bytes and serialized request at 65,536; before send, the selected host must report a context window satisfying first-turn max input tokens + request bytes + 8,192 output reserve + 16,384 safety tokens. Unknown/oversize is DENY with preserved evidence. The r242 accepted-spec SHA is the successor binding, not a claim about the installed r69f parent. Runtime qualification remains pending.

> **r69g DRAFT delivery successor.** Installed r69f lock SHA 45a280b5dfc5e83e88d6c1f4d635b9ace7e5d1adaf3f9795a1215288bfe54dd5 remains authoritative. Exact independently READY_TO_DRAFT S2 specification SHA 6e7981627ffa616a7fabba856dca343e6f43c5eeda773d0eb87a572bdc7a0e1a is copied as `review-delivery-spec.md`. The current candidate replaces the reviewer-body producer with a same-thread `turn/start.outputSchema` item after `review/start` text; it requires the clean sentinel, full-subject saved request, dual-item collector/fresh read and unchanged PRE limits. Older r69 review-delivery paragraphs below describe historical candidates and do not override `route-bootstrap-contract.json#auditJoin.delivery`. No native WS216-01 from this DRAFT.

# Evidence plan — revision 9

## Revision69b corrected DRAFT — exact limited native qualification

The active current-Codex profile and all three 16k workstream selectors use `ALK_CONTROLLED_OUTBOUND_INPUT_FIT` only. The retained config artifact binds credential-free ALK-controlled source bytes/SHA; Codex internal effective-config equality remains `UNPROVEN` for this claim. `route-bootstrap-contract.json#validation.limitedNativeMatrix` is the executable 24-row, six-role evidence contract: a separately admitted maximum of six selected Codex positive calls, 12 predispatch refusals without a model and six controlled local started-failure fixtures. Each row binds role, polarity, command template, producer, oracle, run/task/attempt/claim/lock and receipt path. Local fault rows cannot count as selected Codex native positive; original strong IF09/IF12 remain `NOT_RUN` for this limited profile. The exact r69b preview and review/lock are still pending; r68e remains installed authority and native WS01 is `DENY`.

## Revision69 current DRAFT — current-Codex limited outbound proof

This isolated plan candidate has parent r68e verified lock SHA `a619308da56efc1fe0c23a65de9b8c04074e79e93d7247f02958b5a831af6c66` and accepted S2 specification SHA `c69a24fa6170ba4a509048c2d4cf218f970f793431bc2cce6e08ce8687dec018`. It is not reviewed or locked. All historical revision paragraphs below describe their then-current states; the r69 rules in `route-bootstrap-contract.json#limitedFitApplicability` and `alk-input-fit-contract.json#r69FitDisposition` govern this candidate. r68e remains installed authority; native WS01 DENY, Release NOT_READY.

The proposed current-Codex positive claim covers only ALK-constructed bytes accepted by the OS stdin pipe associated with the selected child, not model-visible input or child consumption. Per-role fresh diagnostic and catalog are prelaunch candidates, not future native equivalence. Strong host-fit/financial requests refuse before dispatch. After observed Popen, only complete same-attempt pipe write/close plus joined native success/usage can pass the new limited case; failure retains unknown cost. Original strong IF09/IF12 remain NOT_RUN for this limited profile. All other accounting, H05/A5, 12-adapter, privacy, 30-day cleanup, hourly scheduler, security/platform/publication and final-audit gates remain.


## Revision68c exact r181 field correction

`independent-audit.json` is produced by the ALK post-completion collector, while `reviewer-body.json` is the immutable raw App Server reviewer text. Their path, producer, UTF-8 byte rule, hashes, consumer and first-native live re-read agree in the current route and fit contracts; the lead only later links SHAs. `r68FitDisposition.effectiveConfig` names the retained credential-free effective-config.json as the started raw source, independently equal to the child effective config. CODEX_HOME is credential-only ephemeral and excluded from that inventory; failure to separate refuses before start.

C34/C35 and the WS02 task EV use only `RB11-PRE`. Bare `RB11` is a machine final-release aggregate in the WS03 publication EV target-probe receipt after RB11-PRE and every one of the 11 owner-mapped WS01/02/03 runtime case receipts; no local helper or WS02 acceptance can emit combined PASS. The current r67b lock, selected-host IF09/IF12, App Server runtime, target maintenance and all other release gates remain pending.

## Revision68b exact correction of r179 findings

The reviewer-authored `reviewer-body.json` is the exact completed App Server review text, closed schema and raw UTF-8 SHA. It cannot contain its own SHA or a later server read. After completed item/turn and `thread/read`, the ALK collector writes `independent-audit.json` with server IDs, exact raw-body SHA and canonical stable item-projection SHA; first-native admission reopens the item and verifies both, then the lead's later SHA join. Actor strings alone never qualify. Both artifacts and the selected-host positive IF09/IF12 remain `NOT_RUN` until separately admitted live qualification.

The active first-native authority is the exact reviewed r68 successor lock; r67b appears only as the locked parent. Prestart C34/C35 prove RB11-PRE only. Started raw request, diagnostic and credential-free effective config source are sealed in an immutable private inventory with a hash-only pending marker before possible start and handed to WS01's durable per-run obligation. Only credential-only ephemeral CODEX_HOME material may be removed at child exit; the retained config source and other started raw wait until authoritative full closure plus 30 days. Missing source equality or safe credential split refuses before start.

`route-bootstrap-contract.json#validation.phaseEvidenceMap` is the one-to-one binding for five WS01 journal, three WS02 CLI and three WS03 target case IDs to owner AC, EV, exact command digest and receipt path. Each phase has a separately admitted finite budget; these are subsets of existing task allocations, not extra prestart C34/C35 slots. WS03 owns `tests/operations/test_retention_maintenance_target.py` and the operation document; its static command executes against the selected release target's actual installed scheduler and ALK command, recording scheduler identity/cadence, journal/root/authority SHA and real no-due/due/overdue outcomes. Local mock or unqualified platform deletion cannot close combined RB11 or retention release readiness.

## Revision68 current draft: source-bound RB11 and maintenance handoff

This is the exact r68 draft successor to the reviewed r176 specification SHA `b4a00c69751e67bfc81c277d38e0f2904c7f862ef461bdc596feb4019a1dc413` and current r67b lock SHA `56766d2d39988723484ce412523bbb34ab6ac6ae31f9e5deae1c96a779b6e561`. r67b remains operative until a separately accepted full S2 review, matching report and canonical r68 lock. No present product test or native/model result transfers to newly added cases.

Pre-WS01 lead owns only the six unchanged bootstrap paths; C34/C35 and independent audit cover RB01–RB12-PRE, with RB11-PRE limited to pure fully-closed eligibility/refusal. RB11-RUNTIME is `NOT_RUN` at that audit. WS01 owns journal/finalization/private authority and durable raw cleanup after SQL collection; WS02 owns the existing lifecycle CLI and new maintenance test; WS03 owns the operational document and installed hourly target schedule. Combined RB11 `PASS` is final-release-only after all three runtime owners and a supported-platform target probe. The old two-command prestart limit does not consume poststart commands.

The maintenance command uses a pinned private authority SHA and accepts no independent journal/root override. Started raw details delete only after authoritative full financial closure plus 30 days; unresolved runs have no purge clock. An immutable raw inventory and per-run pending obligation survive SQL collection and partial/crash unlink, with hash-only totals/dedup/closure state retained. The journal write-admission boundary covers fresh closure, due and financial-exception checks through bounded unlink and obligation result. Windows/macOS/Linux targets prove equivalent private path, identity and race-safe deletion behavior or refuse before unlink, retain PENDING/OVERDUE and block retention readiness. Same-user Codex does not gain a protected-close claim.

The independent bootstrap review uses a separately admitted local Codex App Server candidate, distinct review thread, completed item/turn, raw-text SHA and live `thread/read` verification. Documentation and installed schema are only interface candidates; runtime qualification is `NOT_RUN`. Selected-host positive IF09/IF12, all12 adapters, H04/H05/A5, numeric, security/platform/publication and final independent audit remain required. The current Codex claim is only `ALK_CONTROLLED_INPUT_FIT`; full host input/U/FULL_FINANCIAL and protected close remain unavailable. Missing native or review proof denies launch, and missing retention target proof blocks release.

## Revision68b current accounting evidence join

EV216-ACCOUNTING-ENFORCEMENT requires exact independently reviewed r68 successor lock, matching plan/packet/attempt, immutable independently delivered reviewerBody, later ALK collector receipt with live App Server item verification, and lead later result-SHA join before first native task. Started process-start/input/result evidence and prelaunch no-start refusal remain separate. Earlier r66 lock wording is historical.

## Revision66 bootstrap independent audit receipt

An independent reviewer, not the lead, produces `evidence/route-bootstrap/independent-audit.json` with typed PASS/FAIL, distinct actor/session provenance, r66 lock/plan/admission/bootstrap identity, six before/after SHAs, whole-WIP digest, C34/C35 output/case digests, private support digest and cost/unknown-hold status. The lead `receipt.json` includes that report SHA and exact subject; first native admission verifies both artifacts rather than trusting the lead verdict. A missing, stale, self-produced or mismatched report is DENY. The exact r66 local preview may support 16k planning but does not replace selected-host native IF09–IF12 or H04 proof. All revision65 start/input and private retention joins remain.


## Revision65 DRAFT bootstrap and accounting EV join

`route-bootstrap-contract.json` defines the lead receipt under `evidence/route-bootstrap/`, C34/C35 with RB01–RB12 local cases, private request digest-only projection and exact per-attempt prelaunch-intent, process-start and process-input artifacts. Before runner reserve both actual receipt paths, persist expected digests and prove selected host/config/transport/child-load at the last boundary. After real Popen, `process-start.json` records observed child/argv/config with stdin PENDING; only later `process-input.json` can record complete actual OS-pipe byte/SHA/close identity. Started IF09/IF12 join both plus result/usage and task-bound native evidence; IF10/IF11 no-start refusals have neither actual receipt. Short/failed input or missing post-start receipt fails the started attempt and retains observed/unknown cost. Public evidence remains hash-only; raw request purges 30 days after full closure. C34/C35 local results do not qualify a native positive or H04 hard cap. r64 evidence wording below is historical for r65 once reviewed and locked.


## Revision64 CURRENT accounting EV for prepared FROZEN shape

The exact r63 DRAFT received independent READY_TO_FREEZE at digest `b4fa3223f6ca53a701cdab27c6bef875d49fdda6dcf30cc5447d87437a51c315`, but r63 has no lock. For r64, EV216-ACCOUNTING-ENFORCEMENT requires an independently reviewed exact r64 FROZEN-shaped plan, matching machine report and verified r64 lock, then plan/packet/final-prompt and run/task/attempt/role/route/claim identity. Before runner bind snapshot, diagnostic, transport, prelaunch-intent expected digests and reserved process-start path. For started IF09/IF12, join actual observed process-start/result/usage after start; for IF10/IF11 prelaunch refusals, prove hostLaunchStarted=false with no actual process-start receipt. Post-start evidence failure retains observed/unknown cost. The Revision63 section below is historical for lock identity.

## Revision63 accounting EV sequence — historical for r64 lock identity — r62 S2 M01/M02

The r63 proposal required the exact independently reviewed r63 lock, plan digest and task/run/attempt/role/route/claim identity; r61 remained a rejected DRAFT with no lock and r62 has no accepted lock. Before runner, bind private snapshot, diagnostic hash, config manifest, transport witness, last-boundary checks and `prelaunch-intent.json` expected argv/stdin/config digests plus an exclusively reserved `process-start.json` path. A prelaunch mismatch refuses with hostLaunchStarted=false. After observed child start, write actual `process-start.json` start/argv/stdin observation, finalize result/usage after completion, and join to the same subject for started IF09/IF12 cases. Prelaunch IF10/IF11 cases require the no-start refusal record and no actual process-start receipt. Missing/mismatched post-start evidence fails attempt/EV and retains observed or unknown cost; never call it a no-start refusal. The r61 section below is historical and superseded for lock identity.

## Revision62 typed accounting EV joins — r61 S2 M01/M02

EV216-ACCOUNTING-ENFORCEMENT requires canonical command digest `3b9f0a1a9af2a89f59d14b2b43bbd9800716a04f21fc74e9651f3a78ff96c70c` and oracle `tests/adapter_sessions/test_codex_exact_prompt.py` for IF09–IF12. The lead joins each task/attempt/route-bound `config-snapshot-manifest.json`, `transport-equivalence.json`, `process-start.json` and private diagnostic hash from the exact r62RuntimeArtifacts path templates. The new command's observations must carry existing IF09–IF12 case IDs, plan/packet/final-prompt digest and subject; missing/wrong/stale artifact cannot satisfy a case. Private snapshot is destroyed after use, raw diagnostic deleted 30 days after full close, hash-only identity/cost proof retained. None is native positive evidence until actual task-bound route proof passes.

## Revision61 exact-prompt evidence — historical, superseded for lock identity

At the r61 proposal stage, EV216-ACCOUNTING-ENFORCEMENT IF09–IF12 was proposed to join accepted spec SHA `4e1245c0c8fc4c321f275829bf2953aea75e67c23e657b55a39f1ab360d88ae2`, a proposed r61 lock/packet/source/role/final-prompt receipt, prelaunch source-bound exec - stdin and config-snapshot qualification, direct/unified all-role hostLaunchStarted=false negatives, then task-bound native argv/stdin/result and controlled failure/cost history. This r61 proposal never acquired a lock and is not an operative current EV requirement. A diagnostic alone is NOT_RUN for native.

## Revision58 IF09–IF12 scoped current-Codex evidence

WS216-02/C20 and EV216-ACCOUNTING-ENFORCEMENT now require IF09 exact scoped positive packet/diagnostic/ALK component binding, IF10 prelaunch mismatch negatives through both managedTask callers, IF11 stronger-claim denial and unknown preservation, and IF12 task-bound native host failure/truncation handling with usage retention under a controlled local fixture; actual native failures are retained if observed, not deliberately induced. The existing `tests/accounting/test_host_bridge.py` owner and command remain; source fixtures/results are PLANNED/NOT_RUN. A local synthetic receipt does not qualify native host behavior. No complete-host-fit or H04 U proof is planned from `debug prompt-input` alone.

## Revision56 exact evidence case set

The required EV216-WORKFLOW-STORE `caseIds` list now has 22 exact local IDs including `recovery.state.ds24`–`ds27`; the pre-existing WS216-01 owned test command/digest and oracle paths remain. A command PASS without these case observations cannot satisfy the evidence validator. Positive WR07/native and all other gates retain their status.

## Revision54 correction candidate — independent full S2 review pending

r54 requires exact WR07 migration/root, WR09 B-stage, WR11 event-repair partition and WR12 filesystem side-effect/native-refusal receipts on a future qualified route; all remain NOT_RUN. The current route still needs OR01–OR19 refusal and WR01–WR06 local evidence. A local packet preview supplies no host-owned input or whole-call U proof.


## Revision53 draft evidence delta

EV216-WORKFLOW-AUTHORITY records WR01–WR03/WR06; EV216-CLOSING-RESOURCES records WR04; EV216-DEADLINE-CONTRACT records WR05 as distinct required local case IDs. Exact bytes, current SQL selection and operator/clock/root provenance must not be inferred from fixture validation. WR07–WR12, complete write inventory and F0/F3–F6 native recovery remain `NOT_RUN` for a future qualified protected route. Current Codex OR01–OR19 refusal and all pre-existing Choice B/H04/H05/A5/adapter/platform/security/publication/final-audit evidence remain required.


## Revision52 prepared FROZEN-shape candidate — Choice B current-Codex capability-scoped closing

The user selected Choice B. On the current full-access Codex route ALK must refuse protected adoption, root/epoch-0 publication, closing activation/grant and protected dispatch before write or process start. Positive CC04–CC16, DS14, DA15 and joined DS/DA/DR/DD cases remain NOT_RUN/UNPROVEN under their original IDs; distinct OR01–OR19 native negatives and independently reviewed applicability are required for a limited release. All 53 retained WS01 local cases, CC01–CC03, late settlement, H04/H05, A5 for all12 adapters, platform/security/publication and numeric caps remain mandatory. A qualified future route must pass the original positive native cases before enabling protected closing. This prepared candidate has no accepting review, lock, native proof, task acceptance or release permission; r48 remains current. EV216-CLOSING-WINDOW caseIds are OR01–OR19 plus the unchanged 14 A5 case IDs. EV216-WORKFLOW-STORE replaces required DS14 with new DS23; EV216-WORKFLOW-AUTHORITY adds DA17. Original positive cases remain in their source contracts, NOT_RUN. Existing 33 validation command strings/digests are retained; added tests belong to their owned files and existing commands.


## Revision31 — direct local-profile launch negatives

WS216-02 IF05/IF07 must exercise the reachable `managedTask` `launch_preflight.py` pre-run gate through both `unified_start.py` and direct `launch_from_local_profile`, including callers that bypass continuation. Missing, stale, wrong or over-limit input-fit receipts require `hostLaunchStarted=false` before `context.runner`. IF08 tests `planningTask` limited exclusion and no process start for stronger task/run fit or FULL_FINANCIAL requests. The existing C20 / EV216-ACCOUNTING-ENFORCEMENT route and owner test path remain; all results are `NOT_RUN`.

## Revision30 — input-fit oracle joins

`alk-input-fit-contract.json` declares IF01–IF04 as WS216-01 / EV216-ACCOUNTING-CORE pure selector/limit cases under retained command C18, and IF05–IF08 as WS216-02 / EV216-ACCOUNTING-ENFORCEMENT ALK dispatch/consumer/limited-route cases under retained command C20. Both expected evidence descriptors pin this contract as an oracle source and require their four new case IDs conjunctively with the old cases. Future tests belong to `tests/accounting/test_journal.py` and `tests/accounting/test_host_bridge.py`; all eight cases are `NOT_RUN`. No host-wide fit or financial guarantee is inferred from a local renderer receipt.

## Revision24 — typed A5 evidence bindings

R23-A5-M01 is addressed as a DRAFT correction. The two existing required typed
evidence routes now conjunctively require their retained commands/cases and the
new owner-specific A5 command/cases. EV216-SCHEMA (WS216-01) requires
A502/A506/A510/A511; EV216-CLOSING-WINDOW (WS216-02) requires
A501/A503/A504/A505/A507/A508/A509/A512. All six r22 categories retain their
existing case IDs and now map to these owner cases through the implementation
contract's typedEvidenceJoin.categoryToOwnerCases. Both required EVs must pass
on their independently expected task/subject; an old-only or A5-only receipt is
insufficient. The same typed routes bind the exact implementation contract,
owner tests/fixture, and the WS216-02 boundary registry as configuration input.
Missing/wrong command, case or input identity must reject after implementation.
All A501-A512 remain NOT_RUN; this declaration does not attest runtime behavior.
Prior evidence obligations, source/validity/provenance rules and release gates
remain mandatory. A narrow independent review must close R23-A5-M01; structural
PASS alone does not do so.


## Revision23 — concrete A5 limited implementation candidate

`cf01-a5-implementation-contract.json` now defines the proposed closed records,
frozen policy/state/adoption join, ordinary planning request binding, exact ALK
launch/refusal and consumer hooks, all12 saved expectation targets, exact owners
and 12 future oracle groups. Status: DRAFT_REQUIRES_INDEPENDENT_DELTA_REVIEW.
The accepted r22 capability policy and r19-r21 authority/storage/resource/deadline
semantics remain unchanged. This amendment supersedes only their unresolved A5
integration placeholders; it does not claim full-plan acceptance or runtime proof.

Ordinary standalone context binds the actual explicit operation/input; it is not
a bearer authorization and needs no invented authority file or workflow attempt.
Frozen workflow requirements remain independently authoritative. Accepted attempts
retain original A5 classification/evidence/cost and use a separate adoption binding.
No strong-positive v1 variant exists. Every proposed strong request refuses.

R216-IMMUTABLE-INPUT maps to AC216-A5-SCHEMA / WS216-01 / EV216-SCHEMA and existing
AC216-A5-CAPABILITY / WS216-02 / EV216-CLOSING-WINDOW. All six r22 policy categories
are covered by A501-A512 in the contract. Future commands are declared in the
manifest, NOT_RUN. H05, measured packet/native-budget fit, independent delta and
whole-candidate review/freeze, implementation and actual all12/platform/final
qualification remain open. Existing caps are retained, never presumed sufficient.


## Revision22 — A5 according to existing host capabilities

User-approved scope: strong A5 is enabled only for an existing route with proven
continuous input protection. Other routes refuse that mode and may meet release
acceptance with a reviewed limitation plus actual source-bound refusal proof.
The positive A5 invariant is unchanged; no endpoint-hash fallback, silent downgrade
or immutable-input/write-scope exemption is allowed on a limited route. Ordinary
source/result/ownership/audit and independently required security/validity checks
remain mandatory; any operation requiring unavailable protection remains refused.

`cf01-a5-capability-scope.json` is the normative applicability authority for all12
adapter routes. Older unconditional A5 prerequisite statements below apply to the
STRONG_A5 branch; limited routes instead require a complete refusal integration
contract before freeze and actual route/consumer qualification before release.
H04 support does not establish A5 support. Unknown remains UNPROVEN, not PASS.
The accepted r19/r20/r21 design is retained. This r22 amendment needs scoped
independent review; full candidate readiness, H05, actual fit and all implementation,
storage/platform/final release gates remain open. Historical revision narratives
below are retained as history and do not override this current applicability rule.

## Revision18 — D-DEADLINE configured consumers and current time

cf-d-deadline-contract.json joins the four closing-window design contracts. Actual
runtime gate input is per-task controllerGates and its producer/phase configuration,
not securityGates prose. Only an independently declared compatible execution-only
predicate may consume signed closing permission; run/attempt wall budgets, evidence
freshness, lease/grace/I-O and opaque custom gates retain their original bounds.

The supplied historical receipt identifies project planning/immutable-gate.py and
its execution-deadline failure. Its old FAIL is preserved; historical script source
semantics/current runtime qualification remain unproven. No gate was rerun or
project script/host patched. New contract templates are reviewable before freeze;
actual compiled registry/source/clock identities must be qualified after implementation.

New workflow timestamps use canonical UTC microseconds. D-AUTH and D-DEADLINE share
the same fresh final decision observation; replay/projection never renews time.
Late useful results and all actual costs remain recordable, with reuse classified
separately from permission. Final-audit acceptance or a prepared proof file alone
cannot bypass finalization gates or commit COMPLETE after an invalid decision.

16NOT_RUN cases contribute8WS01 rule/clock-storage and8WS02 consumer/integration witnesses.
Seven exact ownership paths and two planned validation groups retain old owners and
native caps. The joined DRAFT needs independent review, then implementation/native
proof. CF01-A5/H05/actual fit/all12adapter/storage/platform/final gates remain open.

## Revision17 — D-RESOURCE prospective policy and current claim

cf-d-resource-contract.json defines the minimal ACCOUNTING_REPORTED_TOKENS_V1
policy effect in the existing journal, joined with D-STATE and D-AUTH. Signed
additional allowance A yields cumulative ceiling C=S+A at the exact signed anchor.
It never adds unused old allowance. Task/run/window constraints evaluate one charge;
old costs, caps, reserves, protection and violations remain. Source bound failure
or unknown opening cannot be repaired by raising a budget.

Activation records policy/window/nonce together. Reservation and once-claim both
validate current resource and authority state; claim includes the already reserved
U once. Each closeout transfer/refund stays with its original owner/window. A new
signed window may retire an earlier entitlement but cannot roll over unused A,
claim an old unclaimed permit or reset spend. Legacy billableTokens/invocations/
wallSeconds remain distinct unchanged guards; unsupported extension is unavailable.

20NOT_RUN cases contribute16WS01 resource witnesses and4WS02 integration witnesses.
Five exact ownership paths and two validation groups are added within unchanged
native ceilings. These are author design contracts, not implementation or evidence
of native enforcement. Configured D-DEADLINE consumers and their exact guard state
must be bound next, then the combined design needs independent review. CF01-A5,
H05/actual fit, all12adapter qualification and final release gates remain open.

## Revision16 — D-AUTH issuer, revocation and commit contract

cf-d-auth-contract.json defines an independently pinned operator root, a signed
per-run issuer snapshot and a separately signed closing grant. It reuses ALK's
Ed25519 implementation through a planned contracts extraction with compatibility
exports. A name, receipt hash, external pathname or TEST_AUTHORITY is insufficient
owner proof. Native bootstrap qualification remains required as DA15.

The existing SQLite writer transaction orders authority publication, nonce use,
workflow activation and financial claim. A revocation takes effect when its signed
snapshot commits locally. A prior committed claim is in flight and cannot be
promised cancelled by this protocol. Current authority/time and financial state
are rechecked at claim; historical replay cannot issue a new permit. Expiry during
projection or commit does not extend permission or cause checks to restart.

Sixteen NOT_RUN cases contribute12WS01 authority/storage witnesses and4WS02
integration/native witnesses. Eight additional exact ownership paths and two
planned validation groups preserve all previous owners, cases and finite ceilings.
This is a concrete design candidate, not implementation or independent acceptance.
D-RESOURCE must close the exact approval-policy schema/transaction/claim join next;
configured D-DEADLINE, CF01-A5, H05/actual fit and final review remain open.
Only ALK is changed by the planned implementation; all12adapter capability limits,
FULL_FINANCIAL semantics and30-day financially-closed detail retention are retained.

## Revision15 — D-STATE transaction and recovery contract

cf-d-state-contract.json selects one authoritative SQLite transaction for workflow
state/event/result, closing window, nonce use and qualified prospective policy.
JSON state/event files become derived, generation-bound projections. Existing
Journal transaction/version/writer admission is a primitive to extend, not proof
that this workflow feature already exists. A typed WS01 WorkflowStore port owns
storage/adoption/replay/publication; WS02 integrates state/kernel/events and every
permission consumer. No new database, JSONL authority implementation or benchmark
is introduced by this plan. Four exact paths and one planned command are added.

An operation committed before a lost reply returns the same durable semantic
result on replay. Pending/mismatched projection denies new dispatch. A claimed or
uncertain model invocation never restarts during storage recovery. Late expenses
remain recordable without renewing authority. Trusted JOURNAL_REQUIRED binding
prevents fallback to old JSON or a new empty accounting scope. Adoption requires
qualified legacy observation, known quiescent writers and preserved history.

The22 NOT_RUN cases separate18WS01 storage witnesses from4WS02 integration cases.
D-STATE is a concrete DRAFT design, not independently accepted or implemented.
D-AUTH commit-bound verification, D-RESOURCE same-transaction policy port, configured
D-DEADLINE consumers, CF01-A5, H05/actual fit and final candidate review remain open.
FULL_FINANCIAL limitations and30-day financially-closed retention remain unchanged.

## Revision14 — CF01/CF02 exact integration map

cf-integration-map.json is the current source/owner/oracle authority for this
integration. Fourteen rows separate source-read facts, reused accepted core proof,
declarations and proposed interfaces. Thirteen exact paths are added to the serial
WS01/WS02 ownership; no directory wildcard or product edit is authorized by DRAFT.
WS01 provides a pure closing-policy/state/finalization seam before WS02 native
activation. Direct CLI, Python and continuation routes must converge on the same
authoritative action/time/resource guard; ordinary task work cannot bypass it.

S2-R11-P01 is PARTIALLY_ADDRESSED, not closed. Existing neutrality signature code
is a domain-specific primitive, not a workflow owner grant. Kernel event append
and state replacement are separate; neither this nor accounting SQLite proves an
atomic activation/nonce/policy transition. The exact authority route, all-writer
transaction/recovery interface, configured execution-deadline/watchdog producers
and prospective resource policy API remain prefreeze design dependencies.
No literal execution-deadline consumer was found in the bounded repository source
search; dynamic/installed/configured consumers remain unproven, not nonexistent.

Evidence TTL, worker leases, process grace and capture deadlines cannot be extended
by a new execution permission. Expired permission does not discard valid evidence
or prevent late financial settlement; those actions do not grant new paid work.
CF01 A5/G-AUTH/G-OBS/G-TIME/G-CONSUME/G-SCOPE, H05 coverage and measured fit remain
open. No actor, receipt, counter, lock or runtime PASS is manufactured here.

## Revision 13 — pinned expectation inputs and staged runtime identity

All12 expectation templates are now populated in h04-adapter-profile-cases.json:
descriptor/capability hashes, selected versions with provenance, saved official
source snapshots, each documented candidate's ceiling/oracle, role and original
case obligations, and bounded qualification recipes. These are EXPECTED_NOT_OBSERVED
inputs pending independent review; no runtime profile is accepted by this revision.

r12's requirement for actual host executable/configuration hashes before freeze
is replaced by TARGET13 in h04-artifact-contracts.json. Before freeze review the
fixed targets, source hashes and claim/qualification policy. After implementation
bind exact existing runtime identity for every native-positive claim. A reviewed
source-bound limitation may use explicitly null runtime hashes and must reject
all native-positive/financial claims through actual ALK refusal. This grants no
host compatibility or permission to modify/install a host. Every documented
candidate still requires an individual justified disposition; no convenience fallback.

Native experiments require concrete admitted argv/configuration and source-bound
oracles before execution. The12x100000 ordinary planning allocations consume1.2M
of existing WS02 ordinary2M; remaining800000 covers integration/validation. WS02
protected250000 is shared once, not copied per profile. Request/time/tool/evidence
and validation-run fit remain unproven; this allocation changes no native cap.
Retained CF02/CF01 integration design, H05 coverage, actual fit and final independent
review still block freeze. No code/tests/native transition or release approval.

## Revision 12 — reviewed findings and current authority

r11 full-plan independent review returned CHANGES_REQUIRED (3 High,4 Medium).
r12 addresses S2-R11-H01/H02/M01/M02 in DRAFT; these are author corrections,
not independently closed findings. h04-artifact-contracts.json defines closed
artifact/request/result types, immutable expectation joins, exact comparison and
refusal rules, bounded producers and qualification milestones. The profile-case
file maps all21 profile oracles and all13 original core/native assertions.
WS01 produces pure resolver proof in its own EV; WS02 produces exact-final-profile
refusal after integration. Expected bindings are pinned templates, not runtime PASS; TARGET13 controls runtime qualification.
Before freeze populate and independently review all12 exact target/source/claim
and recipe expectations. Runtime qualification follows implementation and precedes
release. Existing CF02/CF01 transitive design, H05 independent coverage and actual
packet/budget fit remain open; no lock, execution or release approval exists.
Full H04 on current Codex remains optional; all12 scoped profile acceptance remains
mandatory. Earlier revision text is historical where it conflicts with this block.

## Revision 11 — current H04 authority

DRAFT. The user removed mandatory full H04 in current Codex. [h04-adapter-boundaries.md](h04-adapter-boundaries.md), h04-adapter-profile-cases.json and manifest revision11 control adapter-specific acceptance for all12. Every accepted profile requires both applicable capability/limitation evidence and exact-profile ALK resolver refusal proof. FULL_FINANCIAL remains strict but optional per supported profile. Earlier conflicting H04 statements below are historical; other release gates and original evidence remain unchanged. Independent specification review permits migration only; full-plan review, implementation and runtime qualification remain pending.


All release evidence is canonical, contained and bound to actual source/workload
identities under work/release-2-16/evidence/. Unknown time/token usage is UNAVAILABLE.
The prepared revision38 candidate declares the fixtures; workers implement them
only after an actual accepting review, reviewed lock and native authorization.
No successful fixture results are invented in planning.

## Exact pre-execution sequence

The controlling sequence is README's revision-9 execution authority and native
review binding section. Prepare exact candidate N/report-path bindings BEFORE its
accepting review; report bytes arrive only as reviewer output, then native
lock-create binds the complete inventory. P (pinned accepted 2.15 source) verifies,
compiles, initializes/adopts with approval-required and authorizes WS216-01 work.
C1 (actual WS216-01 source inventory) must replace P before that task's first
implementation audit and task-accept. Preserve the same state/plan/base lineage.
C2/C3 and final acceptance use their corresponding verified source candidates.
Activation records and negative acceptance-route observations live outside the
locked package under work/release-2-16/evidence/. Record executable/import paths,
source inventory, manifest/lock/task/result bindings and actual command outputs.
EV216-BINDING/RECEIPT require the isolated acceptance-route negative/positive
controls defined in README, including receipt mutation after report creation.
No such test, native transition or accepting review was performed in r9 planning.
DRAFT structural validation is not this sequence's proof.

| Evidence | Owner | Required proof |
| --- | --- | --- |
| `EV216-SCHEMA` | `WS216-01` | Mutate every required published audit field, type, enum and lineage independently through schema and real task/final accepting routes; both reject the same invalid inputs. Valid predecessor reports remain readable under their documented guarantee; no accepting path uses weaker validation. |
| `EV216-BINDING` | `WS216-01` | A receipt for one of five required IDs does not satisfy the others. Missing/duplicate ID, wrong task/attempt/plan/source, changed configuration/oracle/build, and stale digest fail. A complete exact mapping passes. Different commit history with identical tested content requires explicit validated applicability; a changed merge tree never inherits the old PASS. |
| `EV216-RECEIPT` | `WS216-01` | Built-in versioned payload fixtures round-trip through the actual audit consumer. Expected contracts come from the frozen plan, not the supplied receipt. Unsupported kinds, missing required fields, spoofed producer claims, self-selected subjects and advisory extensions cannot satisfy required evidence. For a declared asynchronous negative observation, missing readiness or incomplete declared event/time coverage fails; valid bound observations pass without claiming that structural validation proves oracle semantics. |
| `EV216-PROVENANCE` | `WS216-02` | Self-asserted independent=true and renamed actor strings remain DECLARED; an ATTESTED gate rejects them. Same actor or same session, replayed/wrong-subject/stale provenance and untrusted issuer proof fail. Valid evidence passes the pure verifier under an explicit independently pinned TEST_AUTHORITY. Native ATTESTED remains UNSUPPORTED until a qualified route is reviewed; a fake issuer exercises rejection, never live attestation. Native ATTESTED claims or requirements reject missing or unqualified context, report-selected root/pin, stripped claims, wrong phase and same actor or session against any final author; imported PASS or quorum summaries cannot bypass revalidation. |
| `EV216-IMPORT` | `WS216-02` | Wrong raw container/items, invalid status/budget types, conflicting bindings and malformed command outcomes fail before normalized output is created. Valid supported nested bindings preserve values and all findings. FAIL/nonzero exitCode is retained; WAIVED cannot manufacture PASS. Missing usage is explicitly unknown, observed zero remains zero, and imports retain their non-quorum default. |
| `EV216-PUBLICATION` | `WS216-03` | Migration notes identify newly rejected inputs and show safe preparation without rewriting existing evidence. Version consumers and a new accounting fixture point to 2.16.0. Required local gates and Windows/Linux/macOS candidate checks pass with exact source identities and no threshold relaxation; missing telemetry remains UNAVAILABLE. |

## Candidate platforms and CI applicability

Retain the existing Python 3.11–3.14 Linux/macOS/Windows CI coverage. Local work
can run on macOS. Required Windows cases execute on a Windows host or GitHub
Windows runner; a local UTM VM is optional for uncommitted-source debugging.
CI uses the exact candidate source/tree and declared commands. Record checked-out
commit/tree, OS/architecture/interpreter, command identities, exit/result, skips
and artifact hashes. PR CI may check a merge candidate; reconcile that identity
with the candidate actually accepted. A green job for a different tree is not proof.

Current .github/workflows/ci.yml runs the full unit/security and several contract
checks; matrix.yml is manually dispatchable. Reuse these routes. Their green
checks alone do not claim every release-specific quality/publication gate or
signed matrix receipt was produced. Collect actual outcomes under this release's
evidence and prove all required cases ran, including native predecessor regressions.
Do not require a separate third-party project or a permanently running local VM.

Focused validation extends current suites and declared new test modules. Full
discovery is -s tests -t .; full security, architecture, quality, neutrality,
stdlib, hygiene/history, workflow, docs, routing and publication gates remain.
Evidence-count completeness and source validity are checked before final audit.

## Exact revision-8 receipt production

Each EV has its own artifactPath and required typed descriptor in the manifest.
One envelope satisfies exactly one EV. The same command execution may be referenced
by several receipts only when each receipt carries its own required case evidence;
a reused unrelated file cannot fill the required set. Consumers recompute digests
and expected subject from the verified candidate, then check exact command/case
sets and actual exit/skip outcomes. Case evidence files are not semantically trusted
just because they have hashes. The independent reviewer examines their producers.

The following stable case IDs are fixture obligations, not completed evidence:

- EV216-SCHEMA: schema.required-fields, schema.valid-contract, schema.task-consumer, schema.final-consumer.
- EV216-BINDING: binding.missing-ids, binding.duplicate-id, binding.wrong-lineage, binding.changed-content, binding.config-oracle, binding.history-applicability.
- EV216-RECEIPT: receipt.bounds-and-types, receipt.unsupported-kind, receipt.payload-digest, receipt.readiness, receipt.coverage, receipt.seeded-delayed-violation.
- EV216-PROVENANCE: provenance.same-actor, provenance.same-session, provenance.forged, provenance.replayed, provenance.valid-trusted-route.
- EV216-IMPORT: import.lossless-findings, import.failed-command, import.invalid-container, import.binding-conflict, import.unknown-usage, import.observed-zero, import.non-quorum.
- EV216-PUBLICATION: publication.compatibility, publication.versions, publication.required-gates, publication.candidate-platforms.

Publication receipts must additionally reference the actual platform job outputs
and required-case coverage described above; the typed command envelope alone does
not create Windows/Linux/macOS proof. The DECLARED producer requirement for these
release test receipts does not weaken the separate native independent-review and
trusted-provenance gates. The valid-trusted-route case is a positive test of the
pure verifier under an independently pinned TEST_AUTHORITY; it qualifies no native
issuer/caller route. Native ATTESTED remains UNSUPPORTED and its required rejection
cases must pass. Production native availability is explicitly deferred, not a
release-positive proof inferred from this fixture.

Changed contract fixtures must exercise exact bounds, duplicate JSON keys, explicit
null versus missing fields, unknown versions, path escapes, byte/digest mismatch,
all supported payload kinds and v1-read-only/v2-normalized compatibility. These are
future implementation tests, not commands run by this planning correction.

## Revision-8 provenance producer contract

The README fixes agent-reviewer-trust-root.v1, agent-reviewer-attestation.v1,
agent-reviewer-identity-claims.v1 and agent-reviewer-provenance-validation.v1.
EV216-PROVENANCE additionally requires the exact manifest cases for untrusted
root, actor/phase allowlists, signature domain, expiry, challenge and idempotent
retry. Implement them in the owned review/provenance suite/public test fixture.

The valid-trusted-route fixture uses a separately pinned test issuer and exercises
the actual proposed verifier; it is not live external reviewer attestation. A
production ATTESTED promotion additionally needs the qualified real caller/issuer
route. Do not bypass that distinction or change DECLARED requirements to claim
stronger evidence. Exact caller integration and issuer evidence are review gates.

## Revision-8 native integration oracle

README defines the exact phase/caller map and proposed capability deferral. EV216-PROVENANCE must cover every added native caseId in the manifest, including missing context at freeze/task/final acceptance, expected ATTESTED with its claim stripped, wrong phase and all final authors. Tests must assert that failed provenance cannot advance acceptance. The valid-trusted-route case is TEST_AUTHORITY only. Independent S2 acceptance of the capability limitation remains required; no AC is marked passed.

## Revision-8 command-to-evidence binding

Resolve exact commands from the frozen manifest using README's workstream selection
rule and each required EV descriptor, before running them. WS216-01's three EVs
require only command 1; WS216-02's two EVs require command 2; WS216-03's publication
EV retains the 15 original final commands at inventory positions 3–17. No earlier
workstream must execute later-owned new tests or version/publication gates to
produce its own receipts. All case IDs, final regression gates and platform proof
remain required. contextRefs make the manifest and this rule available; the current
compiler does not automatically emit command selections. This prepared candidate
has not proven runtime activation or measured native budget fit.


## Revision-10 controlling accounting/recovery amendment

Revision10 is DRAFT. release-prerequisites.md and the manifest define the added minimal accounting/recovery scope, serial ownership, prospective token ceilings and unresolved prerequisites. accounting-and-recovery-cases.json retains original H04 AC01–AC13 and CF CC01–CC16. All earlier unchanged-scope/cap statements apply to their historical revisions; original acceptance, command, quality/security and publication gates remain. This amendment is not an accepting review, implementation proof, freeze or native authorization.


EV216-CLOSING-POLICY is produced by the WS01 closing_policy/workflow_state_schemas unit command and saved at work/release-2-16/evidence/ev216-closing-policy.json. Exact five case IDs/oracles are cf-integration-map.json#/purePolicyWitnesses. WS02 EV216-CLOSING-WINDOW additionally requires the planned CLI/integration/recovery command. Neither command has run in this planning section. The future native activation command remains a contract to design and review; no working endpoint is asserted.

EV216-WORKFLOW-STORE uses the declared tests.accounting.test_workflow_store/test_workflow_store_recovery command and 22 exact DS case IDs, including required DS24–DS27. The existing WS02 closing-window integration/recovery command produces its4DS integration cases. Storage fault-hook results are not full host/process/power-loss proof; bind the actual fault, process, filesystem and platform scope.

EV216-WORKFLOW-AUTHORITY maps12WS01 DA cases to the authority/store/crypto command. EV216-CLOSING-WINDOW retains CC04-CC16 and4DS cases and adds DA08/DA12/DA14/DA15 via tests.workflow.test_closing_authority. DA15 must contain actual native bootstrap evidence after implementation; a mocked CLI or fixture root cannot satisfy its oracle.

EV216-CLOSING-RESOURCES maps16WS01 DR cases to tests.accounting.test_closing_resources/test_closing_resources_recovery. Existing EV216-CLOSING-WINDOW additionally requires DR13/DR15/DR19/DR20 through tests.workflow.test_closing_resource_integration, retaining every CC/DS/DA case. Runtime guard/bootstrap evidence is not supplied by a pure arithmetic fixture.

EV216-DEADLINE-CONTRACT covers8WS01 pure DD cases. EV216-CLOSING-WINDOW adds DD06/DD07/DD08/DD09/DD10/DD12/DD13/DD15; exact case inventory in cf-d-deadline-contract.json controls (8WS02 total). Pure fixture clock/schema proof does not qualify actual gate producer or background host control.

## A5 r22 evidence traceability

R216-IMMUTABLE-INPUT -> AC216-A5-CAPABILITY -> WS216-02 -> EV216-CLOSING-WINDOW.
The six exact a5.capability.* case oracles are in cf01-a5-capability-scope.json and
the manifest EV. All are NOT_RUN. Existing command groups and budgets are retained;
exact case-to-test ownership, runtime route bindings and measured admission fit
remain prefreeze design work. A positive design review is not refusal/runtime proof.

## r69l R11 PRE bootstrap successor (DRAFT)

For the current prospective PRE bootstrap, `r69l-r11-bootstrap-delta.md`, the r69l route/manifest, v9/v4 oracles and v5 schemas supersede earlier r69j/r69k one-turn, six-path, 70-path and v4-only PRE wording. Earlier text remains historical for its pinned revision and for unchanged task/release gates. The installed r69k lock remains authority until a separate full DRAFT/FROZEN S2, exact report, canonical lock and controlled transfer. The r362 FAIL remains open; no product/native/release PASS is inferred.
