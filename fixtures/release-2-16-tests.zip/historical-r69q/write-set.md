> **Current r69q exact FROZEN role-delivery candidate.** Current delivery authority is r69q-role-delivery-delta.md and r69q-role-contract.json. Superseded v4/v5 delivery/count/budget/roster/status passages below are historical ONLY for that enumerated delta; all unchanged product/ownership/security/native/release requirements remain mandatory. Exact DRAFT/FROZEN review and canonical lock required before transfer; installed r69p remains authority. C34 candidate96/C35=16; no implementation or host proof. WS216-01 DENY; Release NOT_READY. r413 exact r69q DRAFT accepted fullReview=true READY_TO_FREEZE, report SHA 4770d7fc3ecd16b5d2da2609ca3635ec2cdfce71eae066541643d24c00b9797d. Exact FROZEN shape requires its matching independent report, canonical lock and verified transfer; implementation/host/native/release proof not granted by plan status.

> **r69k R10 FROZEN shape pending exact review.** r352 independently accepted the corrected 50-file DRAFT subject (body SHA `93cecf316b40a6564bf877bb5f3d253544f6c0576116c78a05b49088013e8079`) with fullReview=true and no findings. This candidate changes only status, review metadata and top historical notices; the FROZEN-shape report and canonical lock are absent. The verified installed r69j parent lock `c96f464a845c7e69a4fd08af705d55cffb3a4db328cf1eb5a1eef17b9d4d894b` remains authority. Older notices and DRAFT text below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69k R10 isolated DRAFT; independent plan S2 pending.** r348 independently accepted corrected R10 specification SHA `14e5fbba22aa6258ba051abccffec3a0b07b97a9e7174d20491889dbaa43bfda` for plan drafting only. This candidate raises the one-turn request cap to 245760 bytes and binds r69k successor to verified r69j parent. The installed r69j lock `c96f464a845c7e69a4fd08af705d55cffb3a4db328cf1eb5a1eef17b9d4d894b` remains authority; r69k has no independent plan review or lock. Older notices below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69j R9 FROZEN shape pending exact review.** r333 independently accepted the exact corrected DRAFT subject (raw reviewer body SHA `858e61c9211e114ed3392f1dd8425654857265e573b6a09312e4a6a98dededa2`) and closed R331-S2-M01. This candidate changes only status, review metadata and top historical notices; the FROZEN-shape report and canonical lock are absent. Older notices below are historical. Installed r69i parent lock `721d7e3fa60723d59708efddfe2166347af5abc0981d47153527b00382f0bd67` remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69j R9 isolated DRAFT; independent plan S2 pending.** r329 accepted exact R9 specification SHA `965d2c4c02d4dc80b9538288355294391feb94a0f3bd1e6899c0a3b070bf5d03` for plan drafting only. Candidate v3 support oracle `671ed21d004beedecb80e1785a478e1eb95375a3593df3cd0a731a0151a3b84e` and v8 source oracle `d19e5edb56f4908c949f4239763038915f27798f54e8cdbbc13db6a361f93834` are not installed. Parent r69i verified lock `721d7e3fa60723d59708efddfe2166347af5abc0981d47153527b00382f0bd67` remains installed in execution57. No r69j plan-review report or lock exists; WS216-01 native DENY and Release NOT_READY. Older notices below are historical.

> **r69i R8-R3 FROZEN shape pending exact review.** r301 independently accepted the exact DRAFT subject (raw reviewer body SHA `f96bbe126d9f2dd7bbcf996608a4cbf978d9ff8c39227deab75453878f4ab9fd`). This candidate changes only status, review metadata and top historical notices; its future independent report path is declared but the FROZEN-shape report and canonical lock are absent. Older DRAFT notices below are historical. Installed r69h lock `a1d7a69a05f5887b72165613ebb116bf59f2bf52b59d6f851c66b977c284976c` remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69i R8-R3 isolated DRAFT; independent plan S2 pending.** r299 independently accepted exact R8-R3 specification SHA `bef13eb0608b604ffb88a659abe8b0d940046b52ff5ca2f732eecd48ed924cb7` and source oracle SHA `5f7b3cee3f074ebfbf4129bd4058d38116ef8385be20e6fbcd965158bc07a4fe` for plan drafting only. This candidate overlays the `codex_exact_prompt.py` FULL-source row with typed AST slices and local dependency closure; all other R7/v6 requirements remain. Parent r69h verified lock `a1d7a69a05f5887b72165613ebb116bf59f2bf52b59d6f851c66b977c284976c` stays installed in execution57. This r69i candidate has no plan-review report or lock; WS216-01 native DENY and Release NOT_READY. Older r69h/r69g notices below are historical.

> **r69h R7 FROZEN shape pending exact review.** r288 independently accepted the prior DRAFT subject (raw reviewer body SHA `1a5a331060a81d40e9be6a366856ad4742004567520d91526883485ccd4e6399`). This candidate changes only status, review metadata and overview notices; its future independent report path is declared but the FROZEN-shape report and canonical lock are absent. The older DRAFT notice below is historical. Installed r69g remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69h isolated R7 DRAFT — current delivery authority.** r286 independently accepted R7 specification SHA `b54ebc77c4cc89aed0d809a4d193a15a61e7132a651f6db18f6dc98051732ab1` and oracle v6 SHA `aa25670dc55f6c1fb28ba249b9f24dc6115e470e13e0a6d75166ed2023edb702` for plan drafting only. The copied specification preserves its historical pre-adoption status; this candidate now pins R7/v6. Installed r69g lock `673715e292661c13b6d9c7222434d60b2c0247a54a61d45cf5bd3861c3043a99` remains authoritative. r282's R5/v4 DRAFT review was CHANGES_REQUIRED; this amended DRAFT has no independent plan acceptance or lock. Older delivery notices below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69g FROZEN shape pending exact review.** r254 independently accepted the prior DRAFT subject (raw reviewer body SHA 023d7fd1873d6094ef474f6ddc68e908fc28cc5dbf62e3d0f2891707fbeb58a4). This FROZEN-shaped candidate changes status/review metadata and overview notices only; its report path is declared but the independent FROZEN-shape report and canonical lock are absent. Older DRAFT notices below are historical. Installed r69f remains authoritative; WS216-01 native is DENY.

> **r69g DRAFT delivery successor.** Installed r69f lock SHA 45a280b5dfc5e83e88d6c1f4d635b9ace7e5d1adaf3f9795a1215288bfe54dd5 remains authoritative. Exact independently READY_TO_DRAFT S2 specification SHA 6e7981627ffa616a7fabba856dca343e6f43c5eeda773d0eb87a572bdc7a0e1a is copied as `review-delivery-spec.md`. The current candidate replaces the reviewer-body producer with a same-thread `turn/start.outputSchema` item after `review/start` text; it requires the clean sentinel, full-subject saved request, dual-item collector/fresh read and unchanged PRE limits. Older r69 review-delivery paragraphs below describe historical candidates and do not override `route-bootstrap-contract.json#auditJoin.delivery`. No native WS216-01 from this DRAFT.

# Exact write ownership — revision 40 prepared architecture classification correction

## Revision69 current DRAFT — current-Codex limited outbound proof

This isolated plan candidate has parent r68e verified lock SHA `a619308da56efc1fe0c23a65de9b8c04074e79e93d7247f02958b5a831af6c66` and accepted S2 specification SHA `c69a24fa6170ba4a509048c2d4cf218f970f793431bc2cce6e08ce8687dec018`. It is not reviewed or locked. All historical revision paragraphs below describe their then-current states; the r69 rules in `route-bootstrap-contract.json#limitedFitApplicability` and `alk-input-fit-contract.json#r69FitDisposition` govern this candidate. r68e remains installed authority; native WS01 DENY, Release NOT_READY.

The proposed current-Codex positive claim covers only ALK-constructed bytes accepted by the OS stdin pipe associated with the selected child, not model-visible input or child consumption. Per-role fresh diagnostic and catalog are prelaunch candidates, not future native equivalence. Strong host-fit/financial requests refuse before dispatch. After observed Popen, only complete same-attempt pipe write/close plus joined native success/usage can pass the new limited case; failure retains unknown cost. Original strong IF09/IF12 remain NOT_RUN for this limited profile. All other accounting, H05/A5, 12-adapter, privacy, 30-day cleanup, hourly scheduler, security/platform/publication and final-audit gates remain.


## Revision68b exact correction of r179 findings

The reviewer-authored `reviewer-body.json` is the exact completed App Server review text, closed schema and raw UTF-8 SHA. It cannot contain its own SHA or a later server read. After completed item/turn and `thread/read`, the ALK collector writes `independent-audit.json` with server IDs, exact raw-body SHA and canonical stable item-projection SHA; first-native admission reopens the item and verifies both, then the lead's later SHA join. Actor strings alone never qualify. Both artifacts and the selected-host positive IF09/IF12 remain `NOT_RUN` until separately admitted live qualification.

The active first-native authority is the exact reviewed r68 successor lock; r67b appears only as the locked parent. Prestart C34/C35 prove RB11-PRE only. Started raw request, diagnostic and credential-free effective config source are sealed in an immutable private inventory with a hash-only pending marker before possible start and handed to WS01's durable per-run obligation. Only credential-only ephemeral CODEX_HOME material may be removed at child exit; the retained config source and other started raw wait until authoritative full closure plus 30 days. Missing source equality or safe credential split refuses before start.

`route-bootstrap-contract.json#validation.phaseEvidenceMap` is the one-to-one binding for five WS01 journal, three WS02 CLI and three WS03 target case IDs to owner AC, EV, exact command digest and receipt path. Each phase has a separately admitted finite budget; these are subsets of existing task allocations, not extra prestart C34/C35 slots. WS03 owns `tests/operations/test_retention_maintenance_target.py` and the operation document; its static command executes against the selected release target's actual installed scheduler and ALK command, recording scheduler identity/cadence, journal/root/authority SHA and real no-due/due/overdue outcomes. Local mock or unqualified platform deletion cannot close combined RB11 or retention release readiness.

## Revision68 current draft: source-bound RB11 and maintenance handoff

This is the exact r68 draft successor to the reviewed r176 specification SHA `b4a00c69751e67bfc81c277d38e0f2904c7f862ef461bdc596feb4019a1dc413` and current r67b lock SHA `56766d2d39988723484ce412523bbb34ab6ac6ae31f9e5deae1c96a779b6e561`. r67b remains operative until a separately accepted full S2 review, matching report and canonical r68 lock. No present product test or native/model result transfers to newly added cases.

Pre-WS01 lead owns only the six unchanged bootstrap paths; C34/C35 and independent audit cover RB01–RB12-PRE, with RB11-PRE limited to pure fully-closed eligibility/refusal. RB11-RUNTIME is `NOT_RUN` at that audit. WS01 owns journal/finalization/private authority and durable raw cleanup after SQL collection; WS02 owns the existing lifecycle CLI and new maintenance test; WS03 owns the operational document and installed hourly target schedule. Combined RB11 `PASS` is final-release-only after all three runtime owners and a supported-platform target probe. The old two-command prestart limit does not consume poststart commands.

The maintenance command uses a pinned private authority SHA and accepts no independent journal/root override. Started raw details delete only after authoritative full financial closure plus 30 days; unresolved runs have no purge clock. An immutable raw inventory and per-run pending obligation survive SQL collection and partial/crash unlink, with hash-only totals/dedup/closure state retained. The journal write-admission boundary covers fresh closure, due and financial-exception checks through bounded unlink and obligation result. Windows/macOS/Linux targets prove equivalent private path, identity and race-safe deletion behavior or refuse before unlink, retain PENDING/OVERDUE and block retention readiness. Same-user Codex does not gain a protected-close claim.

The independent bootstrap review uses a separately admitted local Codex App Server candidate, distinct review thread, completed item/turn, raw-text SHA and live `thread/read` verification. Documentation and installed schema are only interface candidates; runtime qualification is `NOT_RUN`. Selected-host positive IF09/IF12, all12 adapters, H04/H05/A5, numeric, security/platform/publication and final independent audit remain required. The current Codex claim is only `ALK_CONTROLLED_INPUT_FIT`; full host input/U/FULL_FINANCIAL and protected close remain unavailable. Missing native or review proof denies launch, and missing retention target proof blocks release.

## Revision67 active temporary lead ownership

The r67 route contract retains the exact six temporary ALK product/test write paths for separately audited pre-WS216-01 bootstrap, expiring before first native task. WS216-02 retains later ownership; no concurrent grant or new path is added.

## Revision66 independent audit output ownership

The temporary six-path lead product exception and later WS216-02 ownership in revision65 remain unchanged. A distinct independent reviewer alone produces `work/release-2-16/evidence/route-bootstrap/independent-audit.json` under the lead-owned evidence root; the bootstrap lead may read and SHA-bind it but may not produce or alter it. First-task admission checks reviewer/lead identity separation and exact subject against independently produced provenance. The lead writes `receipt.json` only after that result; a self-asserted PASS grants no authority. Both reports are evidence artifacts, not additional product write paths.


## Revision65 DRAFT temporal route-bootstrap ownership

`route-bootstrap-contract.json` grants the lead only a time-limited pre-WS216-01 exception for six exact paths: `codex_exact_prompt.py`, `launch_preflight.py`, `unified_start.py`, `process.py`, `test_codex_exact_prompt.py` and `test_process_cleanup.py` under their declared directories. The manifest lists all six in future WS216-02 `writes`; there is no concurrent grant: the lead exception ends before WS216-01 native start, WS216-02 takes ordinary ownership only after accepted WS216-01, and the lead passes exact changed-byte digests. `launcher.py`, `input_fit.py`, `process_capture.py`, `process_control.py`, host adapter/profile and installed Codex remain read-only. Unexpected write need stops for a new reviewed exact owner. The lead owns private staging/sealed request and prelaunch/start/input evidence under `work/release-2-16` before handoff; producer/consumer/modes/retention are in the contract and `r65RuntimeArtifacts`. This is DRAFT, not product-edit authority until exact plan review and verified lock.


## Revision64 active two-phase runtime ownership

The current `r64RuntimeArtifacts` retains the exact lead-owned `prelaunch-intent.json` and `process-start.json` path templates, WS216-02 producer/lead consumer, 0600 receipt files, private config modes, cleanup and 30-day fully-closed-run raw-detail retention. The r63 section below is historical for current plan/lock identity; no product write ownership changes.

## Revision63 two-phase receipt ownership — r62 S2 M01

WS216-02 under lead-owned evidence authority produces `work/release-2-16/evidence/codex-exact-prompt/{runId}/{taskId}/{attemptId}/prelaunch-intent.json` (0600) before runner, with expected argv/stdin/config digests and exclusively reserved process-start path. The same route writes actual `process-start.json` only after observed child start; result/usage lineage is finalized after completion. Prelaunch refusal and post-start evidence failure have distinct hostLaunchStarted/cost dispositions. Exact producers/consumers and cleanup remain in r63RuntimeArtifacts; r62RuntimeArtifacts is historical.

## Revision62 exact runtime artifact ownership — r61 S2 M02

The r61 product write paths stay WS216-02-owned. Its ALK route is the producer of the per-attempt private `runtime-private/codex-exact-prompt/{runId}/{taskId}/{attemptId}/codex-home/` snapshot, private `private-details/codex-exact-prompt/{runId}/{taskId}/{attemptId}/prompt-input.json`, and support receipts in `evidence/codex-exact-prompt/{runId}/{taskId}/{attemptId}/{config-snapshot-manifest,transport-equivalence,process-start}.json`, all under lead-owned `work/release-2-16` runtime authority. The lead owns persistence/join into EV216-ACCOUNTING-ENFORCEMENT; the selected child reads only the private config snapshot. Every template identifier is one normalized component; symlinks/reuse refuse. Snapshot dirs 0700, files atomically 0600 then config 0400; evidence/private raw files 0600. Only credential-only ephemeral CODEX_HOME material is removed after proven no-start or child exit, with crash-orphan cleanup after liveness proof. The exact credential-free effective config snapshot is separately retained as a started raw source with request and diagnostic, sealed in the immutable raw inventory before possible start and handed by SHA to WS01 per-run pending obligation. Started raw is eligible only after authoritative full financial closure plus 30 days; open/reconciliation-pending runs have no purge clock. The hash-only pending marker and digest/identity/cost totals survive raw deletion. Public receipts contain only digests/lengths, never prompt or credentials. See r62RuntimeArtifacts for exact producers, consumers and paths.

## Revision61 ALK-owned route ownership

WS216-02 additionally owns `src/agent_lifecycle/adapter_sessions/codex_exact_prompt.py` and `tests/adapter_sessions/test_codex_exact_prompt.py` for canonical component mapping/caps, private config, stdin transport, route/claim and shared direct/unified pre-run negatives; its existing `launch_preflight.py`, `unified_start.py`, host bridge and CLI paths carry integration. Lead owns task-bound evidence joining. No adapter source or shipped profile write is authorized.

## Revision54 correction candidate — independent full S2 review pending

Revision54 keeps WS01 ownership of Journal migration, RunOutputAnchor, B/P stage, authority/resource/deadline/finalization; WS02 exclusively owns protected path/route primitives, including exact directory creation, mode checks, deterministic temp cleanup, state/event projection and current-route refusal. `closing-write-inventory.json` CW01–CW11 and routeCallSites map the effects. Generic chmod of an existing ancestor is forbidden in the protected route.


## Revision53 draft ownership delta

WS216-01 owns the Journal/authority/resource/deadline and finalization sides of `cf-d-window-request-contract.json`, including distinct F0 B producer and F3–F6 E outbox decisions. WS216-02 owns route/state/event/path primitives; its exclusive added paths are `src/agent_lifecycle/contracts/authority_io.py`, `src/agent_lifecycle/workflow/artifacts.py` and `tests/contracts/test_authority_io.py`. The exact shared semantic write map is `closing-write-inventory.json`; no path becomes jointly writable. New normative sources are plan inputs, not product write ownership. r53 remains unreviewed.


## Revision52 prepared FROZEN-shape candidate — Choice B current-Codex capability-scoped closing

The user selected Choice B. On the current full-access Codex route ALK must refuse protected adoption, root/epoch-0 publication, closing activation/grant and protected dispatch before write or process start. Positive CC04–CC16, DS14, DA15 and joined DS/DA/DR/DD cases remain NOT_RUN/UNPROVEN under their original IDs; distinct OR01–OR19 native negatives and independently reviewed applicability are required for a limited release. All 53 retained WS01 local cases, CC01–CC03, late settlement, H04/H05, A5 for all12 adapters, platform/security/publication and numeric caps remain mandatory. A qualified future route must pass the original positive native cases before enabling protected closing. This prepared candidate has no accepting review, lock, native proof, task acceptance or release permission; r48 remains current. No new implementation/test path is assigned. WS01 owns DS23/DA17 local witnesses in existing accounting/authority paths; WS02 owns OR01–OR19 direct CLI/Python/continuation/managed route negatives in its existing paths. New path requires exact ownership amendment before use.


## Revision40 — account for the new accounting package in the existing architecture gate

WS216-01 additionally owns `policy/architecture-dependencies.json`, solely to
classify the new `agent_lifecycle.accounting` package at level 2. Its
`input_fit.py` imports `agent_lifecycle.context.rendering` at level 2, while
workflow and adapter consumers remain higher-level. The existing release
module-dependency command remains mandatory; no layer, cycle or exemption
limit is weakened. The r38 implementation candidate demonstrated that adding
only `accounting: 2`, after removing the normalization/opening import cycle,
makes the exact command pass. The r38 frozen run cannot accept implementation
against this prepared candidate: an actual accepting r40 review, reviewed lock
and fresh native authority are needed.

All other r38 requirements, owners, commands, limits and evidence gates remain
unchanged. The r38 independent review stays as historical evidence; this
ownership amendment requires a scoped independent review before freeze. The r39
two-file draft was rejected for stale r38 revision/fit bindings; r40 rebinds
those inputs and has its own pre-review packet/fit preview.

## Revision31 — existing WS216-02 pre-run owners

The `managedTask` and `planningTask` local-profile entry and pre-run checks belong to WS216-02's existing exact write paths `src/agent_lifecycle/adapter_sessions/unified_start.py` and `src/agent_lifecycle/adapter_sessions/launch_preflight.py`. The existing `tests/accounting/test_host_bridge.py` path owns IF05/IF07/IF08 direct-launch negatives. No new shared write path, command or adapter implementation is added.

## Revision30 — input-fit ownership

WS216-01 additionally owns `src/agent_lifecycle/accounting/input_fit.py` for the pure 15-ref selector and limit contract, with IF01–IF04 in its already owned `tests/accounting/test_journal.py`. WS216-02 owns the existing `src/agent_lifecycle/workflow/continuation.py` and `src/agent_lifecycle/adapter_sessions/launch_execution.py` dispatch/consumer joins, with IF05–IF08 in its already owned `tests/accounting/test_host_bridge.py`. No host adapter implementation or shared write path is introduced. The manifest is the exact ownership authority.

## Revision23 — concrete A5 limited implementation candidate

`cf01-a5-implementation-contract.json` now defines the proposed closed records,
frozen policy/state/adoption join, ordinary planning request binding, exact ALK
launch/refusal and consumer hooks, all12 saved expectation targets, exact owners
and 12 future oracle groups. Status: DRAFT_REQUIRES_INDEPENDENT_DELTA_REVIEW.
The accepted r22 capability policy and r19-r21 authority/storage/resource/deadline
semantics remain unchanged. This amendment supersedes only their unresolved A5
integration placeholders; it does not claim full-plan acceptance or runtime proof.

Ordinary standalone context binds the actual explicit operation/input; it is not
a bearer authorization and needs no invented authority file or workflow attempt.
Frozen workflow requirements remain independently authoritative. Accepted attempts
retain original A5 classification/evidence/cost and use a separate adoption binding.
No strong-positive v1 variant exists. Every proposed strong request refuses.

R216-IMMUTABLE-INPUT maps to AC216-A5-SCHEMA / WS216-01 / EV216-SCHEMA and existing
AC216-A5-CAPABILITY / WS216-02 / EV216-CLOSING-WINDOW. All six r22 policy categories
are covered by A501-A512 in the contract. Future commands are declared in the
manifest, NOT_RUN. H05, measured packet/native-budget fit, independent delta and
whole-candidate review/freeze, implementation and actual all12/platform/final
qualification remain open. Existing caps are retained, never presumed sufficient.


## Revision22 — A5 according to existing host capabilities

User-approved scope: strong A5 is enabled only for an existing route with proven
continuous input protection. Other routes refuse that mode and may meet release
acceptance with a reviewed limitation plus actual source-bound refusal proof.
The positive A5 invariant is unchanged; no endpoint-hash fallback, silent downgrade
or immutable-input/write-scope exemption is allowed on a limited route. Ordinary
source/result/ownership/audit and independently required security/validity checks
remain mandatory; any operation requiring unavailable protection remains refused.

`cf01-a5-capability-scope.json` is the normative applicability authority for all12
adapter routes. Older unconditional A5 prerequisite statements below apply to the
STRONG_A5 branch; limited routes instead require a complete refusal integration
contract before freeze and actual route/consumer qualification before release.
H04 support does not establish A5 support. Unknown remains UNPROVEN, not PASS.
The accepted r19/r20/r21 design is retained. This r22 amendment needs scoped
independent review; full candidate readiness, H05, actual fit and all implementation,
storage/platform/final release gates remain open. Historical revision narratives
below are retained as history and do not override this current applicability rule.

Existing owners retained; implementation follows independent accepting review and matching freeze.

## WS216-01 — contract-worker

Depends on: none.

- `policy/architecture-dependencies.json`
- `src/agent_lifecycle/accounting/__init__.py`
- `src/agent_lifecycle/accounting/closing_resources.py`
- `src/agent_lifecycle/accounting/closing_resource_recovery.py`
- `src/agent_lifecycle/accounting/closing_resource_policy.py`
- `src/agent_lifecycle/accounting/contracts.py`
- `src/agent_lifecycle/accounting/journal.py`
- `src/agent_lifecycle/accounting/normalization.py`
- `src/agent_lifecycle/accounting/opening_balances.py`
- `src/agent_lifecycle/accounting/support_profiles.py`
- `src/agent_lifecycle/accounting/workflow_store.py`
- `src/agent_lifecycle/accounting/workflow_state_store.py`
- `src/agent_lifecycle/accounting/workflow_authority_store.py`
- `src/agent_lifecycle/audit/implementation.py`
- `src/agent_lifecycle/contracts/audit_schemas.py`
- `src/agent_lifecycle/contracts/closing_resource_schemas.py`
- `src/agent_lifecycle/contracts/deadline_schemas.py`
- `src/agent_lifecycle/contracts/deadlines.py`
- `src/agent_lifecycle/contracts/ed25519.py`
- `src/agent_lifecycle/contracts/evidence_receipt_schemas.py`
- `src/agent_lifecycle/contracts/implementation_audit_validation.py`
- `src/agent_lifecycle/contracts/plan_manifest_schemas.py`
- `src/agent_lifecycle/contracts/reviewer_identity_schemas.py`
- `src/agent_lifecycle/contracts/schemas.py`
- `src/agent_lifecycle/contracts/workflow_authority.py`
- `src/agent_lifecycle/contracts/workflow_authority_schemas.py`
- `src/agent_lifecycle/contracts/workflow_state_schemas.py`
- `src/agent_lifecycle/neutrality/ed25519.py`
- `src/agent_lifecycle/planning/manifest_contract.py`
- `src/agent_lifecycle/review/provenance.py`
- `src/agent_lifecycle/workflow/closing_policy.py`
- `src/agent_lifecycle/workflow/finalization.py`
- `src/agent_lifecycle/workflow/implementation_audit_gate.py`
- `tests/accounting/__init__.py`
- `tests/accounting/fixtures/release_216_accounting.json`
- `tests/accounting/fixtures/release_216_adapter_profiles.json`
- `tests/accounting/test_closing_resources.py`
- `tests/accounting/test_closing_resources_recovery.py`
- `tests/accounting/test_deadline_clock.py`
- `tests/accounting/test_journal.py`
- `tests/accounting/test_normalization.py`
- `tests/accounting/test_opening_balances.py`
- `tests/accounting/test_support_profiles.py`
- `tests/accounting/test_workflow_authority_store.py`
- `tests/accounting/test_workflow_store.py`
- `tests/accounting/test_workflow_store_recovery.py`
- `tests/audit/fixtures/release_216_evidence_contracts.json`
- `tests/audit/test_implementation_audit.py`
- `tests/audit/test_implementation_audit_review_mesh.py`
- `tests/contracts/test_audit_schemas.py`
- `tests/contracts/test_deadlines.py`
- `tests/contracts/test_evidence_receipt_schemas.py`
- `tests/contracts/test_plan_manifest_schemas.py`
- `tests/contracts/test_reviewer_identity_schemas.py`
- `tests/contracts/test_workflow_authority.py`
- `tests/contracts/test_workflow_state_schemas.py`
- `tests/neutrality/test_ed25519_vectors.py`
- `tests/planning/test_manifest_contract.py`
- `tests/review/__init__.py`
- `tests/review/fixtures/reviewer_provenance.v1.json`
- `tests/review/test_provenance.py`
- `tests/workflow/test_closing_policy.py`
- `tests/workflow/test_finalization.py`
- `tests/workflow/test_finalization_audit_outcomes.py`
- `tests/workflow/test_implementation_audit_gate.py`

## WS216-02 — integration-worker

Depends on: WS216-01.

- `docs/reference/audit-evidence-and-reviewer-provenance.md`
- `docs/reference/host-local-token-accounting.md`
- `docs/ru/reference/audit-evidence-and-reviewer-provenance.md`
- `docs/ru/reference/host-local-token-accounting.md`
- `profiles/accounting-adapter-capabilities.v1.json`
- `src/agent_lifecycle/accounting/host_bridge.py`
- `src/agent_lifecycle/cli/dispatch_lifecycle.py`
- `src/agent_lifecycle/cli/host_launch.py`
- `src/agent_lifecycle/cli/lifecycle_parsers.py`
- `src/agent_lifecycle/contracts/closing_window_schemas.py`
- `src/agent_lifecycle/contracts/review_mesh_schemas.py`
- `src/agent_lifecycle/contracts/workflow_authorization_schemas.py`
- `src/agent_lifecycle/freeze/package_integrity.py`
- `src/agent_lifecycle/review/validation.py`
- `src/agent_lifecycle/review_mesh/contracts.py`
- `src/agent_lifecycle/review_mesh/results.py`
- `src/agent_lifecycle/workflow/authorization.py`
- `src/agent_lifecycle/workflow/closing_window.py`
- `src/agent_lifecycle/workflow/continuation.py`
- `src/agent_lifecycle/workflow/deadline_guards.py`
- `src/agent_lifecycle/workflow/events.py`
- `src/agent_lifecycle/workflow/gates.py`
- `src/agent_lifecycle/workflow/operation_kernel.py`
- `src/agent_lifecycle/workflow/plan_adoption.py`
- `src/agent_lifecycle/workflow/review_mesh_gate.py`
- `src/agent_lifecycle/workflow/reviews.py`
- `src/agent_lifecycle/workflow/risk_execution_gate.py`
- `src/agent_lifecycle/workflow/state.py`
- `src/agent_lifecycle/workflow/task_start.py`
- `src/agent_lifecycle/workflow/task_transitions.py`
- `tests/accounting/test_host_bridge.py`
- `tests/cli/test_closing_window_commands.py`
- `tests/cli/test_host_launch_commands.py`
- `tests/contracts/test_closing_window_schemas.py`
- `tests/contracts/test_review_mesh_schemas.py`
- `tests/freeze/test_plan_package_integrity.py`
- `tests/planning/test_sdd_services.py`
- `tests/release/test_accounting_adapter_profiles.py`
- `tests/review/test_validation.py`
- `tests/review_mesh/test_contracts.py`
- `tests/review_mesh/test_quorum_gate.py`
- `tests/review_mesh/test_result_import.py`
- `tests/workflow/fixtures/release_216_recovery.json`
- `tests/workflow/test_closing_authority.py`
- `tests/workflow/test_closing_resource_integration.py`
- `tests/workflow/test_closing_window.py`
- `tests/workflow/test_closing_window_integration.py`
- `tests/workflow/test_closing_window_recovery.py`
- `tests/workflow/test_deadline_guards.py`
- `tests/workflow/test_deadline_integration.py`
- `tests/workflow/test_plan_adoption.py`
- `tests/workflow/test_review_mesh_gate.py`
- `tests/workflow/test_task_acceptance_audit_gate.py`
- `tools/release/validate_accounting_adapter_profiles.py`

## WS216-03 — release-worker

Depends on: WS216-02.

- `.agents/plugins/marketplace.json`
- `.claude-plugin/marketplace.json`
- `.claude-plugin/plugin.json`
- `.codex-plugin/plugin.json`
- `.cursor-plugin/marketplace.json`
- `.cursor-plugin/plugin.json`
- `CHANGELOG.md`
- `README.md`
- `adapters/claude/.claude-plugin/plugin.json`
- `adapters/codex/.codex-plugin/plugin.json`
- `adapters/cursor/.cursor-plugin/plugin.json`
- `docs/README.md`
- `docs/guides/install-and-first-run.md`
- `docs/reference/cli.md`
- `docs/ru/README.md`
- `docs/ru/guides/install-and-first-run.md`
- `docs/ru/reference/cli.md`
- `pyproject.toml`
- `src/agent_lifecycle/_version.py`
- `tests/metrics/fixtures/release-2-16-accounting.json`
- `tests/release/test_docs_gates.py`
- `tests/release/test_publication_adoption.py`
- `tests/release/test_publication_versions.py`
- `tools/release/publication_contract.py`
- `uv.lock`


## A5 r22 ownership limit

No product write path or owner changes in this policy amendment. Existing mapped
reviews.py/task_transitions.py sites are candidates within WS216-02 ownership.
The shared adapter_sessions/local_launch_profile.py is a read-only source reference,
not an added write grant. Actual dispatch/refusal schema/test ownership must be
explicitly mapped and reviewed before implementation/freeze; no directory grant.

## Revision23 exact A5 implementation ownership

All entries below are prospective; implementation requires matching reviewed freeze.

- `src/agent_lifecycle/contracts/immutable_input_schemas.py` — WS216-01 (NEW): Closed proposed Policy/Request/Decision schemas and validation; no strong-positive v1 variant
- `src/agent_lifecycle/workflow/immutable_input.py` — WS216-02 (NEW): Pure policy/request decision and native expected-context binding helpers
- `src/agent_lifecycle/contracts/plan_manifest_schemas.py` — WS216-01 (EXISTING): Explicit frozen A5 task requirement/policy reference compatibility
- `src/agent_lifecycle/planning/manifest_contract.py` — WS216-01 (EXISTING): Validate exact frozen policy applicability and new/legacy distinction
- `src/agent_lifecycle/contracts/workflow_state_schemas.py` — WS216-01 (EXISTING): Explicit actual-attempt ordinary classification slot; closed schema compatibility
- `src/agent_lifecycle/workflow/task_start.py` — WS216-02 (EXISTING): Pure early denial before helper gates/mutation and successful attempt-bound classification persistence
- `src/agent_lifecycle/workflow/reviews.py` — WS216-02 (EXISTING): Result/review expected applicability and exact attempt binding
- `src/agent_lifecycle/workflow/task_transitions.py` — WS216-02 (EXISTING): Result commit/ownership/acceptance no-exemption checks
- `src/agent_lifecycle/contracts/implementation_audit_validation.py` — WS216-01 (EXISTING): Expected A5 applicability checked by independent audit consumer
- `src/agent_lifecycle/workflow/finalization.py` — WS216-01 (EXISTING): Accepted r22 limited applicability at Q0/final consumer; retain required security/current-state predicates
- `tests/contracts/test_immutable_input_schemas.py` — WS216-01 (NEW): Closed record mismatch/type/positive-forgery qualification cases
- `tests/workflow/test_immutable_input_admission.py` — WS216-02 (NEW): Pre-mutation/pre-helper rejection, stripped request and actual-attempt consumer semantics
- `tests/workflow/fixtures/release_216_a5_routes.json` — WS216-02 (NEW): All12 exact source-bound refusal/ordinary-path inputs; no fabricated runtime facts
- `src/agent_lifecycle/adapter_sessions/launch_execution.py` — WS216-02 (EXISTING): Candidate planning callback guard; preserve generic blocked route
- `src/agent_lifecycle/adapter_sessions/launch_preflight.py` — WS216-02 (EXISTING): Operation context and explicit guarded managed sink
- `src/agent_lifecycle/adapter_sessions/planning_launch.py` — WS216-02 (EXISTING): Guard direct planning sink before task envelope/process stdin
- `src/agent_lifecycle/adapter_sessions/immutable_input.py` — WS216-02 (NEW): Native-bound invocation context construction/validation, no bearer authorization
- `tests/adapter_sessions/test_immutable_input_launch.py` — WS216-02 (NEW): Actual managed/planning/qualification/preflight callback and input-transport denial oracles
- `src/agent_lifecycle/workflow/plan_adoption.py` — WS216-02 (EXISTING): Materialize A5 policy and preserve original accepted admission plus explicit compatibility binding; preserve existing WIP.
- `src/agent_lifecycle/adapter_sessions/unified_start.py` — WS216-02 (EXISTING): Normalize and propagate the actual request through both core/project paths and planning/managed callers.
- `tests/workflow/test_plan_adoption.py` — WS216-02 (EXISTING): Only new A5 carryover cases; preserve accepted finalization fix/evidence.
- `tests/contracts/test_workflow_state_schemas.py` — WS216-01 (EXISTING): Conditional A5 slot/cross-field validation and legacy no-positive compatibility.
- `tests/contracts/test_plan_manifest_schemas.py` — WS216-01 (EXISTING): Plan/task policy declared-presence and digest/enum negative cases.
- `tests/planning/test_manifest_contract.py` — WS216-01 (EXISTING): Cross-field default/task policy consistency and downgrade refusal.
- `tests/adapter_sessions/test_immutable_input_start.py` — WS216-02 (NEW): Real unified-start call paths preserve request through project/default/resume/direct branches.
- `profiles/immutable-input-adapter-capabilities.v1.json` — WS216-02 (NEW): Versioned all12 A5 expectation inventory, independent from H04. Every initial record strongAdmissionSupported=false; no runtime PASS from profile data.

## r69l R11 PRE bootstrap successor (DRAFT)

For the current prospective PRE bootstrap, `r69l-r11-bootstrap-delta.md`, the r69l route/manifest, v9/v4 oracles and v5 schemas supersede earlier r69j/r69k one-turn, six-path, 70-path and v4-only PRE wording. Earlier text remains historical for its pinned revision and for unchanged task/release gates. The installed r69k lock remains authority until a separate full DRAFT/FROZEN S2, exact report, canonical lock and controlled transfer. The r362 FAIL remains open; no product/native/release PASS is inferred.
