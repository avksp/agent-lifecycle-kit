> **Current r69q exact FROZEN role-delivery candidate.** Current delivery authority is r69q-role-delivery-delta.md and r69q-role-contract.json. Superseded v4/v5 delivery/count/budget/roster/status passages below are historical ONLY for that enumerated delta; all unchanged product/ownership/security/native/release requirements remain mandatory. Exact DRAFT/FROZEN review and canonical lock required before transfer; installed r69p remains authority. C34 candidate96/C35=16; no implementation or host proof. WS216-01 DENY; Release NOT_READY. r413 exact r69q DRAFT accepted fullReview=true READY_TO_FREEZE, report SHA 4770d7fc3ecd16b5d2da2609ca3635ec2cdfce71eae066541643d24c00b9797d. Exact FROZEN shape requires its matching independent report, canonical lock and verified transfer; implementation/host/native/release proof not granted by plan status.

> **r69k R10 FROZEN shape pending exact review.** r352 independently accepted the corrected 50-file DRAFT subject (body SHA `93cecf316b40a6564bf877bb5f3d253544f6c0576116c78a05b49088013e8079`) with fullReview=true and no findings. This candidate changes only status, review metadata and top historical notices; the FROZEN-shape report and canonical lock are absent. The verified installed r69j parent lock `c96f464a845c7e69a4fd08af705d55cffb3a4db328cf1eb5a1eef17b9d4d894b` remains authority. Older notices and DRAFT text below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69k R10 isolated DRAFT; independent plan S2 pending.** r348 independently accepted corrected R10 specification SHA `14e5fbba22aa6258ba051abccffec3a0b07b97a9e7174d20491889dbaa43bfda` for plan drafting only. This candidate raises the one-turn request cap to 245760 bytes and binds r69k successor to verified r69j parent. The installed r69j lock `c96f464a845c7e69a4fd08af705d55cffb3a4db328cf1eb5a1eef17b9d4d894b` remains authority; r69k has no independent plan review or lock. Older notices below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69j R9 FROZEN shape pending exact review.** r333 independently accepted the exact corrected DRAFT subject (raw reviewer body SHA `858e61c9211e114ed3392f1dd8425654857265e573b6a09312e4a6a98dededa2`) and closed R331-S2-M01. This candidate changes only status, review metadata and top historical notices; the FROZEN-shape report and canonical lock are absent. Older notices below are historical. Installed r69i parent lock `721d7e3fa60723d59708efddfe2166347af5abc0981d47153527b00382f0bd67` remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69j R9 isolated DRAFT; independent plan S2 pending.** r329 accepted exact R9 specification SHA `965d2c4c02d4dc80b9538288355294391feb94a0f3bd1e6899c0a3b070bf5d03` for plan drafting only. Candidate v3 support oracle `671ed21d004beedecb80e1785a478e1eb95375a3593df3cd0a731a0151a3b84e` and v8 source oracle `d19e5edb56f4908c949f4239763038915f27798f54e8cdbbc13db6a361f93834` are not installed. Parent r69i verified lock `721d7e3fa60723d59708efddfe2166347af5abc0981d47153527b00382f0bd67` remains installed in execution57. No r69j plan-review report or lock exists; WS216-01 native DENY and Release NOT_READY. Older notices below are historical.

> **r69i R8-R3 FROZEN shape pending exact review.** r301 independently accepted the exact DRAFT subject (raw reviewer body SHA `f96bbe126d9f2dd7bbcf996608a4cbf978d9ff8c39227deab75453878f4ab9fd`). This candidate changes only status, review metadata and top historical notices; its future independent report path is declared but the FROZEN-shape report and canonical lock are absent. Older DRAFT notices below are historical. Installed r69h lock `a1d7a69a05f5887b72165613ebb116bf59f2bf52b59d6f851c66b977c284976c` remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69i R8-R3 isolated DRAFT; independent plan S2 pending.** r299 independently accepted exact R8-R3 specification SHA `bef13eb0608b604ffb88a659abe8b0d940046b52ff5ca2f732eecd48ed924cb7` and source oracle SHA `5f7b3cee3f074ebfbf4129bd4058d38116ef8385be20e6fbcd965158bc07a4fe` for plan drafting only. This candidate overlays the `codex_exact_prompt.py` FULL-source row with typed AST slices and local dependency closure; all other R7/v6 requirements remain. Parent r69h verified lock `a1d7a69a05f5887b72165613ebb116bf59f2bf52b59d6f851c66b977c284976c` stays installed in execution57. This r69i candidate has no plan-review report or lock; WS216-01 native DENY and Release NOT_READY. Older r69h/r69g notices below are historical.

> **r69h R7 FROZEN shape pending exact review.** r288 independently accepted the prior DRAFT subject (raw reviewer body SHA `1a5a331060a81d40e9be6a366856ad4742004567520d91526883485ccd4e6399`). This candidate changes only status, review metadata and overview notices; its future independent report path is declared but the FROZEN-shape report and canonical lock are absent. The older DRAFT notice below is historical. Installed r69g remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69h isolated R7 DRAFT — current delivery authority.** r286 independently accepted R7 specification SHA `b54ebc77c4cc89aed0d809a4d193a15a61e7132a651f6db18f6dc98051732ab1` and oracle v6 SHA `aa25670dc55f6c1fb28ba249b9f24dc6115e470e13e0a6d75166ed2023edb702` for plan drafting only. The copied specification preserves its historical pre-adoption status; this candidate now pins R7/v6. Installed r69g lock `673715e292661c13b6d9c7222434d60b2c0247a54a61d45cf5bd3861c3043a99` remains authoritative. r282's R5/v4 DRAFT review was CHANGES_REQUIRED; this amended DRAFT has no independent plan acceptance or lock. Older delivery notices below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69g FROZEN shape pending exact review.** r254 independently accepted the prior DRAFT subject (raw reviewer body SHA 023d7fd1873d6094ef474f6ddc68e908fc28cc5dbf62e3d0f2891707fbeb58a4). This FROZEN-shaped candidate changes status/review metadata and overview notices only; its report path is declared but the independent FROZEN-shape report and canonical lock are absent. Older DRAFT notices below are historical. Installed r69f remains authoritative; WS216-01 native is DENY.

> **r69g DRAFT delivery successor.** Installed r69f lock SHA 45a280b5dfc5e83e88d6c1f4d635b9ace7e5d1adaf3f9795a1215288bfe54dd5 remains authoritative. Exact independently READY_TO_DRAFT S2 specification SHA 6e7981627ffa616a7fabba856dca343e6f43c5eeda773d0eb87a572bdc7a0e1a is copied as `review-delivery-spec.md`. The current candidate replaces the reviewer-body producer with a same-thread `turn/start.outputSchema` item after `review/start` text; it requires the clean sentinel, full-subject saved request, dual-item collector/fresh read and unchanged PRE limits. Older r69 review-delivery paragraphs below describe historical candidates and do not override `route-bootstrap-contract.json#auditJoin.delivery`. No native WS216-01 from this DRAFT.

# Developer overview: Audit evidence and reviewer provenance truth

## Revision69b corrected DRAFT — exact limited native qualification

The active current-Codex profile and all three 16k workstream selectors use `ALK_CONTROLLED_OUTBOUND_INPUT_FIT` only. The retained config artifact binds credential-free ALK-controlled source bytes/SHA; Codex internal effective-config equality remains `UNPROVEN` for this claim. `route-bootstrap-contract.json#validation.limitedNativeMatrix` is the executable 24-row, six-role evidence contract: a separately admitted maximum of six selected Codex positive calls, 12 predispatch refusals without a model and six controlled local started-failure fixtures. Each row binds role, polarity, command template, producer, oracle, run/task/attempt/claim/lock and receipt path. Local fault rows cannot count as selected Codex native positive; original strong IF09/IF12 remain `NOT_RUN` for this limited profile. The exact r69b preview and review/lock are still pending; r68e remains installed authority and native WS01 is `DENY`.

## Revision69 current DRAFT — current-Codex limited outbound proof

This isolated plan candidate has parent r68e verified lock SHA `a619308da56efc1fe0c23a65de9b8c04074e79e93d7247f02958b5a831af6c66` and accepted S2 specification SHA `c69a24fa6170ba4a509048c2d4cf218f970f793431bc2cce6e08ce8687dec018`. It is not reviewed or locked. All historical revision paragraphs below describe their then-current states; the r69 rules in `route-bootstrap-contract.json#limitedFitApplicability` and `alk-input-fit-contract.json#r69FitDisposition` govern this candidate. r68e remains installed authority; native WS01 DENY, Release NOT_READY.

The proposed current-Codex positive claim covers only ALK-constructed bytes accepted by the OS stdin pipe associated with the selected child, not model-visible input or child consumption. Per-role fresh diagnostic and catalog are prelaunch candidates, not future native equivalence. Strong host-fit/financial requests refuse before dispatch. After observed Popen, only complete same-attempt pipe write/close plus joined native success/usage can pass the new limited case; failure retains unknown cost. Original strong IF09/IF12 remain NOT_RUN for this limited profile. All other accounting, H05/A5, 12-adapter, privacy, 30-day cleanup, hourly scheduler, security/platform/publication and final-audit gates remain.


## Revision68 current draft: source-bound RB11 and maintenance handoff

This is the exact r68 draft successor to the reviewed r176 specification SHA `b4a00c69751e67bfc81c277d38e0f2904c7f862ef461bdc596feb4019a1dc413` and current r67b lock SHA `56766d2d39988723484ce412523bbb34ab6ac6ae31f9e5deae1c96a779b6e561`. r67b remains operative until a separately accepted full S2 review, matching report and canonical r68 lock. No present product test or native/model result transfers to newly added cases.

Pre-WS01 lead owns only the six unchanged bootstrap paths; C34/C35 and independent audit cover RB01–RB12-PRE, with RB11-PRE limited to pure fully-closed eligibility/refusal. RB11-RUNTIME is `NOT_RUN` at that audit. WS01 owns journal/finalization/private authority and durable raw cleanup after SQL collection; WS02 owns the existing lifecycle CLI and new maintenance test; WS03 owns the operational document and installed hourly target schedule. Combined RB11 `PASS` is final-release-only after all three runtime owners and a supported-platform target probe. The old two-command prestart limit does not consume poststart commands.

The maintenance command uses a pinned private authority SHA and accepts no independent journal/root override. Started raw details delete only after authoritative full financial closure plus 30 days; unresolved runs have no purge clock. An immutable raw inventory and per-run pending obligation survive SQL collection and partial/crash unlink, with hash-only totals/dedup/closure state retained. The journal write-admission boundary covers fresh closure, due and financial-exception checks through bounded unlink and obligation result. Windows/macOS/Linux targets prove equivalent private path, identity and race-safe deletion behavior or refuse before unlink, retain PENDING/OVERDUE and block retention readiness. Same-user Codex does not gain a protected-close claim.

The independent bootstrap review uses a separately admitted local Codex App Server candidate, distinct review thread, completed item/turn, raw-text SHA and live `thread/read` verification. Documentation and installed schema are only interface candidates; runtime qualification is `NOT_RUN`. Selected-host positive IF09/IF12, all12 adapters, H04/H05/A5, numeric, security/platform/publication and final independent audit remain required. The current Codex claim is only `ALK_CONTROLLED_INPUT_FIT`; full host input/U/FULL_FINANCIAL and protected close remain unavailable. Missing native or review proof denies launch, and missing retention target proof blocks release.

## Revision67 current authority boundary

r67 is a separate FROZEN-shaped plan candidate from independently accepted r66b DRAFT digest `3a4fcec5600b08d35bceb8a5c2ebe7795695cd292bc15215520dbac702267ffb`. It needs exact full S2 review, matching machine report and verified lock before any pre-WS216-01 bootstrap or native admission; prior r66 lock references are historical.

## Revision66 audit provenance correction

The lead cannot establish pre-WS01 bootstrap audit success by writing its own summary. `route-bootstrap-contract.json` now names a distinct independent reviewer result with reviewer/lead actor-session separation, exact r66 lock/admission/six changed-byte/WIP/C34-C35/private-support/held-cost subject and digest verification by first-task admission. The lead summary joins that result by SHA; a missing, stale or self-produced result refuses. The active machine 16k state names only exact r66 local preview PASS, with selected-host native proof still pending. This correction changes no adapter, task DAG, numeric cap or product write owner.


## Revision65 pre-WS216-01 route bootstrap

The exact current-Codex route cannot be used for WS216-01 under locked r64 because its WS216-02 implementation is downstream. The accepted r152 S2 specification SHA `a4289b37d3372295aa85556adf5627fc272a294a49a1ef299e26b2084e043aa7` authorizes drafting a lead-owned, pre-run ALK bootstrap without accepting WS216-02 early. The six exact temporary writes and future WS216-02 ownership are in `route-bootstrap-contract.json`. The common gate binds explicit direct/unified route, claim and private request; an opt-in runner separates child-start observation from complete OS-pipe stdin delivery. Raw request lifecycle and 30-day fully-closed-run retention are explicit. Risks are false transport claims, private-input leakage, pre-WS01 ownership conflict and unmeasured coordinator cost; any missing proof refuses before launch or fails a started attempt while retaining cost. This draft changes no adapter or shipped profile and grants no native or release approval.


## Revision61 ALK-owned exact-prompt Codex execution route

Intent: qualify only the user's limited current-Codex ALK_CONTROLLED_INPUT_FIT claim without changing adapter code. The existing 0.147.0 fixed-prompt profile cannot carry the r60 task-bound input on installed 0.156.1. WS216-02 adds an explicit codex-exact-prompt-v1 managed route that canonically assembles all role components, checks inherited caps, qualifies stdin transport and a private effective-config snapshot, and refuses mismatches before the runner on direct/unified entries. Lead joins task-bound native evidence and final gates. Risks are an unbound child prompt/config, route bypass and secret exposure; missing proof refuses. Host-owned tokens/U, protected permissions, all12 adapters and release approval remain outside this local route claim. Accepted product S2 spec SHA `4e1245c0c8fc4c321f275829bf2953aea75e67c23e657b55a39f1ab360d88ae2`; r61 DRAFT awaits independent plan review.

## Revision54 correction candidate — independent full S2 review pending

Revision54 is a separate unreviewed successor to the independently rejected r53 bytes. It keeps Choice B and all r52 gates, and closes the four r53 review findings in plan text: CW01–CW11 plus exact route/directory/mode/temp inventory; positive-route storage v6 with refusal of adopted/pending v5, immutable anchor and B/P staging; disjoint SQL-owned same-generation event repair versus separate legacy quarantine; and prefreeze conditional fit with actual host proof before 16k native launch. r52 remains locked authority.


## Revision53 DRAFT — closing request and publication delta

Revision53 is an unreviewed successor to the locked r52 plan. It adds the closed 22-field intent/23-field request, signed four-class AllowedWrites, independently adopted output-root identity, and exact B producer versus E outbox recovery contract in `cf-d-window-request-contract.json` and `closing-write-inventory.json`. WS01 owns authority/Journal/resource/deadline/finalization; WS02 owns route/state/event/path primitives. Current Codex Choice B still refuses protected adoption/closing; ordinary guarded work and late settlement remain. The six new local WR01–WR06 cases are required; WR07–WR12 are future qualified/native or prefreeze inventory obligations. No r53 review, lock or native evidence exists; r52 remains execution authority.


## Revision52 prepared FROZEN-shape candidate — Choice B current-Codex capability-scoped closing

The user selected Choice B. On the current full-access Codex route ALK must refuse protected adoption, root/epoch-0 publication, closing activation/grant and protected dispatch before write or process start. Positive CC04–CC16, DS14, DA15 and joined DS/DA/DR/DD cases remain NOT_RUN/UNPROVEN under their original IDs; distinct OR01–OR19 native negatives and independently reviewed applicability are required for a limited release. All 53 retained WS01 local cases, CC01–CC03, late settlement, H04/H05, A5 for all12 adapters, platform/security/publication and numeric caps remain mandatory. A qualified future route must pass the original positive native cases before enabling protected closing. This prepared candidate has no accepting review, lock, native proof, task acceptance or release permission; r48 remains current.


## Revision48 — prepared adoption-input candidate

The r47 DRAFT staged the minimal adoption correction. This distinct r48 FROZEN-shape candidate defines closed AdoptionInput/AdoptionSelection shapes and exact legacy/accounting/root import rules, without changing owners, commands, cases, caps or release gates. Save exact source/fit preview before independent review. At preparation there is no r48 report, lock, run or task result; the r46 lock remains current. Host-owned input and DA15 operator provenance are still unproven.

## Revision47 — DRAFT adoption-input successor

Revision46 received an independent READY_TO_FREEZE report and lock, then WS01 implementation exposed an unclosed `adopt_run` input mapping. Revision47 is a separate DRAFT staging successor that adds only closed AdoptionInput/AdoptionSelection shapes and the exact legacy/accounting/root import semantics. The r46 lock remains current until a later distinct candidate passes independent review and lock; no native run or WS01 acceptance exists. No product code, write ownership, task/cap, command, case, evidence, host or release gate changes in this plan draft.

## Revision46 — prepared WS01 D-RESOURCE ownership candidate

Revision45 was the DRAFT successor after two nonaccepting r44 reviews.
Revision46 is a distinct prepared FROZEN-shape candidate for the same two
WS01 D-RESOURCE modules. Only 62 already owned product files may transfer
after independent review and a new lock. The preserved r58 test file is
excluded; WS01 must carry its meaningful cases into its already owned test
file before acceptance. The 16k input preview and all source bytes must be
bound to this revision; 4k/8k remain refusal routes. At r46 preparation no report or lock existed; its later review/lock did
not start a native run, accept WS01 or prove provider/release guarantees.

## Revision45 — DRAFT successor after rejected r44

Both r44 independent reviews were nonaccepting. The second confirmed the
62-file selected transfer and 16k fit but required a fresh revision after the
first rejection. Revision45 is a DRAFT staging successor only: no report,
lock, native run, budget renewal or task acceptance follows from it.

## Revision44 — WS01 D-RESOURCE module ownership correction

The r43 plan and lock did not assign the read-only closing resource recovery
module, and the planned pure `prepare_closing_policy` cannot safely grow inside
the existing 794-line `accounting/closing_resources.py` retention mixin.
Revision44 assigns `accounting/closing_resource_recovery.py` to immutable
membership/bucket reconciliation and `accounting/closing_resource_policy.py`
to pure proposal/candidate construction. Both remain WS216-01-owned and use
only the existing Journal boundary for any future mutation. This corrects
placement only; no case, command, cap, evidence ID, host guarantee or release
gate changes. r43 WIP is not accepted by its lock; no native r43 run exists.
The first r44 review found an unowned r58 test file in execution43. That file
stays byte-exact in historical WIP and is excluded from the r44 transfer; WS01
must move its meaningful cases into the already owned
`tests/workflow/test_implementation_audit_gate.py` before task acceptance.

## Revision43 — WS01 WorkflowStore ownership correction

WS01's existing `accounting/workflow_store.py` is a 798-line JournalStoreMixin,
not the D-STATE WorkflowStore public port described by the frozen design.
Revision43 assigns `accounting/workflow_state_store.py` for that public port and
`accounting/workflow_authority_store.py` for package-internal D-AUTH transactions.
Both must share the existing Journal database, admission and `BEGIN IMMEDIATE`
transaction; no separate authority store or broad callback is allowed. This is
an ownership/placement correction only. No command, case, cap, evidence ID,
producer guarantee, adapter scope or release gate changes. The r42 lock and
READY run remain historical; WS01 was not started and no C1 acceptance exists.

## Revision38 — complete pre-review cap receipts

The independent r36 full review rejected an exact preview that omitted successful cap checks and counts. Revision37 was the DRAFT successor. Revision38 prepares a fresh candidate whose read-only preview must save every renderer check and explicit non-token cap outcome before independent review. Report, lock, run state, executable cases and release authority remain absent at preparation.

## Revision36 — exact preview review gate

Revision34 was archived without adoption after the post-lock independent review found its exact pre-review preview missing. Revision35 was the DRAFT successor. Revision36 saved an exact packet/source/six-role preview, but its independent review found the cap-check receipt incomplete and returned `CHANGES_REQUIRED`; no report, lock, run state or release authority followed.

## Revision34 — prepared candidate stage

Revision33's full review found one remaining Medium status conflict in active preparation instructions. Revision34 marked the DRAFT-to-FROZEN recipe as historical and updated the delivery order. It later received review/lock, then was superseded without adoption for a missing exact pre-review preview; the archive preserves those bytes.

## Revision33 — status-bound candidate

The full independent r32 review rejected conflicting current-status prose, while accepting the native pre-review shape and retained design coverage. Revision33 time-scoped several stale DRAFT/PENDING controls; its full review found one remaining active instruction conflict. No report, lock, run state, executable H05/IF evidence or release authority followed.

## Revision32 — prepared native review candidate

The r31 S2 design was accepted by composed independent review after its actual-launch correction. Revision32 prepared exact bytes for a full independent review, which returned `CHANGES_REQUIRED` for status prose. Its manifest `FROZEN` marker created no lock, execution authority or release proof; all IF/H05, host, platform, security and final gates remained open.

## Revision31 — reachable dispatch boundary

WS216-02's already owned `unified_start.py` and `launch_preflight.py` are now exact input-fit integration points. `managedTask` requires a valid bound receipt before the local-profile process runner; direct callers without one must not start a host process. `planningTask` is limited and refuses stronger fit/financial requests. IF05/IF07/IF08 remain planned tests under C20; no current runtime proof is claimed.

## Revision30 — ALK input-fit design

`alk-input-fit-contract.json` assigns the exact 15-ref selector/limit contract to WS216-01 and ALK dispatch/consumer joins to WS216-02. IF01–IF08 are planned positive/negative oracles under retained C18/C20 commands. Current source-derived fit and host feasibility remain separate; no native or actual model-input proof exists. The r29 High fit finding needs an independent correction review before any whole-plan acceptance.

## Revision28 — context route

The current unsplit WS216-01/02 fail the source-derived 4k/8k profile checks. Their proposed 16k route requires actual host/version support and exact candidate/native/host-input fit; otherwise dispatch refuses until a reviewed split or other revision. The exact revision52 preview fails WS216-03 on 4k/8k; both routes refuse this candidate. Historical r27 local PASS is not current host qualification. The pinned prefreeze fit contract carries the exact decision; the plan remains DRAFT/PENDING.

## Revision26 — proof stages

The prefreeze fit contract now separates documented host/ALK design feasibility and independent H05 design traceability from post-implementation admission/refusal, authoritative usage and executed H05 proof. Status remains DRAFT/PENDING; release gates remain open.

## Revision25 — staged fit measurement

The pinned `prefreeze-fit-contract.md` separates read-only DRAFT candidate measurement, exact post-review/lock native comparison, and actual host usage qualification. It preserves H04 per-host applicability, H05 full coverage and all final gates. Packet-size projection alone cannot assert host-input fit or financial enforcement. Status remains DRAFT/PENDING.

## Revision23 — concrete A5 limited implementation candidate

`cf01-a5-implementation-contract.json` now defines the proposed closed records,
frozen policy/state/adoption join, ordinary planning request binding, exact ALK
launch/refusal and consumer hooks, all12 saved expectation targets, exact owners
and 12 future oracle groups. Status: DRAFT_REQUIRES_INDEPENDENT_DELTA_REVIEW.
The accepted r22 capability policy and r19-r21 authority/storage/resource/deadline
semantics remain unchanged. This amendment supersedes only their unresolved A5
integration placeholders; it does not claim full-plan acceptance or runtime proof.

Ordinary standalone context binds the actual explicit operation/input; it is not
a bearer authorization and needs no invented authority file or workflow attempt.
Frozen workflow requirements remain independently authoritative. Accepted attempts
retain original A5 classification/evidence/cost and use a separate adoption binding.
No strong-positive v1 variant exists. Every proposed strong request refuses.

R216-IMMUTABLE-INPUT maps to AC216-A5-SCHEMA / WS216-01 / EV216-SCHEMA and existing
AC216-A5-CAPABILITY / WS216-02 / EV216-CLOSING-WINDOW. All six r22 policy categories
are covered by A501-A512 in the contract. Future commands are declared in the
manifest, NOT_RUN. H05, measured packet/native-budget fit, independent delta and
whole-candidate review/freeze, implementation and actual all12/platform/final
qualification remain open. Existing caps are retained, never presumed sufficient.


## Revision22 — A5 according to existing host capabilities

User-approved scope: strong A5 is enabled only for an existing route with proven
continuous input protection. Other routes refuse that mode and may meet release
acceptance with a reviewed limitation plus actual source-bound refusal proof.
The positive A5 invariant is unchanged; no endpoint-hash fallback, silent downgrade
or immutable-input/write-scope exemption is allowed on a limited route. Ordinary
source/result/ownership/audit and independently required security/validity checks
remain mandatory; any operation requiring unavailable protection remains refused.

`cf01-a5-capability-scope.json` is the normative applicability authority for all12
adapter routes. Older unconditional A5 prerequisite statements below apply to the
STRONG_A5 branch; limited routes instead require a complete refusal integration
contract before freeze and actual route/consumer qualification before release.
H04 support does not establish A5 support. Unknown remains UNPROVEN, not PASS.
The accepted r19/r20/r21 design is retained. This r22 amendment needs scoped
independent review; full candidate readiness, H05, actual fit and all implementation,
storage/platform/final release gates remain open. Historical revision narratives
below are retained as history and do not override this current applicability rule.

## Revision21 — exact local proof and FINALIZE authority decisions

R20-DELTA-M01 is author-corrected pending independent narrow review. D-AUTH now
specifies distinct PRODUCE_PROOF and FINALIZE decision keys, both using the existing
signed grant action finalize and null claimId. They reference the original activated
grant/nonce without renewed allowance; genuine financial CLAIM remains separate.
A closed Q0 binds once-only local deterministic proof production; P records Q0/A0.
Final A1 binds the fixed Q and commits atomically with E and the final result/outbox.
Local variants cannot authorize model/provider/process/auditor/test work.

The accepted r20 current-receipt/ABSENT-cap corrections and final proof hash,
materialization/publication/replay construction remain retained. Only the affected
authorization and DS02/DS07/DD10/DD12 joins require review. All runtime cases are
NOT_RUN; original owners/commands/evidence IDs/budgets/gates and all12 adapter
limitations remain unchanged. No product code/tests/native/host changes or freeze.

## Revision20 — three precise joins after complete r19 review

The independent r19 review completed all14parts and confirmed R18-JOINED-M01
replay correction. Three Medium findings are author-corrected here, pending an
independent delta review: R19-JOINED-M01 separates pinned freshness policy from
current receipt observations; M02 distinguishes ABSENT and FINITE retained caps;
M03 specifies prepared proof inputs, separate producer/final decisions, downstream
committed envelope, exact materialization and publication/replay identities.

See D-DEADLINE.currentEvidenceJoin, D-RESOURCE.capBindingSemantics and
D-STATE.finalProofConstruction and their closed wire schemas. Existing case IDs
DD04/DD08/DD10/DD12, DR04/DR18, DS02/DS07 now include the precise counterexamples.
All runtime cases remain NOT_RUN. No product code/tests/native/host changes.
This block supersedes older review-pending/partial statements only for completed
r19 coverage. The raw r19 CHANGES_REQUIRED report remains immutable; no blanket
whole-release acceptance, freeze or native qualification follows. Existing exact
owners, command groups, evidence routes, budgets and retained A5/H05/fit/all12
adapter/platform/final gates are unchanged. Review only these deltas and joins.

## Revision19 — committed replay before pending-publication rejection

R18-JOINED-M01 is author-corrected pending independent verification. D-STATE P1
qualifies the authoritative store, P2 returns an identical committed result even
while publication is PENDING, and only the new-operation branch rejects pending
publication and checks fresh authority/revisions. Replay adds no event, allowance,
nonce, reservation, claim or dispatch. DS02 now holds publication unavailable
throughout its pre-ACK replay. No product code or test changed.

The previous independent report remains CHANGES_REQUIRED/PARTIAL with all unread
sections still unreviewed. This revision makes no new whole-design, native or
release readiness claim. All four contracts need completion of the bounded review.

## Revision18 — D-DEADLINE configured consumers and current time

cf-d-deadline-contract.json joins the four closing-window design contracts. Actual
runtime gate input is per-task controllerGates and its producer/phase configuration,
not securityGates prose. Only an independently declared compatible execution-only
predicate may consume signed closing permission; run/attempt wall budgets, evidence
freshness, lease/grace/I-O and opaque custom gates retain their original bounds.

The supplied historical receipt identifies project planning/immutable-gate.py and
its execution-deadline failure. Its old FAIL is preserved; historical script source
semantics/current runtime qualification remain unproven. No gate was rerun or
project script/host patched. New contract templates are reviewable before freeze;
actual compiled registry/source/clock identities must be qualified after implementation.

New workflow timestamps use canonical UTC microseconds. D-AUTH and D-DEADLINE share
the same fresh final decision observation; replay/projection never renews time.
Late useful results and all actual costs remain recordable, with reuse classified
separately from permission. Final-audit acceptance or a prepared proof file alone
cannot bypass finalization gates or commit COMPLETE after an invalid decision.

16NOT_RUN cases contribute8WS01 rule/clock-storage and8WS02 consumer/integration witnesses.
Seven exact ownership paths and two planned validation groups retain old owners and
native caps. The joined DRAFT needs independent review, then implementation/native
proof. CF01-A5/H05/actual fit/all12adapter/storage/platform/final gates remain open.

## Revision17 — D-RESOURCE prospective policy and current claim

cf-d-resource-contract.json defines the minimal ACCOUNTING_REPORTED_TOKENS_V1
policy effect in the existing journal, joined with D-STATE and D-AUTH. Signed
additional allowance A yields cumulative ceiling C=S+A at the exact signed anchor.
It never adds unused old allowance. Task/run/window constraints evaluate one charge;
old costs, caps, reserves, protection and violations remain. Source bound failure
or unknown opening cannot be repaired by raising a budget.

Activation records policy/window/nonce together. Reservation and once-claim both
validate current resource and authority state; claim includes the already reserved
U once. Each closeout transfer/refund stays with its original owner/window. A new
signed window may retire an earlier entitlement but cannot roll over unused A,
claim an old unclaimed permit or reset spend. Legacy billableTokens/invocations/
wallSeconds remain distinct unchanged guards; unsupported extension is unavailable.

20NOT_RUN cases contribute16WS01 resource witnesses and4WS02 integration witnesses.
Five exact ownership paths and two validation groups are added within unchanged
native ceilings. These are author design contracts, not implementation or evidence
of native enforcement. Configured D-DEADLINE consumers and their exact guard state
must be bound next, then the combined design needs independent review. CF01-A5,
H05/actual fit, all12adapter qualification and final release gates remain open.

## Revision16 — D-AUTH issuer, revocation and commit contract

cf-d-auth-contract.json defines an independently pinned operator root, a signed
per-run issuer snapshot and a separately signed closing grant. It reuses ALK's
Ed25519 implementation through a planned contracts extraction with compatibility
exports. A name, receipt hash, external pathname or TEST_AUTHORITY is insufficient
owner proof. Native bootstrap qualification remains required as DA15.

The existing SQLite writer transaction orders authority publication, nonce use,
workflow activation and financial claim. A revocation takes effect when its signed
snapshot commits locally. A prior committed claim is in flight and cannot be
promised cancelled by this protocol. Current authority/time and financial state
are rechecked at claim; historical replay cannot issue a new permit. Expiry during
projection or commit does not extend permission or cause checks to restart.

Sixteen NOT_RUN cases contribute12WS01 authority/storage witnesses and4WS02
integration/native witnesses. Eight additional exact ownership paths and two
planned validation groups preserve all previous owners, cases and finite ceilings.
This is a concrete design candidate, not implementation or independent acceptance.
D-RESOURCE must close the exact approval-policy schema/transaction/claim join next;
configured D-DEADLINE, CF01-A5, H05/actual fit and final review remain open.
Only ALK is changed by the planned implementation; all12adapter capability limits,
FULL_FINANCIAL semantics and30-day financially-closed detail retention are retained.

## Revision15 — D-STATE transaction and recovery contract

cf-d-state-contract.json selects one authoritative SQLite transaction for workflow
state/event/result, closing window, nonce use and qualified prospective policy.
JSON state/event files become derived, generation-bound projections. Existing
Journal transaction/version/writer admission is a primitive to extend, not proof
that this workflow feature already exists. A typed WS01 WorkflowStore port owns
storage/adoption/replay/publication; WS02 integrates state/kernel/events and every
permission consumer. No new database, JSONL authority implementation or benchmark
is introduced by this plan. Four exact paths and one planned command are added.

An operation committed before a lost reply returns the same durable semantic
result on replay. Pending/mismatched projection denies new dispatch. A claimed or
uncertain model invocation never restarts during storage recovery. Late expenses
remain recordable without renewing authority. Trusted JOURNAL_REQUIRED binding
prevents fallback to old JSON or a new empty accounting scope. Adoption requires
qualified legacy observation, known quiescent writers and preserved history.

The22 NOT_RUN cases separate18WS01 storage witnesses from4WS02 integration cases.
D-STATE is a concrete DRAFT design, not independently accepted or implemented.
D-AUTH commit-bound verification, D-RESOURCE same-transaction policy port, configured
D-DEADLINE consumers, CF01-A5, H05/actual fit and final candidate review remain open.
FULL_FINANCIAL limitations and30-day financially-closed retention remain unchanged.

## Revision14 — CF01/CF02 exact integration map

cf-integration-map.json is the current source/owner/oracle authority for this
integration. Fourteen rows separate source-read facts, reused accepted core proof,
declarations and proposed interfaces. Thirteen exact paths are added to the serial
WS01/WS02 ownership; no directory wildcard or product edit is authorized by DRAFT.
WS01 provides a pure closing-policy/state/finalization seam before WS02 native
activation. Direct CLI, Python and continuation routes must converge on the same
authoritative action/time/resource guard; ordinary task work cannot bypass it.

S2-R11-P01 is PARTIALLY_ADDRESSED, not closed. Existing neutrality signature code
is a domain-specific primitive, not a workflow owner grant. Kernel event append
and state replacement are separate; neither this nor accounting SQLite proves an
atomic activation/nonce/policy transition. The exact authority route, all-writer
transaction/recovery interface, configured execution-deadline/watchdog producers
and prospective resource policy API remain prefreeze design dependencies.
No literal execution-deadline consumer was found in the bounded repository source
search; dynamic/installed/configured consumers remain unproven, not nonexistent.

Evidence TTL, worker leases, process grace and capture deadlines cannot be extended
by a new execution permission. Expired permission does not discard valid evidence
or prevent late financial settlement; those actions do not grant new paid work.
CF01 A5/G-AUTH/G-OBS/G-TIME/G-CONSUME/G-SCOPE, H05 coverage and measured fit remain
open. No actor, receipt, counter, lock or runtime PASS is manufactured here.

## Revision 13 — pinned expectation inputs and staged runtime identity

All12 expectation templates are now populated in h04-adapter-profile-cases.json:
descriptor/capability hashes, selected versions with provenance, saved official
source snapshots, each documented candidate's ceiling/oracle, role and original
case obligations, and bounded qualification recipes. These are EXPECTED_NOT_OBSERVED
inputs pending independent review; no runtime profile is accepted by this revision.

r12's requirement for actual host executable/configuration hashes before freeze
is replaced by TARGET13 in h04-artifact-contracts.json. Before freeze review the
fixed targets, source hashes and claim/qualification policy. After implementation
bind exact existing runtime identity for every native-positive claim. A reviewed
source-bound limitation may use explicitly null runtime hashes and must reject
all native-positive/financial claims through actual ALK refusal. This grants no
host compatibility or permission to modify/install a host. Every documented
candidate still requires an individual justified disposition; no convenience fallback.

Native experiments require concrete admitted argv/configuration and source-bound
oracles before execution. The12x100000 ordinary planning allocations consume1.2M
of existing WS02 ordinary2M; remaining800000 covers integration/validation. WS02
protected250000 is shared once, not copied per profile. Request/time/tool/evidence
and validation-run fit remain unproven; this allocation changes no native cap.
Retained CF02/CF01 integration design, H05 coverage, actual fit and final independent
review still block freeze. No code/tests/native transition or release approval.

## Revision 12 — reviewed findings and current authority

r11 full-plan independent review returned CHANGES_REQUIRED (3 High,4 Medium).
r12 addresses S2-R11-H01/H02/M01/M02 in DRAFT; these are author corrections,
not independently closed findings. h04-artifact-contracts.json defines closed
artifact/request/result types, immutable expectation joins, exact comparison and
refusal rules, bounded producers and qualification milestones. The profile-case
file maps all21 profile oracles and all13 original core/native assertions.
WS01 produces pure resolver proof in its own EV; WS02 produces exact-final-profile
refusal after integration. Expected bindings are pinned templates, not runtime PASS; TARGET13 controls runtime qualification.
Before freeze populate and independently review all12 exact target/source/claim
and recipe expectations. Runtime qualification follows implementation and precedes
release. Existing CF02/CF01 transitive design, H05 independent coverage and actual
packet/budget fit remain open; no lock, execution or release approval exists.
Full H04 on current Codex remains optional; all12 scoped profile acceptance remains
mandatory. Earlier revision text is historical where it conflicts with this block.

## Revision 11 — current H04 authority

DRAFT. The user removed mandatory full H04 in current Codex. [h04-adapter-boundaries.md](h04-adapter-boundaries.md), h04-adapter-profile-cases.json and manifest revision11 control adapter-specific acceptance for all12. Every accepted profile requires both applicable capability/limitation evidence and exact-profile ALK resolver refusal proof. FULL_FINANCIAL remains strict but optional per supported profile. Earlier conflicting H04 statements below are historical; other release gates and original evidence remain unchanged. Independent specification review permits migration only; full-plan review, implementation and runtime qualification remain pending.


Revision 9, DRAFT; source v2.15.0. This release strengthens the path from required
evidence to task/final acceptance. One unrelated file must not close many evidence
IDs, and a malformed or self-attested report must not gain a stronger guarantee.

## Architecture and ownership

WS216-01 owns the expected descriptor in existing acceptance.evidence[].validation,
typed receipt/schema convergence and actual task/final audit validation. It adds
the narrow manifest validation integration needed to keep expectations independent
of supplied receipts. WS216-02 integrates reviewer provenance and raw import using
those contracts. WS216-03 publishes compatible documentation and version consumers.
The DAG is serial; no shared file is assigned concurrently to two workers.

Reuse audit/implementation.py, contracts/implementation_audit_validation.py,
workflow/implementation_audit_gate.py, planning/manifest_contract.py, the schema
registry and review_mesh/results.py. Existing source/task freshness and 2.15
filesystem/output protection remain in force. A module path explicitly declared
as new is not a claim it exists in the predecessor.

## Delivery order

1. Verify the accepted predecessor identity; the local source tree matches it.
2. Confirm the completed contract/version and budget-fit design decisions in the
   prepared revision38 candidate; record exact manifest/file/source identities and
   its read-only preview before independent review.
3. Perform bounded independent specification and full S2 plan review. A structural
   PASS and the previous revision's reports do not approve this candidate.
4. Create/verify the reviewed lock using native APIs, compile outside the frozen
   plan, initialize/adopt and obtain valid native execution authorization.
5. Implement WS216-01 under pinned predecessor P; activate verified candidate C1
   before its implementation audit and acceptance as specified in README. Continue
   WS216-02/C2 and WS216-03/C3 with source-bound task audits;
   collect full candidate regression/security/quality and Windows/Linux/macOS proof.
6. Complete the independent final audit before release promotion/publication.

## Risks and measurable outcome

The key risks are choosing expected contracts from untrusted receipts, losing
findings during normalization, overstating attestation, mismatching source/build
or oracle identities, and unowned changes at shared validation consumers. Negative
fixtures must exercise real accepting routes. Schema completeness is not semantic
proof of an arbitrary test oracle or a producer's external truth.

Reduce manual investigation by producing precise stable errors. No percentage
time/token saving is promised. Record actual source-native costs or UNAVAILABLE;
an estimated packet size is not actual full host input. Exact guarantee/version
migration is required before stronger validation becomes authoritative.

Revision 7 pins typed descriptor/envelope/payload limits and raw/v2 compatibility in README. The external attestation verifier boundary, full consumer review and native implementation budget fit remain explicit pre-freeze blockers; this is still a DRAFT.

R6 proposes reviewer-specific signed claims over existing Ed25519, with a pinned public issuer root, exact actor/session/assignment/subject, expiry and idempotent retries. Trust-context qualification remains a pre-freeze requirement; no production issuer is fabricated.

Revision 7 makes the native limitation explicit: ALK can validate the proposed signed contract under a separately controlled caller, but current native callers cannot claim ATTESTED. The plan specifies native failure behavior, exact phase translation and ordered ownership. Independent review must approve this limitation before freeze; test keys do not establish a production issuer.

Revision 8 separates required validation commands by the existing serial owners and EV descriptor digests, preserving every final release gate. It aligns provenance acceptance with TEST_AUTHORITY-only pure-verifier success and native ATTESTED UNSUPPORTED. R7 review remains CHANGES_REQUIRED with incomplete coverage; the two draft corrections require independent verification. Runtime bootstrap, freeze binding and native budget fit remain open.

Revision 9 specifies the exact predecessor/candidate runtime activation boundary
and the existing native candidate/report/lock binding recipe. These are operational
contracts pending independent verification; no runtime was activated and no report,
lock, native state or product implementation was created in this correction.


## Revision-10 controlling accounting/recovery amendment

Revision10 is DRAFT. release-prerequisites.md and the manifest define the added minimal accounting/recovery scope, serial ownership, prospective token ceilings and unresolved prerequisites. accounting-and-recovery-cases.json retains original H04 AC01–AC13 and CF CC01–CC16. All earlier unchanged-scope/cap statements apply to their historical revisions; original acceptance, command, quality/security and publication gates remain. This amendment is not an accepting review, implementation proof, freeze or native authorization.

## r69l R11 PRE bootstrap successor (DRAFT)

For the current prospective PRE bootstrap, `r69l-r11-bootstrap-delta.md`, the r69l route/manifest, v9/v4 oracles and v5 schemas supersede earlier r69j/r69k one-turn, six-path, 70-path and v4-only PRE wording. Earlier text remains historical for its pinned revision and for unchanged task/release gates. The installed r69k lock remains authority until a separate full DRAFT/FROZEN S2, exact report, canonical lock and controlled transfer. The r362 FAIL remains open; no product/native/release PASS is inferred.
