# Revision 13 — per-adapter accounting and recovery integration

## Revision69b corrected DRAFT — exact limited native qualification

The active current-Codex profile and all three 16k workstream selectors use `ALK_CONTROLLED_OUTBOUND_INPUT_FIT` only. The retained config artifact binds credential-free ALK-controlled source bytes/SHA; Codex internal effective-config equality remains `UNPROVEN` for this claim. `route-bootstrap-contract.json#validation.limitedNativeMatrix` is the executable 24-row, six-role evidence contract: a separately admitted maximum of six selected Codex positive calls, 12 predispatch refusals without a model and six controlled local started-failure fixtures. Each row binds role, polarity, command template, producer, oracle, run/task/attempt/claim/lock and receipt path. Local fault rows cannot count as selected Codex native positive; original strong IF09/IF12 remain `NOT_RUN` for this limited profile. The exact r69b preview and review/lock are still pending; r68e remains installed authority and native WS01 is `DENY`.

## Revision69 current DRAFT — current-Codex limited outbound proof

This isolated plan candidate has parent r68e verified lock SHA `a619308da56efc1fe0c23a65de9b8c04074e79e93d7247f02958b5a831af6c66` and accepted S2 specification SHA `c69a24fa6170ba4a509048c2d4cf218f970f793431bc2cce6e08ce8687dec018`. It is not reviewed or locked. All historical revision paragraphs below describe their then-current states; the r69 rules in `route-bootstrap-contract.json#limitedFitApplicability` and `alk-input-fit-contract.json#r69FitDisposition` govern this candidate. r68e remains installed authority; native WS01 DENY, Release NOT_READY.

The proposed current-Codex positive claim covers only ALK-constructed bytes accepted by the OS stdin pipe associated with the selected child, not model-visible input or child consumption. Per-role fresh diagnostic and catalog are prelaunch candidates, not future native equivalence. Strong host-fit/financial requests refuse before dispatch. After observed Popen, only complete same-attempt pipe write/close plus joined native success/usage can pass the new limited case; failure retains unknown cost. Original strong IF09/IF12 remain NOT_RUN for this limited profile. All other accounting, H05/A5, 12-adapter, privacy, 30-day cleanup, hourly scheduler, security/platform/publication and final-audit gates remain.


## Revision68b exact correction of r179 findings

The reviewer-authored `reviewer-body.json` is the exact completed App Server review text, closed schema and raw UTF-8 SHA. It cannot contain its own SHA or a later server read. After completed item/turn and `thread/read`, the ALK collector writes `independent-audit.json` with server IDs, exact raw-body SHA and canonical stable item-projection SHA; first-native admission reopens the item and verifies both, then the lead's later SHA join. Actor strings alone never qualify. Both artifacts and the selected-host positive IF09/IF12 remain `NOT_RUN` until separately admitted live qualification.

The active first-native authority is the exact reviewed r68 successor lock; r67b appears only as the locked parent. Prestart C34/C35 prove RB11-PRE only. Started raw request, diagnostic and credential-free effective config source are sealed in an immutable private inventory with a hash-only pending marker before possible start and handed to WS01's durable per-run obligation. Only credential-only ephemeral CODEX_HOME material may be removed at child exit; the retained config source and other started raw wait until authoritative full closure plus 30 days. Missing source equality or safe credential split refuses before start.

`route-bootstrap-contract.json#validation.phaseEvidenceMap` is the one-to-one binding for five WS01 journal, three WS02 CLI and three WS03 target case IDs to owner AC, EV, exact command digest and receipt path. Each phase has a separately admitted finite budget; these are subsets of existing task allocations, not extra prestart C34/C35 slots. WS03 owns `tests/operations/test_retention_maintenance_target.py` and the operation document; its static command executes against the selected release target's actual installed scheduler and ALK command, recording scheduler identity/cadence, journal/root/authority SHA and real no-due/due/overdue outcomes. Local mock or unqualified platform deletion cannot close combined RB11 or retention release readiness.

## Revision68 current draft: source-bound RB11 and maintenance handoff

This is the exact r68 draft successor to the reviewed r176 specification SHA `b4a00c69751e67bfc81c277d38e0f2904c7f862ef461bdc596feb4019a1dc413` and current r67b lock SHA `56766d2d39988723484ce412523bbb34ab6ac6ae31f9e5deae1c96a779b6e561`. r67b remains operative until a separately accepted full S2 review, matching report and canonical r68 lock. No present product test or native/model result transfers to newly added cases.

Pre-WS01 lead owns only the six unchanged bootstrap paths; C34/C35 and independent audit cover RB01–RB12-PRE, with RB11-PRE limited to pure fully-closed eligibility/refusal. RB11-RUNTIME is `NOT_RUN` at that audit. WS01 owns journal/finalization/private authority and durable raw cleanup after SQL collection; WS02 owns the existing lifecycle CLI and new maintenance test; WS03 owns the operational document and installed hourly target schedule. Combined RB11 `PASS` is final-release-only after all three runtime owners and a supported-platform target probe. The old two-command prestart limit does not consume poststart commands.

The maintenance command uses a pinned private authority SHA and accepts no independent journal/root override. Started raw details delete only after authoritative full financial closure plus 30 days; unresolved runs have no purge clock. An immutable raw inventory and per-run pending obligation survive SQL collection and partial/crash unlink, with hash-only totals/dedup/closure state retained. The journal write-admission boundary covers fresh closure, due and financial-exception checks through bounded unlink and obligation result. Windows/macOS/Linux targets prove equivalent private path, identity and race-safe deletion behavior or refuse before unlink, retain PENDING/OVERDUE and block retention readiness. Same-user Codex does not gain a protected-close claim.

The independent bootstrap review uses a separately admitted local Codex App Server candidate, distinct review thread, completed item/turn, raw-text SHA and live `thread/read` verification. Documentation and installed schema are only interface candidates; runtime qualification is `NOT_RUN`. Selected-host positive IF09/IF12, all12 adapters, H04/H05/A5, numeric, security/platform/publication and final independent audit remain required. The current Codex claim is only `ALK_CONTROLLED_INPUT_FIT`; full host input/U/FULL_FINANCIAL and protected close remain unavailable. Missing native or review proof denies launch, and missing retention target proof blocks release.

## Revision67 review and lock prerequisite

The r66b DRAFT verdict does not approve r67 FROZEN bytes. Require separate independent full S2 acceptance, matching report installation and canonical lock verification before ALK bootstrap/native preflight. H04/H05/A5/all12, protected Choice B, platform/security/publication and final gates remain.

## Revision66 independently proved bootstrap gate

Before WS216-01 native admission, verify an independently produced bootstrap audit `PASS` under the exact reviewed r66 lock and finite admission, six before/after product/test SHAs, whole-WIP inventory digest, C34/C35 output/case digests, private support receipts and held-cost status. Reopen the independent result and compare its SHA/subject to the lead receipt; reviewer actor/session must differ from lead, with independent provenance. Then run the fresh selected-host/task-bound preflight. The corrected 16k state is local r66 preview PASS only; native scoped proof remains pending. r64 remains locked authority and WS216-01 native remains DENY until this chain is complete.


## Revision65 DRAFT pre-WS216-01 start prerequisite

r64 is locked but cannot currently admit its first WS216-01 native launch on the selected Codex route. Before that launch, r65 requires its own independent full S2 review and verified lock, a separately admitted/audited lead ALK bootstrap on six exact paths, C34/C35 bounded local negatives, sealed private request and two-phase start/input receipts, then a fresh selected-host/task-bound exact prompt, config, transport and output-reserve preflight. `route-bootstrap-contract.json` is normative for the 300,000-token pre-run coordinator cap and unknown-hold opening. No bootstrap test substitutes for native IF09–IF12, H04 hard enforcement, WS216-02 acceptance or other release gate. Until these are proved, WS216-01 native admission remains DENY.


## Revision64 reviewed-lock and limited route boundary

r64 may become execution authority only after independent full S2 acceptance of its exact FROZEN-shaped bytes, matching machine report installation and canonical lock creation/verification. The r63 DRAFT verdict alone cannot freeze r64. Its current Codex claim is only ALK_CONTROLLED_INPUT_FIT after task-bound qualification; 4k/8k and stronger complete-host/FULL_FINANCIAL requests refuse. H04/H05/A5/all12, protected Choice B, platform/security/publication and final gates remain.

## Revision61 current-Codex route prerequisites

The shipped Codex 0.147.0 static managed profile cannot qualify the selected 0.156.1 exact-prompt route. Only a distinct independently reviewed/locked ALK route with prelaunch stdin/config proof and IF09–IF12 native evidence may claim limited fit. Full host input/U, H04/H05/A5/all12 and remaining security/platform/publication/final gates stay open.

## Revision60 exact freeze and limited Codex route boundary

r60 may become execution authority only after independent full S2 acceptance of its exact FROZEN-shaped bytes, installation of the matching machine report, and canonical lock creation/verification. r59 DRAFT approval alone cannot freeze r60. For current Codex the active `r60FitDisposition` governs only scoped ALK input fit; complete-host fit/hard financial/FULL_FINANCIAL still refuse without full host/U proof. 4k/8k refusal, native packet/route proof, IF01–IF12, protected Choice B refusal, H04/H05/A5/all12 adapters and all other release gates remain. Until adoption r57 native16k remains DENY and Release 2.16 NOT_READY.

## Revision59 scoped current-Codex fit precedence

For a current-Codex `ALK_CONTROLLED_INPUT_FIT` request, the live r59 manifest context-limit rule and `r59FitDisposition` replace earlier complete-host-input prerequisites only for this narrower claim. An exact reviewed lock, selected host/version/config, public packet and ALK component/limit receipt, fresh diagnostic inventory, declared output reserve and native positive/refusal proof remain mandatory. Host-owned complete input and whole-call U stay UNAVAILABLE; complete-host 16k fit, hard financial and FULL_FINANCIAL requests refuse until their stronger proof exists. The revision28–58 route paragraphs below are historical where they demand complete host input for this r59 limited claim; all 4k/8k refusals, numeric caps, native and other release gates remain. IF04 uses the exact ordered 17-entry source index. r59 is DRAFT, not adopted; locked r57 still denies native16k.

## Revision58 limited Codex input-fit release boundary

r58 is an unreviewed DRAFT and cannot replace r57 until exact full S2 acceptance, distinct FROZEN lock, updated native packet comparison and task-bound profile proof. A qualified current-Codex route may claim only `ALK_CONTROLLED_INPUT_FIT`; complete-host 16k fit and FULL_FINANCIAL requests must refuse, and release disclosure must name this limit. IF09–IF12 join all retained IF/financial/host oracles. No H04/H05/A5/all12 adapter, Choice-B protected refusal, workflow-store, platform/security/publication or final-audit gate is waived. Until r58 adoption the locked r57 native16k DENY remains in force.

## Revision57 exact freeze boundary

r57 may become execution authority only if its exact independent full S2 review returns READY_TO_FREEZE, the machine report matches its FROZEN manifest digest, and the canonical plan lock is created and verified. r56 review alone is insufficient. Native protected use still requires a qualified route; current Codex must refuse protected adoption/closing while ordinary v5 financial work and late settlement continue. All existing gates remain.

## Revision56 case-binding gate

r56 needs exact independent full S2 acceptance and a separate verified lock. EV216-WORKFLOW-STORE must require and later observe DS24–DS27 along with the prior 18 local DS IDs; WR07 positive/native proof is conditional on a qualified route. Current Codex protected adoption/closing must refuse; all retained H04/H05/A5/adapter/security/platform/publication/final gates remain.

## Revision55 storage gate

r55 may govern execution only after exact independent full S2 acceptance and a distinct verified lock. DS24–DS27 local tests and v5 current-Codex ordinary/late-settlement continuity are mandatory; WR07 positive/native proof remains conditional on qualified operator capability. Current Codex protected adoption/closing must refuse. No H04/H05/A5/12-adapter, security, platform, publication or final-audit gate is waived.


## Revision54 correction candidate — independent full S2 review pending

r54 may freeze only after independent full S2 acceptance of the four corrected design joins. A source-bound preview can establish a conditional refusal at freeze: 4k/8k deny, 16k denies until actual host/version input and reserve fit are observed before native launch. Unknown whole-call U remains UNAVAILABLE and H04 independently open. Current Codex protected closing denies; all r52 unrelated gates remain.


## Revision53 draft gate delta

A new r53 plan cannot govern execution until full independent S2 review and a distinct verified lock. Its six local WR01–WR06 cases join retained Choice B local evidence; the four-class write inventory must be complete before freeze. WR07–WR12 and original positive CC/DS/DA/DR/DD cases remain `NOT_RUN` until a qualified operator route exists and passes them before enablement. Current Codex protected adoption/closing must natively refuse; ordinary guarded work and late settlement remain required. All r52 unrelated release gates remain open.


## Revision52 prepared FROZEN-shape candidate — Choice B current-Codex capability-scoped closing

The user selected Choice B. On the current full-access Codex route ALK must refuse protected adoption, root/epoch-0 publication, closing activation/grant and protected dispatch before write or process start. Positive CC04–CC16, DS14, DA15 and joined DS/DA/DR/DD cases remain NOT_RUN/UNPROVEN under their original IDs; distinct OR01–OR19 native negatives and independently reviewed applicability are required for a limited release. All 53 retained WS01 local cases, CC01–CC03, late settlement, H04/H05, A5 for all12 adapters, platform/security/publication and numeric caps remain mandatory. A qualified future route must pass the original positive native cases before enabling protected closing. This prepared candidate has no accepting review, lock, native proof, task acceptance or release permission; r48 remains current.


## Revision31 — pre-run input-fit refusal

The mandatory WS216-02 input-fit consumer is the existing `launch_preflight.py` `managedTask` pre-run gate reached through `unified_start.py`, including direct local-profile calls that bypass continuation. IF05/IF07 require `hostLaunchStarted=false` for missing/wrong/over-limit receipt. `planningTask` is explicitly limited outside Release 2.16 task/run fit and refuses stronger requests before process start under IF08. Independent delta review and later actual tests are required; no host adapter changes or extra budget are authorized by this statement.

## Revision30 — ALK-controlled fit contract

The pinned `alk-input-fit-contract.json` defines mandatory exact selection of the 17 revision60 index-only context refs, bounded future worker/validator/auditor/retry/coordinator/closing components, source/host/candidate identity, and overflow/refusal. WS216-01 owns pure selection and IF01–IF04; WS216-02 owns every relevant ALK dispatch/consumer join and IF05–IF08. C18/C20 remain the planned command routes. Before accepting review, measure exact candidate examples and conservative allowed maxima for all six roles; after implementation, execute every positive/negative case and qualify the exact host route. Unknown host-owned input or U remains UNAVAILABLE and cannot confer FULL_FINANCIAL. No task/run cap, H05 gate or post-lock/native/release proof is waived.

## Revision28 — context-route prerequisite

Do not dispatch the current unsplit WS216-01/02 on 4k-strict or default 8k. The saved r27 source-derived projection fails those local checks; 16k is only a conditional candidate. Before accepting a route, prove that the exact existing host/version supports its selected window and that exact candidate components, reserved output and native/host limits fit. If unavailable, refuse and revise/split under independent review. The exact revision52 preview fails WS216-03 on 4k/8k, so both routes refuse this candidate; the earlier r27 smaller-window PASS was a different input. Local 16k remains conditional on exact host/native fit. Preserve H04/H05, reported-token and all release gates; see pinned prefreeze-fit-contract.md.

## Revision26 — evidence stage clarification

Before independent plan acceptance, require source-backed host capability and ALK admission/refusal design plus H05 design traceability. Actual ALK admission/refusal, authoritative usage/reconciliation and H05 executed source/test proof follow implementation before profile/release acceptance. See prefreeze-fit-contract.md; no gate is waived.

## Revision25 — staged fit measurement

The pinned prefreeze-fit-contract.md governs DRAFT candidate measurements, reviewed-lock/native byte comparison and later host usage qualification. It does not waive H04/H05, A5, non-token limits or final proof. Current packet projection is only candidate-side evidence; actual host input and enforceable U remain UNPROVEN.

## Revision23 — concrete A5 limited implementation candidate

`cf01-a5-implementation-contract.json` now defines the proposed closed records,
frozen policy/state/adoption join, ordinary planning request binding, exact ALK
launch/refusal and consumer hooks, all12 saved expectation targets, exact owners
and 12 future oracle groups. Status: DRAFT_REQUIRES_INDEPENDENT_DELTA_REVIEW.
The accepted r22 capability policy and r19-r21 authority/storage/resource/deadline
semantics remain unchanged. This amendment supersedes only their unresolved A5
integration placeholders; it does not claim full-plan acceptance or runtime proof.

Ordinary standalone context binds the actual explicit operation/input; it is not
a bearer authorization and needs no invented authority file or workflow attempt.
Frozen workflow requirements remain independently authoritative. Accepted attempts
retain original A5 classification/evidence/cost and use a separate adoption binding.
No strong-positive v1 variant exists. Every proposed strong request refuses.

R216-IMMUTABLE-INPUT maps to AC216-A5-SCHEMA / WS216-01 / EV216-SCHEMA and existing
AC216-A5-CAPABILITY / WS216-02 / EV216-CLOSING-WINDOW. All six r22 policy categories
are covered by A501-A512 in the contract. Future commands are declared in the
manifest, NOT_RUN. H05, measured packet/native-budget fit, independent delta and
whole-candidate review/freeze, implementation and actual all12/platform/final
qualification remain open. Existing caps are retained, never presumed sufficient.


## Revision22 — A5 according to existing host capabilities

User-approved scope: strong A5 is enabled only for an existing route with proven
continuous input protection. Other routes refuse that mode and may meet release
acceptance with a reviewed limitation plus actual source-bound refusal proof.
The positive A5 invariant is unchanged; no endpoint-hash fallback, silent downgrade
or immutable-input/write-scope exemption is allowed on a limited route. Ordinary
source/result/ownership/audit and independently required security/validity checks
remain mandatory; any operation requiring unavailable protection remains refused.

`cf01-a5-capability-scope.json` is the normative applicability authority for all12
adapter routes. Older unconditional A5 prerequisite statements below apply to the
STRONG_A5 branch; limited routes instead require a complete refusal integration
contract before freeze and actual route/consumer qualification before release.
H04 support does not establish A5 support. Unknown remains UNPROVEN, not PASS.
The accepted r19/r20/r21 design is retained. This r22 amendment needs scoped
independent review; full candidate readiness, H05, actual fit and all implementation,
storage/platform/final release gates remain open. Historical revision narratives
below are retained as history and do not override this current applicability rule.

## Revision18 — D-DEADLINE configured consumers and current time

cf-d-deadline-contract.json joins the four closing-window design contracts. Actual
runtime gate input is per-task controllerGates and its producer/phase configuration,
not securityGates prose. Only an independently declared compatible execution-only
predicate may consume signed closing permission; run/attempt wall budgets, evidence
freshness, lease/grace/I-O and opaque custom gates retain their original bounds.

The supplied historical receipt identifies project planning/immutable-gate.py and
its execution-deadline failure. Its old FAIL is preserved; historical script source
semantics/current runtime qualification remain unproven. No gate was rerun or
project script/host patched. New contract templates are reviewable before freeze;
actual compiled registry/source/clock identities must be qualified after implementation.

New workflow timestamps use canonical UTC microseconds. D-AUTH and D-DEADLINE share
the same fresh final decision observation; replay/projection never renews time.
Late useful results and all actual costs remain recordable, with reuse classified
separately from permission. Final-audit acceptance or a prepared proof file alone
cannot bypass finalization gates or commit COMPLETE after an invalid decision.

16NOT_RUN cases contribute8WS01 rule/clock-storage and8WS02 consumer/integration witnesses.
Seven exact ownership paths and two planned validation groups retain old owners and
native caps. The joined DRAFT needs independent review, then implementation/native
proof. CF01-A5/H05/actual fit/all12adapter/storage/platform/final gates remain open.

## Revision17 — D-RESOURCE prospective policy and current claim

cf-d-resource-contract.json defines the minimal ACCOUNTING_REPORTED_TOKENS_V1
policy effect in the existing journal, joined with D-STATE and D-AUTH. Signed
additional allowance A yields cumulative ceiling C=S+A at the exact signed anchor.
It never adds unused old allowance. Task/run/window constraints evaluate one charge;
old costs, caps, reserves, protection and violations remain. Source bound failure
or unknown opening cannot be repaired by raising a budget.

Activation records policy/window/nonce together. Reservation and once-claim both
validate current resource and authority state; claim includes the already reserved
U once. Each closeout transfer/refund stays with its original owner/window. A new
signed window may retire an earlier entitlement but cannot roll over unused A,
claim an old unclaimed permit or reset spend. Legacy billableTokens/invocations/
wallSeconds remain distinct unchanged guards; unsupported extension is unavailable.

20NOT_RUN cases contribute16WS01 resource witnesses and4WS02 integration witnesses.
Five exact ownership paths and two validation groups are added within unchanged
native ceilings. These are author design contracts, not implementation or evidence
of native enforcement. Configured D-DEADLINE consumers and their exact guard state
must be bound next, then the combined design needs independent review. CF01-A5,
H05/actual fit, all12adapter qualification and final release gates remain open.

## Revision16 — D-AUTH issuer, revocation and commit contract

cf-d-auth-contract.json defines an independently pinned operator root, a signed
per-run issuer snapshot and a separately signed closing grant. It reuses ALK's
Ed25519 implementation through a planned contracts extraction with compatibility
exports. A name, receipt hash, external pathname or TEST_AUTHORITY is insufficient
owner proof. Native bootstrap qualification remains required as DA15.

The existing SQLite writer transaction orders authority publication, nonce use,
workflow activation and financial claim. A revocation takes effect when its signed
snapshot commits locally. A prior committed claim is in flight and cannot be
promised cancelled by this protocol. Current authority/time and financial state
are rechecked at claim; historical replay cannot issue a new permit. Expiry during
projection or commit does not extend permission or cause checks to restart.

Sixteen NOT_RUN cases contribute12WS01 authority/storage witnesses and4WS02
integration/native witnesses. Eight additional exact ownership paths and two
planned validation groups preserve all previous owners, cases and finite ceilings.
This is a concrete design candidate, not implementation or independent acceptance.
D-RESOURCE must close the exact approval-policy schema/transaction/claim join next;
configured D-DEADLINE, CF01-A5, H05/actual fit and final review remain open.
Only ALK is changed by the planned implementation; all12adapter capability limits,
FULL_FINANCIAL semantics and30-day financially-closed detail retention are retained.

## Revision15 — D-STATE transaction and recovery contract

cf-d-state-contract.json selects one authoritative SQLite transaction for workflow
state/event/result, closing window, nonce use and qualified prospective policy.
JSON state/event files become derived, generation-bound projections. Existing
Journal transaction/version/writer admission is a primitive to extend, not proof
that this workflow feature already exists. A typed WS01 WorkflowStore port owns
storage/adoption/replay/publication; WS02 integrates state/kernel/events and every
permission consumer. No new database, JSONL authority implementation or benchmark
is introduced by this plan. Four exact paths and one planned command are added.

An operation committed before a lost reply returns the same durable semantic
result on replay. Pending/mismatched projection denies new dispatch. A claimed or
uncertain model invocation never restarts during storage recovery. Late expenses
remain recordable without renewing authority. Trusted JOURNAL_REQUIRED binding
prevents fallback to old JSON or a new empty accounting scope. Adoption requires
qualified legacy observation, known quiescent writers and preserved history.

The22 NOT_RUN cases separate18WS01 storage witnesses from4WS02 integration cases.
D-STATE is a concrete DRAFT design, not independently accepted or implemented.
D-AUTH commit-bound verification, D-RESOURCE same-transaction policy port, configured
D-DEADLINE consumers, CF01-A5, H05/actual fit and final candidate review remain open.
FULL_FINANCIAL limitations and30-day financially-closed retention remain unchanged.

## Revision14 — CF01/CF02 exact integration map

cf-integration-map.json is the current source/owner/oracle authority for this
integration. Fourteen rows separate source-read facts, reused accepted core proof,
declarations and proposed interfaces. Thirteen exact paths are added to the serial
WS01/WS02 ownership; no directory wildcard or product edit is authorized by DRAFT.
WS01 provides a pure closing-policy/state/finalization seam before WS02 native
activation. Direct CLI, Python and continuation routes must converge on the same
authoritative action/time/resource guard; ordinary task work cannot bypass it.

S2-R11-P01 is PARTIALLY_ADDRESSED, not closed. Existing neutrality signature code
is a domain-specific primitive, not a workflow owner grant. Kernel event append
and state replacement are separate; neither this nor accounting SQLite proves an
atomic activation/nonce/policy transition. The exact authority route, all-writer
transaction/recovery interface, configured execution-deadline/watchdog producers
and prospective resource policy API remain prefreeze design dependencies.
No literal execution-deadline consumer was found in the bounded repository source
search; dynamic/installed/configured consumers remain unproven, not nonexistent.

Evidence TTL, worker leases, process grace and capture deadlines cannot be extended
by a new execution permission. Expired permission does not discard valid evidence
or prevent late financial settlement; those actions do not grant new paid work.
CF01 A5/G-AUTH/G-OBS/G-TIME/G-CONSUME/G-SCOPE, H05 coverage and measured fit remain
open. No actor, receipt, counter, lock or runtime PASS is manufactured here.

## Revision 13 — pinned expectation inputs and staged runtime identity

All12 expectation templates are now populated in h04-adapter-profile-cases.json:
descriptor/capability hashes, selected versions with provenance, saved official
source snapshots, each documented candidate's ceiling/oracle, role and original
case obligations, and bounded qualification recipes. These are EXPECTED_NOT_OBSERVED
inputs pending independent review; no runtime profile is accepted by this revision.

r12's requirement for actual host executable/configuration hashes before freeze
is replaced by TARGET13 in h04-artifact-contracts.json. Before freeze review the
fixed targets, source hashes and claim/qualification policy. After implementation
bind exact existing runtime identity for every native-positive claim. A reviewed
source-bound limitation may use explicitly null runtime hashes and must reject
all native-positive/financial claims through actual ALK refusal. This grants no
host compatibility or permission to modify/install a host. Every documented
candidate still requires an individual justified disposition; no convenience fallback.

Native experiments require concrete admitted argv/configuration and source-bound
oracles before execution. The12x100000 ordinary planning allocations consume1.2M
of existing WS02 ordinary2M; remaining800000 covers integration/validation. WS02
protected250000 is shared once, not copied per profile. Request/time/tool/evidence
and validation-run fit remain unproven; this allocation changes no native cap.
Retained CF02/CF01 integration design, H05 coverage, actual fit and final independent
review still block freeze. No code/tests/native transition or release approval.

DRAFT, NOT READY TO FREEZE. This is a concrete scope amendment under the user release-completion instruction and advance finite-budget authorization. No independent accepting review, lock or native execution authority exists. Earlier revision-specific unchanged-scope/budget statements are historical; h04-adapter-boundaries.md, h04-adapter-profile-cases.json and manifest revision11 control the changed H04 scope. All original six ACs,45case IDs, commands, supported-platform and quality/security gates remain required.

## Included minimum and deferred work

Release2.16 now includes the minimal cumulative ledger/normalization/opening and mandatory admission integration required by H04, the CF01 final-phase fix and the CF02 closing-only continuation contract. General provider discovery, monetary tariffs, arbitrary multi-host/session services and unrelated2.21 features remain deferred. This is not permission to build a second workflow controller. Keep one durable accounting journal beside existing workflow lineage, with one authoritative owner of each charge. ALK must reject requested guarantees unsupported by the accepted profile before ALK-owned dispatch. A qualified limitation can satisfy that adapter profile; a rejection alone without version/claim/source and resolver proof is insufficient. Full H04 on current Codex is no longer a universal release gate.

The full original H04 and CF source cases are copied verbatim into declared accounting-and-recovery-cases.json. Prefix source IDs as accounting.ac01..ac13 and recovery.cc01..cc16 in receipts. Do not replace original expected outcomes with easier local examples. New core witness IDs are a separate contribution, not substitute acceptance. Producer fixtures contain executable assertions and case mappings, not fabricated passing receipts.

## Ownership and dependency order

WS216-01 owns internal accounting contracts/journal/normalization/opening and their tests/fixture, plus existing shared audit/provenance/finalization schema seams. WS216-02 owns host_bridge and native closing-only integration, remaining workflow consumers and recovery fixture, and retains plan_adoption ownership. WS216-03 retains publication. Exact files are in the manifest/write-set; no concurrent ownership or forward dependency on WS02 from WS01 is allowed.

WS01 must provide versioned finalization/audit seams needed by later CF02 consumption, without turning an inactive new field into a permission bypass. This amendment does not demonstrate that the named write set is transitively complete. Exact dispatcher/watchdog, authorization-policy root, command registration, state schema and deadline consumer mapping remain pre-freeze design obligations. If a missing file is needed, reopen the DRAFT and review its ownership; do not write through an unlisted seam. Search matches alone are not a complete call graph.

Existing plan_adoption/test WIP and untracked accounting files are author inputs, not accepted release tasks. Preserve exact snapshots. Before native execution use an isolated candidate/worktree or equivalent source-bound staging so WS01 cannot accidentally accept undeclared WS02 WIP. Reuse unchanged validated proofs with exact applicability; never erase original working files or historical receipts.

## Accounting contract and safety

Use immutable scope/run/task/attempt/role/operation/dispatch identities. One expense enters run once and at most one task; true run overhead has a reason. runSpent=sum(taskSpent)+overhead only when the inventory is complete. Every profile explicitly marks the coverage of all roles, retries, coordinator and closing reply; FULL_FINANCIAL requires complete coverage. Partial or excluded routes never become complete run totals. Failure/timeout/overrun do not erase charges. Missing actor/history/pending inventory is null/UNAVAILABLE, not0 or empty inventory.

In one journal transaction admit only if every applicable spent+activeReservation+U+protectedCloseout <= cap; claim grants one invocation entitlement. Closeout transfers its own protection into active reservation, never borrows another allocation. Settlement records full authoritative actual once, including excess; unknown dispatch retains reservation. Conflicting/oversized evidence and BOUND_BROKEN/CONFLICT survive recovery or resolution of another operation. No blind redispatch follows crash.

Normalization uses a versioned authoritative unit/source profile: cached input and reasoning already included in totals are not added again; cumulative baselines/epoch/ordered coverage persist atomically with charges. Source-event identity and coverage identity both prevent duplicates. Streaming is evidence-only until authoritative final. Parent/child overlaps, counter resets, unproven first origins or reorder require reconciliation. Opening import binds source/cutoff/covered events and operations; late included receipts do not recharge opening. Pending imports preserve reservation, claim and identity; partial overlap remains unavailable. The reviewed H04-P02 design is supporting evidence, not runtime proof.

A hash/ref or trusted flag supplied by the report is not authority qualification. Before hard financial admission prove the source profile, enforceable U including input/output/reasoning/hidden retries and mandatory boundaries for the claimed scope; FULL_FINANCIAL requires every role. Other accepted profiles must state their exact limitations and reject stronger requested guarantees. Codex local counter observation and absent reviewer telemetry currently do not establish that chain. The bootstrap ledger cannot retrospectively prove prevention during its own implementation. Independent offline core development is a bounded prerequisite contribution; positive native guarantees require actual applicable evidence; a separately qualified narrower limitation may satisfy its profile. Every final profile also requires exact-profile resolver refusal evidence. No loop demands a positive host assessment at any cost.

## CF01 and CF02

CF01: nonempty required tasks all ACCEPTED plus matching valid authorization choose FINAL_AUDIT at run-start; empty/optional-only/incomplete sets do not fabricate completion. Existing task/evidence/attempt/cost bytes and final outcome gates remain.

CF02: a separate versioned owner-authorized receipt binds run/plan/source/evidence subject, expected state revision, policy/owner authority, unique nonce, old blocker, validFrom/expiresAt, closing actions, complete opening/pending inventory and separate finite unit allowances/protection. Verify authority using an independently controlled authorization policy, not a self-declared issuer. Activate once atomically in the same nonterminal compatible run; retain old deadline/receipt/overrun and set closing-only mode. Replayed same operation is idempotent; changed nonce binding or stale concurrent activation rejects.

Allowed work is retained-evidence reconciliation, missing final audit/checks, applicable final outcome and finalize, settlement and closeout. Task-start/rework/arbitrary commands/self-extension remain denied. If new product repair is needed, stop this window and create a separate bounded execution amendment. Current spend S plus newly allowed remainder A produces explicit prospective ceiling S+A, while original ceiling/violation stay visible; cumulative and window limits are intersected, not double-charged. Unknown usage/U does not admit a hard-limit call.

Enumerate every deadline consumer before freeze and classify permission expiry versus non-extendable validity/security/delivery limits. A reviewed prospective permission window cannot override the latter. New-operation expiry must not reject late usage recording/settlement. Reuse unchanged valid proof by source/harness/oracle/environment/policy/TTL bindings; rerun only missing/invalidated/dependency-affected proof with reason/cost. Immutable source/result lineage remains mandatory. CF01 A5 admission and release obligations follow cf01-a5-capability-scope.json: all strong prerequisites remain for STRONG_A5; a limited route requires reviewed refusal integration and later actual proof, without manufacturing a protection producer.

## Prospective finite execution envelope

Old native100000/task300000/run amounts were unproven for the enlarged scope. The latest user preapproval authorizes finite new envelopes, not a retrospective reset. DRAFT native proposal:3000000/task and12000000/run reported tokens; task cap aggregates all attempts/roles. Remaining old limits (attempts3, parallelism1, tool/cycle/time/evidence/context limits) stay unchanged and must independently fit. A tokens increase cannot bypass them.

Planning allocation within run12000000: WS01 ordinary2000000, WS02 ordinary2000000, WS03 ordinary1000000, shared coordinator2000000, protected task closeouts3x250000 plus run closeout250000, conditional retry pool2000000, unallocated2000000. Total12000000; allocations are not extra copies of the run cap. Every retry requires missing/affected work and admission against its remaining task/run/window caps. Proposed amounts are a planning ceiling, NOT measured fit or provider-enforced bounds. Before accepting review, the exact candidate must have a read-only packet/input-component measurement and version-bound documented host U/coverage feasibility or an exact limited-profile refusal design under prefreeze-fit-contract.md; executable ALK admission/refusal and usage proof remain post-implementation gates. Host-owned input or missing receipts remain UNAVAILABLE, not estimates relabelled actual. Reviewed-lock/native packet comparison and runtime usage proof follow review in separate gates. A higher number cannot close H04.

All prior planning/review/development scopes and overruns remain in their ledgers. Define the execution scope and its provenance-bound opening explicitly; do not reinterpret missing old actor costs or compact as zero to make this envelope fit. No unused allowance silently carries forward.

## Proof and current readiness

WS01 core command and WS02 integration command are additional manifest commands; every prior final command remains. H04 full native cases belong to FULL_FINANCIAL profile integration proof, not WS01 synthetic core acceptance. Every profile instead meets the21 explicit profile cases and applicability contract; full claims additionally require all13 original native cases. WS02 also owns CC01–CC16; public/native consumers must exercise positive and negative cases on the exact source. All added cases are NOT_RUN. Windows/Linux/macOS current-candidate proof and publication remain mandatory.

PREFREEZE_CONTRACT milestone: review all12 pinned expectationTemplate inputs under h04-artifact-contracts.json TARGET13; actual runtime identity is required later for native-positive qualification. Resolve exact producer/consumer/owner mapping, H04 candidate-side admission fit and documented host capability/U or limited refusal design under prefreeze-fit-contract.md, branch-specific CF01 A5 prerequisites in cf01-a5-capability-scope.json and H05 independent design coverage. Future owned oracles remain PLANNED/NOT_RUN; executed H05 source/test proof follows implementation. A5_LIMITED does not require inventing a strong interval producer; it does require complete exact refusal/consumer/ownership and qualification design. Prepare the exact matching normative candidate and reserved report output, obtain a real accepting review of those final bytes and create its reviewed lock. Future runtime qualification output is not required before resolver implementation; exact native bytes and actual host usage must be verified after lock/execution.

POST_IMPLEMENTATION_QUALIFICATION milestone: following WS01 core/resolver then WS02 integration, verify each existing target against its frozen identity and execute/reuse the bounded qualification recipes. Accept all12 profile/qualification/exact-profile resolver joins, including applicable positive proof or qualified limitation, before release. Preserve predecessor P→C1→C2→C3 runtime pinning before each applicable acceptance. A target mismatch requires an affected reviewed amendment; no host installation/change or forced full guarantee is implied. All other release gates remain. Missing contracts/design/fit block freeze; missing implementation/profile runtime proof blocks release. No report/lock/state is manufactured here.


## Revision 11 — current H04 authority

DRAFT. The user removed mandatory full H04 in current Codex. [h04-adapter-boundaries.md](h04-adapter-boundaries.md), h04-adapter-profile-cases.json and manifest revision11 control adapter-specific acceptance for all12. Every accepted profile requires both applicable capability/limitation evidence and exact-profile ALK resolver refusal proof. FULL_FINANCIAL remains strict but optional per supported profile. Earlier conflicting H04 statements below are historical; other release gates and original evidence remain unchanged. Independent specification review permits migration only; full-plan review, implementation and runtime qualification remain pending.


## Revision 12 — reviewed findings and current authority

r11 full-plan independent review returned CHANGES_REQUIRED (3 High,4 Medium).
r12 addresses S2-R11-H01/H02/M01/M02 in DRAFT; these are author corrections,
not independently closed findings. h04-artifact-contracts.json defines closed
artifact/request/result types, immutable expectation joins, exact comparison and
refusal rules, bounded producers and qualification milestones. The profile-case
file maps all21 profile oracles and all13 original core/native assertions.
WS01 produces pure resolver proof in its own EV; WS02 produces exact-final-profile
refusal after integration. Expected bindings are pinned templates, not runtime PASS; TARGET13 controls runtime qualification.
Before freeze populate and independently review all12 exact target/source/claim
and recipe expectations. Runtime qualification follows implementation and precedes
release. Existing CF02/CF01 transitive design, H05 independent coverage and actual
packet/budget fit remain open; no lock, execution or release approval exists.
Full H04 on current Codex remains optional; all12 scoped profile acceptance remains
mandatory. Earlier revision text is historical where it conflicts with this block.

## r69l R11 PRE bootstrap successor (DRAFT)

For the current prospective PRE bootstrap, `r69l-r11-bootstrap-delta.md`, the r69l route/manifest, v9/v4 oracles and v5 schemas supersede earlier r69j/r69k one-turn, six-path, 70-path and v4-only PRE wording. Earlier text remains historical for its pinned revision and for unchanged task/release gates. The installed r69k lock remains authority until a separate full DRAFT/FROZEN S2, exact report, canonical lock and controlled transfer. The r362 FAIL remains open; no product/native/release PASS is inferred.
