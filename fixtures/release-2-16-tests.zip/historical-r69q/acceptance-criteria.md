> **Current r69q exact FROZEN role-delivery candidate.** Current delivery authority is r69q-role-delivery-delta.md and r69q-role-contract.json. Superseded v4/v5 delivery/count/budget/roster/status passages below are historical ONLY for that enumerated delta; all unchanged product/ownership/security/native/release requirements remain mandatory. Exact DRAFT/FROZEN review and canonical lock required before transfer; installed r69p remains authority. C34 candidate96/C35=16; no implementation or host proof. WS216-01 DENY; Release NOT_READY. r413 exact r69q DRAFT accepted fullReview=true READY_TO_FREEZE, report SHA 4770d7fc3ecd16b5d2da2609ca3635ec2cdfce71eae066541643d24c00b9797d. Exact FROZEN shape requires its matching independent report, canonical lock and verified transfer; implementation/host/native/release proof not granted by plan status.

> **r69k R10 FROZEN shape pending exact review.** r352 independently accepted the corrected 50-file DRAFT subject (body SHA `93cecf316b40a6564bf877bb5f3d253544f6c0576116c78a05b49088013e8079`) with fullReview=true and no findings. This candidate changes only status, review metadata and top historical notices; the FROZEN-shape report and canonical lock are absent. The verified installed r69j parent lock `c96f464a845c7e69a4fd08af705d55cffb3a4db328cf1eb5a1eef17b9d4d894b` remains authority. Older notices and DRAFT text below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69k R10 isolated DRAFT; independent plan S2 pending.** r348 independently accepted corrected R10 specification SHA `14e5fbba22aa6258ba051abccffec3a0b07b97a9e7174d20491889dbaa43bfda` for plan drafting only. This candidate raises the one-turn request cap to 245760 bytes and binds r69k successor to verified r69j parent. The installed r69j lock `c96f464a845c7e69a4fd08af705d55cffb3a4db328cf1eb5a1eef17b9d4d894b` remains authority; r69k has no independent plan review or lock. Older notices below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69j R9 FROZEN shape pending exact review.** r333 independently accepted the exact corrected DRAFT subject (raw reviewer body SHA `858e61c9211e114ed3392f1dd8425654857265e573b6a09312e4a6a98dededa2`) and closed R331-S2-M01. This candidate changes only status, review metadata and top historical notices; the FROZEN-shape report and canonical lock are absent. Older notices below are historical. Installed r69i parent lock `721d7e3fa60723d59708efddfe2166347af5abc0981d47153527b00382f0bd67` remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69j R9 isolated DRAFT; independent plan S2 pending.** r329 accepted exact R9 specification SHA `965d2c4c02d4dc80b9538288355294391feb94a0f3bd1e6899c0a3b070bf5d03` for plan drafting only. Candidate v3 support oracle `671ed21d004beedecb80e1785a478e1eb95375a3593df3cd0a731a0151a3b84e` and v8 source oracle `d19e5edb56f4908c949f4239763038915f27798f54e8cdbbc13db6a361f93834` are not installed. Parent r69i verified lock `721d7e3fa60723d59708efddfe2166347af5abc0981d47153527b00382f0bd67` remains installed in execution57. No r69j plan-review report or lock exists; WS216-01 native DENY and Release NOT_READY. Older notices below are historical.

> **r69i R8-R3 FROZEN shape pending exact review.** r301 independently accepted the exact DRAFT subject (raw reviewer body SHA `f96bbe126d9f2dd7bbcf996608a4cbf978d9ff8c39227deab75453878f4ab9fd`). This candidate changes only status, review metadata and top historical notices; its future independent report path is declared but the FROZEN-shape report and canonical lock are absent. Older DRAFT notices below are historical. Installed r69h lock `a1d7a69a05f5887b72165613ebb116bf59f2bf52b59d6f851c66b977c284976c` remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69i R8-R3 isolated DRAFT; independent plan S2 pending.** r299 independently accepted exact R8-R3 specification SHA `bef13eb0608b604ffb88a659abe8b0d940046b52ff5ca2f732eecd48ed924cb7` and source oracle SHA `5f7b3cee3f074ebfbf4129bd4058d38116ef8385be20e6fbcd965158bc07a4fe` for plan drafting only. This candidate overlays the `codex_exact_prompt.py` FULL-source row with typed AST slices and local dependency closure; all other R7/v6 requirements remain. Parent r69h verified lock `a1d7a69a05f5887b72165613ebb116bf59f2bf52b59d6f851c66b977c284976c` stays installed in execution57. This r69i candidate has no plan-review report or lock; WS216-01 native DENY and Release NOT_READY. Older r69h/r69g notices below are historical.

> **r69h R7 FROZEN shape pending exact review.** r288 independently accepted the prior DRAFT subject (raw reviewer body SHA `1a5a331060a81d40e9be6a366856ad4742004567520d91526883485ccd4e6399`). This candidate changes only status, review metadata and overview notices; its future independent report path is declared but the FROZEN-shape report and canonical lock are absent. The older DRAFT notice below is historical. Installed r69g remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69h isolated R7 DRAFT — current delivery authority.** r286 independently accepted R7 specification SHA `b54ebc77c4cc89aed0d809a4d193a15a61e7132a651f6db18f6dc98051732ab1` and oracle v6 SHA `aa25670dc55f6c1fb28ba249b9f24dc6115e470e13e0a6d75166ed2023edb702` for plan drafting only. The copied specification preserves its historical pre-adoption status; this candidate now pins R7/v6. Installed r69g lock `673715e292661c13b6d9c7222434d60b2c0247a54a61d45cf5bd3861c3043a99` remains authoritative. r282's R5/v4 DRAFT review was CHANGES_REQUIRED; this amended DRAFT has no independent plan acceptance or lock. Older delivery notices below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69g FROZEN shape pending exact review.** r254 independently accepted the prior DRAFT subject (raw reviewer body SHA 023d7fd1873d6094ef474f6ddc68e908fc28cc5dbf62e3d0f2891707fbeb58a4). This FROZEN-shaped candidate changes status/review metadata and overview notices only; its report path is declared but the independent FROZEN-shape report and canonical lock are absent. Older DRAFT notices below are historical. Installed r69f remains authoritative; WS216-01 native is DENY.

> **r69g r251 S2 correction.** The closed receipt requires matching second request/response IDs, the exact written request SHA, completed second-turn input item and full ordered two-turn input/output sequence SHA; fresh read must recompute them. Selected-host pre-send context fit includes the larger of completed first-turn total tokens and all first-turn item transcript UTF-8 bytes, plus second-request bytes, 8,192 output and 16,384 safety tokens. Missing input or fit is DENY. The installed r69f lock has no `acceptedSpecSha256` key at any JSON path; exact lock SHA and field witness are in `route-bootstrap-contract.json#parent`.

> **r69g r248 S2 correction.** PASS requires exact `NO_CURRENT_FINDINGS` (optional one newline) and zero findings, including P3. The second request must be the exact saved bytes actually written and correlated with response ID, completed turn/input item, ordered dual-item thread read and fresh reread. Its raw review is capped at 32,768 UTF-8 bytes and serialized request at 65,536; before send, the selected host must report a context window satisfying first-turn max input tokens + request bytes + 8,192 output reserve + 16,384 safety tokens. Unknown/oversize is DENY with preserved evidence. The r242 accepted-spec SHA is the successor binding, not a claim about the installed r69f parent. Runtime qualification remains pending.

> **r69g DRAFT delivery successor.** Installed r69f lock SHA 45a280b5dfc5e83e88d6c1f4d635b9ace7e5d1adaf3f9795a1215288bfe54dd5 remains authoritative. Exact independently READY_TO_DRAFT S2 specification SHA 6e7981627ffa616a7fabba856dca343e6f43c5eeda773d0eb87a572bdc7a0e1a is copied as `review-delivery-spec.md`. The current candidate replaces the reviewer-body producer with a same-thread `turn/start.outputSchema` item after `review/start` text; it requires the clean sentinel, full-subject saved request, dual-item collector/fresh read and unchanged PRE limits. Older r69 review-delivery paragraphs below describe historical candidates and do not override `route-bootstrap-contract.json#auditJoin.delivery`. No native WS216-01 from this DRAFT.

# Acceptance criteria — revision 40 prepared native review candidate

## Revision69b corrected DRAFT — exact limited native qualification

The active current-Codex profile and all three 16k workstream selectors use `ALK_CONTROLLED_OUTBOUND_INPUT_FIT` only. The retained config artifact binds credential-free ALK-controlled source bytes/SHA; Codex internal effective-config equality remains `UNPROVEN` for this claim. `route-bootstrap-contract.json#validation.limitedNativeMatrix` is the executable 24-row, six-role evidence contract: a separately admitted maximum of six selected Codex positive calls, 12 predispatch refusals without a model and six controlled local started-failure fixtures. Each row binds role, polarity, command template, producer, oracle, run/task/attempt/claim/lock and receipt path. Local fault rows cannot count as selected Codex native positive; original strong IF09/IF12 remain `NOT_RUN` for this limited profile. The exact r69b preview and review/lock are still pending; r68e remains installed authority and native WS01 is `DENY`.

## Revision69 current DRAFT — current-Codex limited outbound proof

This isolated plan candidate has parent r68e verified lock SHA `a619308da56efc1fe0c23a65de9b8c04074e79e93d7247f02958b5a831af6c66` and accepted S2 specification SHA `c69a24fa6170ba4a509048c2d4cf218f970f793431bc2cce6e08ce8687dec018`. It is not reviewed or locked. All historical revision paragraphs below describe their then-current states; the r69 rules in `route-bootstrap-contract.json#limitedFitApplicability` and `alk-input-fit-contract.json#r69FitDisposition` govern this candidate. r68e remains installed authority; native WS01 DENY, Release NOT_READY.

The proposed current-Codex positive claim covers only ALK-constructed bytes accepted by the OS stdin pipe associated with the selected child, not model-visible input or child consumption. Per-role fresh diagnostic and catalog are prelaunch candidates, not future native equivalence. Strong host-fit/financial requests refuse before dispatch. After observed Popen, only complete same-attempt pipe write/close plus joined native success/usage can pass the new limited case; failure retains unknown cost. Original strong IF09/IF12 remain NOT_RUN for this limited profile. All other accounting, H05/A5, 12-adapter, privacy, 30-day cleanup, hourly scheduler, security/platform/publication and final-audit gates remain.


## Revision68c exact r181 field correction

`independent-audit.json` is produced by the ALK post-completion collector, while `reviewer-body.json` is the immutable raw App Server reviewer text. Their path, producer, UTF-8 byte rule, hashes, consumer and first-native live re-read agree in the current route and fit contracts; the lead only later links SHAs. `r68FitDisposition.effectiveConfig` names the retained credential-free effective-config.json as the started raw source, independently equal to the child effective config. CODEX_HOME is credential-only ephemeral and excluded from that inventory; failure to separate refuses before start.

C34/C35 and the WS02 task EV use only `RB11-PRE`. Bare `RB11` is a machine final-release aggregate in the WS03 publication EV target-probe receipt after RB11-PRE and every one of the 11 owner-mapped WS01/02/03 runtime case receipts; no local helper or WS02 acceptance can emit combined PASS. The current r67b lock, selected-host IF09/IF12, App Server runtime, target maintenance and all other release gates remain pending.

## Revision68b exact correction of r179 findings

The reviewer-authored `reviewer-body.json` is the exact completed App Server review text, closed schema and raw UTF-8 SHA. It cannot contain its own SHA or a later server read. After completed item/turn and `thread/read`, the ALK collector writes `independent-audit.json` with server IDs, exact raw-body SHA and canonical stable item-projection SHA; first-native admission reopens the item and verifies both, then the lead's later SHA join. Actor strings alone never qualify. Both artifacts and the selected-host positive IF09/IF12 remain `NOT_RUN` until separately admitted live qualification.

The active first-native authority is the exact reviewed r68 successor lock; r67b appears only as the locked parent. Prestart C34/C35 prove RB11-PRE only. Started raw request, diagnostic and credential-free effective config source are sealed in an immutable private inventory with a hash-only pending marker before possible start and handed to WS01's durable per-run obligation. Only credential-only ephemeral CODEX_HOME material may be removed at child exit; the retained config source and other started raw wait until authoritative full closure plus 30 days. Missing source equality or safe credential split refuses before start.

`route-bootstrap-contract.json#validation.phaseEvidenceMap` is the one-to-one binding for five WS01 journal, three WS02 CLI and three WS03 target case IDs to owner AC, EV, exact command digest and receipt path. Each phase has a separately admitted finite budget; these are subsets of existing task allocations, not extra prestart C34/C35 slots. WS03 owns `tests/operations/test_retention_maintenance_target.py` and the operation document; its static command executes against the selected release target's actual installed scheduler and ALK command, recording scheduler identity/cadence, journal/root/authority SHA and real no-due/due/overdue outcomes. Local mock or unqualified platform deletion cannot close combined RB11 or retention release readiness.

## Revision68 current draft: source-bound RB11 and maintenance handoff

This is the exact r68 draft successor to the reviewed r176 specification SHA `b4a00c69751e67bfc81c277d38e0f2904c7f862ef461bdc596feb4019a1dc413` and current r67b lock SHA `56766d2d39988723484ce412523bbb34ab6ac6ae31f9e5deae1c96a779b6e561`. r67b remains operative until a separately accepted full S2 review, matching report and canonical r68 lock. No present product test or native/model result transfers to newly added cases.

Pre-WS01 lead owns only the six unchanged bootstrap paths; C34/C35 and independent audit cover RB01–RB12-PRE, with RB11-PRE limited to pure fully-closed eligibility/refusal. RB11-RUNTIME is `NOT_RUN` at that audit. WS01 owns journal/finalization/private authority and durable raw cleanup after SQL collection; WS02 owns the existing lifecycle CLI and new maintenance test; WS03 owns the operational document and installed hourly target schedule. Combined RB11 `PASS` is final-release-only after all three runtime owners and a supported-platform target probe. The old two-command prestart limit does not consume poststart commands.

The maintenance command uses a pinned private authority SHA and accepts no independent journal/root override. Started raw details delete only after authoritative full financial closure plus 30 days; unresolved runs have no purge clock. An immutable raw inventory and per-run pending obligation survive SQL collection and partial/crash unlink, with hash-only totals/dedup/closure state retained. The journal write-admission boundary covers fresh closure, due and financial-exception checks through bounded unlink and obligation result. Windows/macOS/Linux targets prove equivalent private path, identity and race-safe deletion behavior or refuse before unlink, retain PENDING/OVERDUE and block retention readiness. Same-user Codex does not gain a protected-close claim.

The independent bootstrap review uses a separately admitted local Codex App Server candidate, distinct review thread, completed item/turn, raw-text SHA and live `thread/read` verification. Documentation and installed schema are only interface candidates; runtime qualification is `NOT_RUN`. Selected-host positive IF09/IF12, all12 adapters, H04/H05/A5, numeric, security/platform/publication and final independent audit remain required. The current Codex claim is only `ALK_CONTROLLED_INPUT_FIT`; full host input/U/FULL_FINANCIAL and protected close remain unavailable. Missing native or review proof denies launch, and missing retention target proof blocks release.

## Revision68b current bootstrap acceptance boundary

The first native WS216-01 task requires a reviewed/verified r68 successor lock and separately delivered immutable reviewerBody plus later ALK-verified collector PASS under the r68 lock/admission/changed-byte/WIP/C34-C35/private-support/held-cost subject. Local C34/C35 or lead assertion alone cannot satisfy native IF09-IF12 or release gates.

## Revision66 bootstrap audit and 16k local fit

Before the first WS216-01 native attempt, the independent bootstrap result must be PASS and separately produced by a reviewer whose actor/session differs from the lead; r66 lock, finite admission, six changed-byte SHAs, WIP inventory, C34/C35 cases/output, private support and held-cost status must match the lead receipt by SHA and subject. A lead-only PASS, missing report or stale subject refuses. The active 16k machine disposition is local r66 preview PASS with selected-host/native proof PENDING; 4k/8k still refuse. RB01–RB12 and C34/C35 are NOT_RUN and cannot satisfy native IF09–IF12.


## Revision65 DRAFT bootstrap before IF09–IF12

The lead bootstrap is a reviewed pre-execution prerequisite, never WS216-02 acceptance. Its RB01–RB12 cases and two targeted C34/C35 commands must show explicit direct/unified route/claim/request binding; private 0700/0600 staging, no-start cleanup and 30-day post-close retention; immediate process-start stdin PENDING; later full or failed OS-pipe input receipt; started cost retention and legacy runner compatibility. IF09/IF12 positive still require selected-host task-bound native proof with both actual receipt phases and result/usage. IF10/IF11 no-start require hostLaunchStarted=false and no actual start/input receipt. Unknown cost is retained; complete-host/FULL_FINANCIAL requests refuse. The current r65 draft proves none of these cases. The current public packet index has 18 ordered context refs, adding `route-bootstrap-contract.json`; IF04 and the exact pre-review preview must bind this revision.


## Revision61 IF09–IF12 exact-prompt route

The explicit `codex-exact-prompt-v1` + scoped claim must reach one shared pre-run gate from direct and unified managedTask entries. IF09 needs final canonical component inclusion/caps and transport/config qualification before native task-bound positive; IF10/IF11 require refusal with hostLaunchStarted=false for missing/drift/stronger/legacy fallback; IF12 preserves failed attempt and observed cost without automatic retry.

## Revision58 current-Codex scoped fit acceptance

The user-selected r58 Choice B adds IF09–IF12 to WS216-02/C20/EV216-ACCOUNTING-ENFORCEMENT. Accept only an exact native, version-bound `ALK_CONTROLLED_INPUT_FIT` receipt for all six ALK roles; pin packet, ALK components/caps, fresh same-route prompt inventory, selected host identity and planned output reserve. Wrong/stale/missing data and stronger requests refuse before launch; host rejection/truncation after launch is failure with historical cost retained. Complete host tokens and U remain UNAVAILABLE. Existing IF01–IF08 and all other gates remain NOT_RUN/open.

## Revision56 executable migration-case binding

EV216-WORKFLOW-STORE now requires the four exact `recovery.state.ds24`–`ds27` case IDs in addition to its 18 existing DS IDs; all 22 must be observed by the existing WS216-01 owned command and evidence validator. This closes r55 R55-S2-M01 at plan-design level only. DS24–DS27 remain NOT_RUN, WR07 native positive remains conditional, and current Codex protected closing refuses.

## Revision55 storage continuity cases

AC216-WORKFLOW-STORE includes DS24–DS27 local evidence in the existing WS216-01 `tests.accounting.test_workflow_store`/`test_workflow_store_recovery` validation command: unmigrated v5 ordinary work, full inventory refusal/rollback, migrated v6 financial and D-RESOURCE continuity, and receipt/reopen/old-writer fencing. WR07 positive native migration remains conditional on a qualified route. Current Codex protected closing still denies and retained gates remain.


## Revision54 correction candidate — independent full S2 review pending

The r54 delta extends WR07 with v5→v6 eligible/refused migration and root binding, WR09 with exact B/P stage/crash ordering, WR11 with disjoint same-generation/legacy recovery, and WR12 with directory, mode, temporary and three-route inventory. WR01–WR06 remain required local cases; WR07–WR12 stay conditional/native or prefreeze as labelled. No current Codex protected capability or old gate is waived.


## Revision53 draft acceptance delta

AC216-WORKFLOW-AUTHORITY adds WR01–WR03 and WR06 local shape/signature/AllowedWrites cases; AC216-CLOSING-RESOURCES adds WR04; AC216-DEADLINE-CONTRACT adds WR05. The exact IDs and oracles are in `cf-d-window-request-contract.json` and `plan.manifest.json`. The source-to-operation write inventory, adopted root identity and WR07–WR12 qualified/native cases remain mandatory before a protected route may be enabled. On current Codex, Choice B still requires OR01–OR19 native refusal and all retained r52 gates; a local wire PASS is no substitute. r53 is unreviewed and r52 remains locked.


## Revision31 — actual managed launch witness

IF05/IF07 now require the `managedTask` pre-run gate in `launch_preflight.py` to reject missing, stale or over-limit input-fit receipts before `context.runner`, including direct local-profile calls that bypass continuation. IF08 classifies `planningTask` as a limited non-run route and requires refusal of stronger task/run fit or financial claims before its process starts. Negative tests must observe `hostLaunchStarted=false`; all remain `NOT_RUN`.

## Revision30 — bounded ALK input fit design

The pinned `alk-input-fit-contract.json` adds IF01–IF04 to EV216-ACCOUNTING-CORE and IF05–IF08 to EV216-ACCOUNTING-ENFORCEMENT under their retained commands C18/C20. These planned cases require exact source selection, all six ALK role envelopes, conditional 16k/4k/8k refusal and explicit host-owned exclusions. They are `NOT_RUN`; this is no claim of complete host input, hard financial control or release readiness.


## Revision23 — concrete A5 limited implementation candidate

`cf01-a5-implementation-contract.json` now defines the proposed closed records,
frozen policy/state/adoption join, ordinary planning request binding, exact ALK
launch/refusal and consumer hooks, all12 saved expectation targets, exact owners
and 12 future oracle groups. Status: DRAFT_REQUIRES_INDEPENDENT_DELTA_REVIEW.
The accepted r22 capability policy and r19-r21 authority/storage/resource/deadline
semantics remain unchanged. This amendment supersedes only their unresolved A5
integration placeholders; it does not claim full-plan acceptance or runtime proof.

Ordinary standalone context binds the actual explicit operation/input; it is not
a bearer authorization and needs no invented authority file or workflow attempt.
Frozen workflow requirements remain independently authoritative. Accepted attempts
retain original A5 classification/evidence/cost and use a separate adoption binding.
No strong-positive v1 variant exists. Every proposed strong request refuses.

R216-IMMUTABLE-INPUT maps to AC216-A5-SCHEMA / WS216-01 / EV216-SCHEMA and existing
AC216-A5-CAPABILITY / WS216-02 / EV216-CLOSING-WINDOW. All six r22 policy categories
are covered by A501-A512 in the contract. Future commands are declared in the
manifest, NOT_RUN. H05, measured packet/native-budget fit, independent delta and
whole-candidate review/freeze, implementation and actual all12/platform/final
qualification remain open. Existing caps are retained, never presumed sufficient.


## Revision22 — A5 according to existing host capabilities

User-approved scope: strong A5 is enabled only for an existing route with proven
continuous input protection. Other routes refuse that mode and may meet release
acceptance with a reviewed limitation plus actual source-bound refusal proof.
The positive A5 invariant is unchanged; no endpoint-hash fallback, silent downgrade
or immutable-input/write-scope exemption is allowed on a limited route. Ordinary
source/result/ownership/audit and independently required security/validity checks
remain mandatory; any operation requiring unavailable protection remains refused.

`cf01-a5-capability-scope.json` is the normative applicability authority for all12
adapter routes. Older unconditional A5 prerequisite statements below apply to the
STRONG_A5 branch; limited routes instead require a complete refusal integration
contract before freeze and actual route/consumer qualification before release.
H04 support does not establish A5 support. Unknown remains UNPROVEN, not PASS.
The accepted r19/r20/r21 design is retained. This r22 amendment needs scoped
independent review; full candidate readiness, H05, actual fit and all implementation,
storage/platform/final release gates remain open. Historical revision narratives
below are retained as history and do not override this current applicability rule.

## Revision18 — D-DEADLINE configured consumers and current time

cf-d-deadline-contract.json joins the four closing-window design contracts. Actual
runtime gate input is per-task controllerGates and its producer/phase configuration,
not securityGates prose. Only an independently declared compatible execution-only
predicate may consume signed closing permission; run/attempt wall budgets, evidence
freshness, lease/grace/I-O and opaque custom gates retain their original bounds.

The supplied historical receipt identifies project planning/immutable-gate.py and
its execution-deadline failure. Its old FAIL is preserved; historical script source
semantics/current runtime qualification remain unproven. No gate was rerun or
project script/host patched. New contract templates are reviewable before freeze;
actual compiled registry/source/clock identities must be qualified after implementation.

New workflow timestamps use canonical UTC microseconds. D-AUTH and D-DEADLINE share
the same fresh final decision observation; replay/projection never renews time.
Late useful results and all actual costs remain recordable, with reuse classified
separately from permission. Final-audit acceptance or a prepared proof file alone
cannot bypass finalization gates or commit COMPLETE after an invalid decision.

16NOT_RUN cases contribute8WS01 rule/clock-storage and8WS02 consumer/integration witnesses.
Seven exact ownership paths and two planned validation groups retain old owners and
native caps. The joined DRAFT needs independent review, then implementation/native
proof. CF01-A5/H05/actual fit/all12adapter/storage/platform/final gates remain open.

## Revision17 — D-RESOURCE prospective policy and current claim

cf-d-resource-contract.json defines the minimal ACCOUNTING_REPORTED_TOKENS_V1
policy effect in the existing journal, joined with D-STATE and D-AUTH. Signed
additional allowance A yields cumulative ceiling C=S+A at the exact signed anchor.
It never adds unused old allowance. Task/run/window constraints evaluate one charge;
old costs, caps, reserves, protection and violations remain. Source bound failure
or unknown opening cannot be repaired by raising a budget.

Activation records policy/window/nonce together. Reservation and once-claim both
validate current resource and authority state; claim includes the already reserved
U once. Each closeout transfer/refund stays with its original owner/window. A new
signed window may retire an earlier entitlement but cannot roll over unused A,
claim an old unclaimed permit or reset spend. Legacy billableTokens/invocations/
wallSeconds remain distinct unchanged guards; unsupported extension is unavailable.

20NOT_RUN cases contribute16WS01 resource witnesses and4WS02 integration witnesses.
Five exact ownership paths and two validation groups are added within unchanged
native ceilings. These are author design contracts, not implementation or evidence
of native enforcement. Configured D-DEADLINE consumers and their exact guard state
must be bound next, then the combined design needs independent review. CF01-A5,
H05/actual fit, all12adapter qualification and final release gates remain open.

## Revision16 — D-AUTH issuer, revocation and commit contract

cf-d-auth-contract.json defines an independently pinned operator root, a signed
per-run issuer snapshot and a separately signed closing grant. It reuses ALK's
Ed25519 implementation through a planned contracts extraction with compatibility
exports. A name, receipt hash, external pathname or TEST_AUTHORITY is insufficient
owner proof. Native bootstrap qualification remains required as DA15.

The existing SQLite writer transaction orders authority publication, nonce use,
workflow activation and financial claim. A revocation takes effect when its signed
snapshot commits locally. A prior committed claim is in flight and cannot be
promised cancelled by this protocol. Current authority/time and financial state
are rechecked at claim; historical replay cannot issue a new permit. Expiry during
projection or commit does not extend permission or cause checks to restart.

Sixteen NOT_RUN cases contribute12WS01 authority/storage witnesses and4WS02
integration/native witnesses. Eight additional exact ownership paths and two
planned validation groups preserve all previous owners, cases and finite ceilings.
This is a concrete design candidate, not implementation or independent acceptance.
D-RESOURCE must close the exact approval-policy schema/transaction/claim join next;
configured D-DEADLINE, CF01-A5, H05/actual fit and final review remain open.
Only ALK is changed by the planned implementation; all12adapter capability limits,
FULL_FINANCIAL semantics and30-day financially-closed detail retention are retained.

## Revision15 — D-STATE transaction and recovery contract

cf-d-state-contract.json selects one authoritative SQLite transaction for workflow
state/event/result, closing window, nonce use and qualified prospective policy.
JSON state/event files become derived, generation-bound projections. Existing
Journal transaction/version/writer admission is a primitive to extend, not proof
that this workflow feature already exists. A typed WS01 WorkflowStore port owns
storage/adoption/replay/publication; WS02 integrates state/kernel/events and every
permission consumer. No new database, JSONL authority implementation or benchmark
is introduced by this plan. Four exact paths and one planned command are added.

An operation committed before a lost reply returns the same durable semantic
result on replay. Pending/mismatched projection denies new dispatch. A claimed or
uncertain model invocation never restarts during storage recovery. Late expenses
remain recordable without renewing authority. Trusted JOURNAL_REQUIRED binding
prevents fallback to old JSON or a new empty accounting scope. Adoption requires
qualified legacy observation, known quiescent writers and preserved history.

The22 NOT_RUN cases separate18WS01 storage witnesses from4WS02 integration cases.
D-STATE is a concrete DRAFT design, not independently accepted or implemented.
D-AUTH commit-bound verification, D-RESOURCE same-transaction policy port, configured
D-DEADLINE consumers, CF01-A5, H05/actual fit and final candidate review remain open.
FULL_FINANCIAL limitations and30-day financially-closed retention remain unchanged.

## Revision14 — CF01/CF02 exact integration map

cf-integration-map.json is the current source/owner/oracle authority for this
integration. Fourteen rows separate source-read facts, reused accepted core proof,
declarations and proposed interfaces. Thirteen exact paths are added to the serial
WS01/WS02 ownership; no directory wildcard or product edit is authorized by DRAFT.
WS01 provides a pure closing-policy/state/finalization seam before WS02 native
activation. Direct CLI, Python and continuation routes must converge on the same
authoritative action/time/resource guard; ordinary task work cannot bypass it.

S2-R11-P01 is PARTIALLY_ADDRESSED, not closed. Existing neutrality signature code
is a domain-specific primitive, not a workflow owner grant. Kernel event append
and state replacement are separate; neither this nor accounting SQLite proves an
atomic activation/nonce/policy transition. The exact authority route, all-writer
transaction/recovery interface, configured execution-deadline/watchdog producers
and prospective resource policy API remain prefreeze design dependencies.
No literal execution-deadline consumer was found in the bounded repository source
search; dynamic/installed/configured consumers remain unproven, not nonexistent.

Evidence TTL, worker leases, process grace and capture deadlines cannot be extended
by a new execution permission. Expired permission does not discard valid evidence
or prevent late financial settlement; those actions do not grant new paid work.
CF01 A5/G-AUTH/G-OBS/G-TIME/G-CONSUME/G-SCOPE, H05 coverage and measured fit remain
open. No actor, receipt, counter, lock or runtime PASS is manufactured here.

## Revision 13 — pinned expectation inputs and staged runtime identity

All12 expectation templates are now populated in h04-adapter-profile-cases.json:
descriptor/capability hashes, selected versions with provenance, saved official
source snapshots, each documented candidate's ceiling/oracle, role and original
case obligations, and bounded qualification recipes. These are EXPECTED_NOT_OBSERVED
inputs pending independent review; no runtime profile is accepted by this revision.

r12's requirement for actual host executable/configuration hashes before freeze
is replaced by TARGET13 in h04-artifact-contracts.json. Before freeze review the
fixed targets, source hashes and claim/qualification policy. After implementation
bind exact existing runtime identity for every native-positive claim. A reviewed
source-bound limitation may use explicitly null runtime hashes and must reject
all native-positive/financial claims through actual ALK refusal. This grants no
host compatibility or permission to modify/install a host. Every documented
candidate still requires an individual justified disposition; no convenience fallback.

Native experiments require concrete admitted argv/configuration and source-bound
oracles before execution. The12x100000 ordinary planning allocations consume1.2M
of existing WS02 ordinary2M; remaining800000 covers integration/validation. WS02
protected250000 is shared once, not copied per profile. Request/time/tool/evidence
and validation-run fit remain unproven; this allocation changes no native cap.
Retained CF02/CF01 integration design, H05 coverage, actual fit and final independent
review still block freeze. No code/tests/native transition or release approval.

## Revision 12 — reviewed findings and current authority

r11 full-plan independent review returned CHANGES_REQUIRED (3 High,4 Medium).
r12 addresses S2-R11-H01/H02/M01/M02 in DRAFT; these are author corrections,
not independently closed findings. h04-artifact-contracts.json defines closed
artifact/request/result types, immutable expectation joins, exact comparison and
refusal rules, bounded producers and qualification milestones. The profile-case
file maps all21 profile oracles and all13 original core/native assertions.
WS01 produces pure resolver proof in its own EV; WS02 produces exact-final-profile
refusal after integration. Expected bindings are pinned templates, not runtime PASS; TARGET13 controls runtime qualification.
Before freeze populate and independently review all12 exact target/source/claim
and recipe expectations. Runtime qualification follows implementation and precedes
release. Existing CF02/CF01 transitive design, H05 independent coverage and actual
packet/budget fit remain open; no lock, execution or release approval exists.
Full H04 on current Codex remains optional; all12 scoped profile acceptance remains
mandatory. Earlier revision text is historical where it conflicts with this block.

## Revision 11 — current H04 authority

DRAFT. The user removed mandatory full H04 in current Codex. [h04-adapter-boundaries.md](h04-adapter-boundaries.md), h04-adapter-profile-cases.json and manifest revision11 control adapter-specific acceptance for all12. Every accepted profile requires both applicable capability/limitation evidence and exact-profile ALK resolver refusal proof. FULL_FINANCIAL remains strict but optional per supported profile. Earlier conflicting H04 statements below are historical; other release gates and original evidence remain unchanged. Independent specification review permits migration only; full-plan review, implementation and runtime qualification remain pending.


| ID | Requirement | Evidence | Criterion |
| --- | --- | --- | --- |
| `AC216-SCHEMA` | `R216-SCHEMA` | `EV216-SCHEMA` | Converge implementation/final-audit runtime validation with published schemas through one shared validation source, preserving lineage, bounded inputs and fail-closed verdict semantics. |
| `AC216-BINDING` | `R216-BINDING` | `EV216-BINDING` | Match each required evidence ID to its independently expected typed contract, subject and validated receipt; reject missing, unrelated, duplicate, stale, wrong-source/configuration/oracle or inapplicable evidence. |
| `AC216-RECEIPT` | `R216-RECEIPT` | `EV216-RECEIPT` | Provide a bounded versioned typed evidence envelope with producer, subject, lineage, evidenceId and digest; validate supported payload contracts and observation conditions without promoting raw output or advisory extensions. |
| `AC216-PROVENANCE` | `R216-PROVENANCE` | `EV216-PROVENANCE` | Distinguish DECLARED from ATTESTED reviewer independence; require externally verifiable actor/session/subject provenance for an ATTESTED gate and preserve the existing same-actor or same-session rejection. |
| `AC216-IMPORT` | `R216-IMPORT` | `EV216-IMPORT` | Validate the documented raw reviewer-input contract before normalization, preserve findings and actual command outcomes, reject ambiguous bindings and invalid values, and represent missing usage as unknown without changing quorum eligibility. |
| `AC216-PUBLICATION` | `R216-PUBLICATION` | `EV216-PUBLICATION` | Publish the changed contracts, migration and interpretation limits, synchronize every version consumer, and retain source-bound regression, security, quality and supported-platform proof. |
| `AC216-ACCOUNTING-CORE` | `R216-ACCOUNTING` | `EV216-ACCOUNTING-CORE` | Verify durable atomic identities/reservations, full actual once, sticky blockers, normalization and provenance-bound opening/pending import. |
| `AC216-ACCOUNTING-ENFORCEMENT` | `R216-ACCOUNTING` | `EV216-ACCOUNTING-ENFORCEMENT` | Validate exactly12 adapter profiles against independently expected version/mode/claim/source bindings; accept supported guarantees or qualified limitations only with source-bound qualification AND exact-profile resolver refusal proof. |
| `AC216-FINALIZATION-RECOVERY` | `R216-FINALIZATION-RECOVERY` | `EV216-FINALIZATION-RECOVERY` | Original CC01–CC03 preserve accepted task/evidence/history identities and cumulative costs; required nonempty accepted set enters FINAL_AUDIT through authorized run-start without bypassing final outcome. |
| `AC216-CLOSING-WINDOW` | `R216-CLOSING-WINDOW` | `EV216-CLOSING-WINDOW` | Current Codex must prove OR01–OR19 native protected refusal, reviewed exact-route applicability, zero unauthorized write/dispatch, ordinary/late-settlement preservation and explicit limitation. Shared EV retains A5 cases conjunctively. Original positive CC04–CC16 and joined native DS/DA/DR/DD stay NOT_RUN; qualified routes require their original positive proof. |
| `AC216-CLOSING-POLICY` | `R216-CLOSING-WINDOW` | `EV216-CLOSING-POLICY` | WS01 pure closing-policy/state-contract witnesses reject forbidden actions, malformed active context and implicit authority; preserve deadline categories, historical outcomes and inactive legacy behavior. |
| `AC216-WORKFLOW-STORE` | `R216-CLOSING-WINDOW`, `R216-ACCOUNTING` | `EV216-WORKFLOW-STORE` | All retained D-STATE local cases plus DS23–DS27 must pass, including exact EV216-WORKFLOW-STORE case IDs for DS24–DS27. Current Codex joins native OR02 refusal and applicability in EV216-CLOSING-WINDOW; DS14 positive stays NOT_RUN. Qualified adoption requires original native DS14. |
| `AC216-WORKFLOW-AUTHORITY` | `R216-CLOSING-WINDOW`, `R216-ACCOUNTING` | `EV216-WORKFLOW-AUTHORITY` | All retained D-AUTH local cases plus DA17 must pass. Current Codex joins native OR01/OR03/OR17 and applicability in EV216-CLOSING-WINDOW; positive DA08/DA12/DA14/DA15 stay NOT_RUN. Qualified authority requires original positive native proof. |
| `AC216-CLOSING-RESOURCES` | `R216-CLOSING-WINDOW`, `R216-ACCOUNTING` | `EV216-CLOSING-RESOURCES` | All retained D-RESOURCE local cases, cumulative costs and late settlement must pass. Current Codex joins native OR09/OR11/OR17; positive DR13/DR15/DR19/DR20 stay NOT_RUN. Qualified route requires original joined proof. |
| `AC216-DEADLINE-CONTRACT` | `R216-CLOSING-WINDOW`, `R216-ACCOUNTING` | `EV216-DEADLINE-CONTRACT` | All retained D-DEADLINE local cases and old deadline/freshness invariants must pass. Current Codex joins native OR05/OR12/OR17; positive DD06–DD10/DD12/DD13/DD15 stay NOT_RUN. Qualified route requires original joined proof. |
| `AC216-A5-CAPABILITY` | `R216-IMMUTABLE-INPUT` | `EV216-CLOSING-WINDOW` | All12 independently pinned A5 boundaries meet either full strong qualification or reviewed limitation with exact-source refusal and consumer evidence. |
| `AC216-A5-SCHEMA` | `R216-IMMUTABLE-INPUT` | `EV216-SCHEMA` | Closed A5 policy/request/decision/context/adoption records and native manifest/state cross-field validation reject forged strong variants, malformed/stripped bindings and downgrade of frozen requirements. |

## AC216-SCHEMA

Requirement: `R216-SCHEMA`

Converge implementation/final-audit runtime validation with published schemas through one shared validation source, preserving lineage, bounded inputs and fail-closed verdict semantics.

Acceptance evidence must prove: Mutate every required published audit field, type, enum and lineage independently through schema and real task/final accepting routes; both reject the same invalid inputs. Valid predecessor reports remain readable under their documented guarantee; no accepting path uses weaker validation.

## AC216-BINDING

Requirement: `R216-BINDING`

Match each required evidence ID to its independently expected typed contract, subject and validated receipt; reject missing, unrelated, duplicate, stale, wrong-source/configuration/oracle or inapplicable evidence.

Acceptance evidence must prove: A receipt for one of five required IDs does not satisfy the others. Missing/duplicate ID, wrong task/attempt/plan/source, changed configuration/oracle/build, and stale digest fail. A complete exact mapping passes. Different commit history with identical tested content requires explicit validated applicability; a changed merge tree never inherits the old PASS.

## AC216-RECEIPT

Requirement: `R216-RECEIPT`

Provide a bounded versioned typed evidence envelope with producer, subject, lineage, evidenceId and digest; validate supported payload contracts and observation conditions without promoting raw output or advisory extensions.

Acceptance evidence must prove: Built-in versioned payload fixtures round-trip through the actual audit consumer. Expected contracts come from the frozen plan, not the supplied receipt. Unsupported kinds, missing required fields, spoofed producer claims, self-selected subjects and advisory extensions cannot satisfy required evidence. For a declared asynchronous negative observation, missing readiness or incomplete declared event/time coverage fails; valid bound observations pass without claiming that structural validation proves oracle semantics.

## AC216-PROVENANCE

Requirement: `R216-PROVENANCE`

Distinguish DECLARED from ATTESTED reviewer independence; require externally verifiable actor/session/subject provenance for an ATTESTED gate and preserve the existing same-actor or same-session rejection.

Acceptance evidence must prove: Self-asserted independent=true and renamed actor strings remain DECLARED; an ATTESTED gate rejects them. Same actor or same session, replayed/wrong-subject/stale provenance and untrusted issuer proof fail. Valid evidence passes the pure verifier under an explicit independently pinned TEST_AUTHORITY. Native ATTESTED remains UNSUPPORTED until a qualified route is reviewed; a fake issuer exercises rejection, never live attestation. Native ATTESTED claims or requirements reject missing or unqualified context, report-selected root/pin, stripped claims, wrong phase and same actor or session against any final author; imported PASS or quorum summaries cannot bypass revalidation.


## AC216-IMPORT

Requirement: `R216-IMPORT`

Validate the documented raw reviewer-input contract before normalization, preserve findings and actual command outcomes, reject ambiguous bindings and invalid values, and represent missing usage as unknown without changing quorum eligibility.

Acceptance evidence must prove: Wrong raw container/items, invalid status/budget types, conflicting bindings and malformed command outcomes fail before normalized output is created. Valid supported nested bindings preserve values and all findings. FAIL/nonzero exitCode is retained; WAIVED cannot manufacture PASS. Missing usage is explicitly unknown, observed zero remains zero, and imports retain their non-quorum default.

## AC216-PUBLICATION

Requirement: `R216-PUBLICATION`

Publish the changed contracts, migration and interpretation limits, synchronize every version consumer, and retain source-bound regression, security, quality and supported-platform proof.

Acceptance evidence must prove: Migration notes identify newly rejected inputs and show safe preparation without rewriting existing evidence. Version consumers and a new accounting fixture point to 2.16.0. Required local gates and Windows/Linux/macOS candidate checks pass with exact source identities and no threshold relaxation; missing telemetry remains UNAVAILABLE.

## Revision29 — complete current acceptance checklist

The eleven criteria added after revision 7 use exactly the current manifest requirement and evidence links above. Their proof obligations below restate the manifest final-audit gates; they remain `NOT_RUN` and require independent plan review and later executed evidence.

## AC216-ACCOUNTING-CORE

Requirement: `R216-ACCOUNTING`

Evidence: `EV216-ACCOUNTING-CORE`

Acceptance evidence must prove: Verify durable atomic identities/reservations, full actual once, sticky blockers, normalization and provenance-bound opening/pending import. Local core witnesses do not close host/all-role enforcement. IF01–IF04 additionally require exact declared source selection, candidate/estimator binding and fail-closed pure limits; planned tests remain NOT_RUN.

## AC216-ACCOUNTING-ENFORCEMENT

Requirement: `R216-ACCOUNTING`

Evidence: `EV216-ACCOUNTING-ENFORCEMENT`

Acceptance evidence must prove: Validate exactly12 adapter profiles against independently expected version/mode/claim/source bindings; accept supported guarantees or qualified limitations only with source-bound qualification AND exact-profile resolver refusal proof. Resolve every declared candidate capability; do not silently choose a weaker profile. Unknown telemetry is UNAVAILABLE, excluded routes never become complete run totals, and partial profiles do not synthesize financial closure/retention. Original core invariants remain mandatory. FULL_FINANCIAL claims require every original native AC01–AC13 across all roles/retries/coordinator/final reply. Other profiles need explicit validated source-case applicability, never fabricated PASS/N/A. Unsupported full Codex is not a universal blocker. Synthetic-only checks cannot qualify native-positive guarantees. IF05–IF08 additionally require exact ALK dispatch-role inclusion, bounded validator/auditor/retry/coordinator/closing projections, 4k/8k refusal, conditional 16k route and limited host-owned exclusion; planned tests remain NOT_RUN. IF05/IF07 direct managedTask launch and IF08 planningTask stronger-claim negatives must prove hostLaunchStarted=false at the actual pre-run boundary, including callers that bypass continuation.

## AC216-FINALIZATION-RECOVERY

Requirement: `R216-FINALIZATION-RECOVERY`

Evidence: `EV216-FINALIZATION-RECOVERY`

Acceptance evidence must prove: Original CC01–CC03 preserve accepted task/evidence/history identities and cumulative costs; required nonempty accepted set enters FINAL_AUDIT through authorized run-start without bypassing final outcome.

## AC216-CLOSING-WINDOW

Requirement: `R216-CLOSING-WINDOW`

Evidence: `EV216-CLOSING-WINDOW`

Acceptance evidence must prove: Current Codex must prove OR01–OR19 native protected refusal, reviewed exact-route applicability, zero unauthorized write/dispatch, ordinary/late-settlement preservation and explicit limitation. Shared EV retains A5 cases conjunctively. Original positive CC04–CC16 and joined native DS/DA/DR/DD stay NOT_RUN; qualified routes require their original positive proof.

## AC216-CLOSING-POLICY

Requirement: `R216-CLOSING-WINDOW`

Evidence: `EV216-CLOSING-POLICY`

Acceptance evidence must prove: WS01 pure closing-policy/state-contract witnesses reject forbidden actions, malformed active context and implicit authority; preserve deadline categories, historical outcomes and inactive legacy behavior. Pure data validation cannot substitute for original CC04-CC16 native activation/authority/atomicity/integration proof.

## AC216-WORKFLOW-STORE

Requirement: `R216-CLOSING-WINDOW`, `R216-ACCOUNTING`

Evidence: `EV216-WORKFLOW-STORE`

Acceptance evidence must prove: All retained D-STATE local cases plus DS23–DS27 must pass, including exact EV216-WORKFLOW-STORE case IDs for DS24–DS27. Current Codex joins native OR02 refusal and applicability in EV216-CLOSING-WINDOW; DS14 positive stays NOT_RUN. Qualified adoption requires original native DS14.

## AC216-WORKFLOW-AUTHORITY

Requirement: `R216-CLOSING-WINDOW`, `R216-ACCOUNTING`

Evidence: `EV216-WORKFLOW-AUTHORITY`

Acceptance evidence must prove: All retained D-AUTH local cases plus DA17 must pass. Current Codex joins native OR01/OR03/OR17 and applicability in EV216-CLOSING-WINDOW; positive DA08/DA12/DA14/DA15 stay NOT_RUN. Qualified authority requires original positive native proof.

## AC216-CLOSING-RESOURCES

Requirement: `R216-CLOSING-WINDOW`, `R216-ACCOUNTING`

Evidence: `EV216-CLOSING-RESOURCES`

Acceptance evidence must prove: All retained D-RESOURCE local cases, cumulative costs and late settlement must pass. Current Codex joins native OR09/OR11/OR17; positive DR13/DR15/DR19/DR20 stay NOT_RUN. Qualified route requires original joined proof.

## AC216-DEADLINE-CONTRACT

Requirement: `R216-CLOSING-WINDOW`, `R216-ACCOUNTING`

Evidence: `EV216-DEADLINE-CONTRACT`

Acceptance evidence must prove: All retained D-DEADLINE local cases and old deadline/freshness invariants must pass. Current Codex joins native OR05/OR12/OR17; positive DD06–DD10/DD12/DD13/DD15 stay NOT_RUN. Qualified route requires original joined proof.

## AC216-A5-CAPABILITY

Requirement: `R216-IMMUTABLE-INPUT`

Evidence: `EV216-CLOSING-WINDOW`

Acceptance evidence must prove: All12 independently pinned A5 boundaries meet either full strong qualification or reviewed limitation with exact-source refusal and consumer evidence. Unqualified strong requests cannot dispatch, silently downgrade, grant ownership exemptions or forge positive proof. Ordinary source/result/ownership/audit and independently required security/validity/atomic checks remain mandatory. Strong invariant unchanged; cf01-a5-capability-scope.json fixes branch-specific prefreeze and later runtime obligations; all six a5.capability.* cases required.

## AC216-A5-SCHEMA

Requirement: `R216-IMMUTABLE-INPUT`

Evidence: `EV216-SCHEMA`

Acceptance evidence must prove: Closed A5 policy/request/decision/context/adoption records and native manifest/state cross-field validation reject forged strong variants, malformed/stripped bindings and downgrade of frozen requirements. Open outer state shape does not bypass these checks. Valid legacy ordinary and explicitly compatible accepted-attempt lineage remain readable without positive A5 claims; original costs and current authority/validity predicates remain mandatory. Execute the WS216-01 A502/A506/A510/A511 oracles in cf01-a5-implementation-contract.json; structural plan validation alone is not runtime evidence.

The concrete matrices, source/ownership boundaries and platform proof in scope-decisions.md and evidence-plan.md are normative.

Revision 7 interpretation: the exact README contract, manifest acceptance.evidence descriptors and evidence-plan case IDs are required for all six ACs. Existing platform, provenance, task/final, source and quality gates remain. Current structural PASS does not close H01/H02 or establish implementation budget fit.

R6 provenance interpretation: a valid explicitly pinned test issuer exercises the signed reviewer contract. Production ATTESTED readiness additionally requires the qualified external issuer and trusted caller context. A structurally valid signature string, neutrality receipt or producer-selected trust root cannot satisfy that claim. Review this scope clarification before freeze; no AC is marked passed.

## Revision-7 native integration oracle

README defines the exact phase/caller map and proposed capability deferral. EV216-PROVENANCE must cover every added native caseId in the manifest, including missing context at freeze/task/final acceptance, expected ATTESTED with its claim stripped, wrong phase and all final authors. Tests must assert that failed provenance cannot advance acceptance. The valid-trusted-route case is TEST_AUTHORITY only. Independent S2 acceptance of the capability limitation remains required; no AC is marked passed.


Revision-9 execution proof: AC216-BINDING/RECEIPT include README's actual accepting-
route activation controls. P cannot accept WS216-01; the same native state must
be consumed by source-pinned C1 after the negative/positive controls and independent
audit. Copied report PASS does not bypass fresh receipt checks. AC216-SCHEMA retains
its task/final route requirements. Before any execution, an exact native candidate
must receive its own full independent report and reviewed inventory lock through
the README protocol. Preparation fields and structural PASS do not satisfy this.


## Revision-10 controlling accounting/recovery amendment

Revision10 is DRAFT. release-prerequisites.md and the manifest define the added minimal accounting/recovery scope, serial ownership, prospective token ceilings and unresolved prerequisites. accounting-and-recovery-cases.json retains original H04 AC01–AC13 and CF CC01–CC16. All earlier unchanged-scope/cap statements apply to their historical revisions; original acceptance, command, quality/security and publication gates remain. This amendment is not an accepting review, implementation proof, freeze or native authorization.


AC216-CLOSING-POLICY / R216-CLOSING-WINDOW / EV216-CLOSING-POLICY: the five purePolicyWitnesses in cf-integration-map.json belong to WS216-01 and must pass before its dependent native WS216-02 integration. This proves only pure scope/state-contract behavior; original native CC04-CC16 remain required.

AC216-WORKFLOW-STORE / EV216-WORKFLOW-STORE covers18WS01 cases in cf-d-state-contract.json; DS10/DS13/DS17/DS21 remain required WS02 EV216-CLOSING-WINDOW integration witnesses in addition to original CC04-CC16. Every case is NOT_RUN.

## r69l R11 PRE bootstrap successor (DRAFT)

For the current prospective PRE bootstrap, `r69l-r11-bootstrap-delta.md`, the r69l route/manifest, v9/v4 oracles and v5 schemas supersede earlier r69j/r69k one-turn, six-path, 70-path and v4-only PRE wording. Earlier text remains historical for its pinned revision and for unchanged task/release gates. The installed r69k lock remains authority until a separate full DRAFT/FROZEN S2, exact report, canonical lock and controlled transfer. The r362 FAIL remains open; no product/native/release PASS is inferred.
