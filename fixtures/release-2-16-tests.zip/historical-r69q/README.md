> **Current r69q exact FROZEN role-delivery candidate.** Current delivery authority is r69q-role-delivery-delta.md and r69q-role-contract.json. Superseded v4/v5 delivery/count/budget/roster/status passages below are historical ONLY for that enumerated delta; all unchanged product/ownership/security/native/release requirements remain mandatory. Exact DRAFT/FROZEN review and canonical lock required before transfer; installed r69p remains authority. C34 candidate96/C35=16; no implementation or host proof. WS216-01 DENY; Release NOT_READY. r413 exact r69q DRAFT accepted fullReview=true READY_TO_FREEZE, report SHA 4770d7fc3ecd16b5d2da2609ca3635ec2cdfce71eae066541643d24c00b9797d. Exact FROZEN shape requires its matching independent report, canonical lock and verified transfer; implementation/host/native/release proof not granted by plan status.

> **Current candidate: r69p C34-only exact FROZEN successor of installed r69o.** r408 exact r69p DRAFT fullReview=true READY_TO_FREEZE, independent report SHA 10230af5c7d40b953193fcc54a7977a9a4f96fbc9d330fe4698bb1c66f0e8bb6; this exact r69p FROZEN shape still requires its own matching independent report, canonical lock and verified transfer. All inherited status notices below are historical; current status and selectors are in manifest/route and r69p-c34-roster-delta.md. C34=77; C35=16 unchanged. WS216-01 DENY; Release NOT_READY.

> **Current candidate: r69p C34-only DRAFT successor of installed r69o.** This adds17 supplemental mandatory C34 cases (77 total) without removing any existing case; C35 remains16. All inherited status notices are historical. Current status and selectors are defined by manifest/route and r69p-c34-roster-delta.md. Installed r69o remains authority until exact independent DRAFT/FROZEN review, canonical lock and controlled transfer. WS216-01 DENY; Release NOT_READY.

> **Current candidate: r69o FROZEN shape of accepted r69n / r69l R11 requirements.** r379 exact r69n DRAFT fullReview=true READY_TO_FREEZE, body SHA 1385115514009a8bee9524fd343c694d9b41dc04b586c8c7f29ca37db776fa06; this r69o FROZEN shape requires its own independent matching report and canonical lock before installation. All inherited DRAFT/FROZEN status notices in this package describe historical provenance; active candidate status is defined by plan.manifest.json and route-bootstrap-contract.json. The r69l amendment requirements and pinned specification bytes are unchanged. Installed r69k remains authority until verified transfer; WS216-01 DENY and Release 2.16 NOT_READY.

> **r69k R10 FROZEN shape pending exact review.** r352 independently accepted the corrected 50-file DRAFT subject (body SHA `93cecf316b40a6564bf877bb5f3d253544f6c0576116c78a05b49088013e8079`) with fullReview=true and no findings. This candidate changes only status, review metadata and top historical notices; the FROZEN-shape report and canonical lock are absent. The verified installed r69j parent lock `c96f464a845c7e69a4fd08af705d55cffb3a4db328cf1eb5a1eef17b9d4d894b` remains authority. Older notices and DRAFT text below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69k R10 isolated DRAFT; independent plan S2 pending.** r348 independently accepted corrected R10 specification SHA `14e5fbba22aa6258ba051abccffec3a0b07b97a9e7174d20491889dbaa43bfda` for plan drafting only. This candidate raises the one-turn request cap to 245760 bytes and binds r69k successor to verified r69j parent. The installed r69j lock `c96f464a845c7e69a4fd08af705d55cffb3a4db328cf1eb5a1eef17b9d4d894b` remains authority; r69k has no independent plan review or lock. Older notices below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69j R9 FROZEN shape pending exact review.** r333 independently accepted the exact corrected DRAFT subject (raw reviewer body SHA `858e61c9211e114ed3392f1dd8425654857265e573b6a09312e4a6a98dededa2`) and closed R331-S2-M01. This candidate changes only status, review metadata and top historical notices; the FROZEN-shape report and canonical lock are absent. Older notices below are historical. Installed r69i parent lock `721d7e3fa60723d59708efddfe2166347af5abc0981d47153527b00382f0bd67` remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69j R9 isolated DRAFT; independent plan S2 pending.** r329 accepted exact R9 specification SHA `965d2c4c02d4dc80b9538288355294391feb94a0f3bd1e6899c0a3b070bf5d03` for plan drafting only. Candidate v3 support oracle `671ed21d004beedecb80e1785a478e1eb95375a3593df3cd0a731a0151a3b84e` and v8 source oracle `d19e5edb56f4908c949f4239763038915f27798f54e8cdbbc13db6a361f93834` are not installed. Parent r69i verified lock `721d7e3fa60723d59708efddfe2166347af5abc0981d47153527b00382f0bd67` remains installed in execution57. No r69j plan-review report or lock exists; WS216-01 native DENY and Release NOT_READY. Older notices below are historical.

> **r69i R8-R3 FROZEN shape pending exact review.** r301 independently accepted the exact DRAFT subject (raw reviewer body SHA `f96bbe126d9f2dd7bbcf996608a4cbf978d9ff8c39227deab75453878f4ab9fd`). This candidate changes only status, review metadata and top historical notices; its future independent report path is declared but the FROZEN-shape report and canonical lock are absent. Older DRAFT notices below are historical. Installed r69h lock `a1d7a69a05f5887b72165613ebb116bf59f2bf52b59d6f851c66b977c284976c` remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69i R8-R3 isolated DRAFT; independent plan S2 pending.** r299 independently accepted exact R8-R3 specification SHA `bef13eb0608b604ffb88a659abe8b0d940046b52ff5ca2f732eecd48ed924cb7` and source oracle SHA `5f7b3cee3f074ebfbf4129bd4058d38116ef8385be20e6fbcd965158bc07a4fe` for plan drafting only. This candidate overlays the `codex_exact_prompt.py` FULL-source row with typed AST slices and local dependency closure; all other R7/v6 requirements remain. Parent r69h verified lock `a1d7a69a05f5887b72165613ebb116bf59f2bf52b59d6f851c66b977c284976c` stays installed in execution57. This r69i candidate has no plan-review report or lock; WS216-01 native DENY and Release NOT_READY. Older r69h/r69g notices below are historical.

> **r69h R7 FROZEN shape pending exact review.** r288 independently accepted the prior DRAFT subject (raw reviewer body SHA `1a5a331060a81d40e9be6a366856ad4742004567520d91526883485ccd4e6399`). This candidate changes only status, review metadata and overview notices; its future independent report path is declared but the FROZEN-shape report and canonical lock are absent. The older DRAFT notice below is historical. Installed r69g remains authority; WS216-01 native DENY, Release NOT_READY.

> **r69h isolated R7 DRAFT — current delivery authority.** r286 independently accepted R7 specification SHA `b54ebc77c4cc89aed0d809a4d193a15a61e7132a651f6db18f6dc98051732ab1` and oracle v6 SHA `aa25670dc55f6c1fb28ba249b9f24dc6115e470e13e0a6d75166ed2023edb702` for plan drafting only. The copied specification preserves its historical pre-adoption status; this candidate now pins R7/v6. Installed r69g lock `673715e292661c13b6d9c7222434d60b2c0247a54a61d45cf5bd3861c3043a99` remains authoritative. r282's R5/v4 DRAFT review was CHANGES_REQUIRED; this amended DRAFT has no independent plan acceptance or lock. Older delivery notices below are historical. WS216-01 native DENY; Release NOT_READY.

> **r69g FROZEN shape pending exact review.** r254 independently accepted the prior DRAFT subject (raw reviewer body SHA 023d7fd1873d6094ef474f6ddc68e908fc28cc5dbf62e3d0f2891707fbeb58a4). This FROZEN-shaped candidate changes status/review metadata and overview notices only; its report path is declared but the independent FROZEN-shape report and canonical lock are absent. Older DRAFT notices below are historical. Installed r69f remains authoritative; WS216-01 native is DENY.

> **r69g DRAFT delivery successor.** Installed r69f lock SHA 45a280b5dfc5e83e88d6c1f4d635b9ace7e5d1adaf3f9795a1215288bfe54dd5 remains authoritative. Exact independently READY_TO_DRAFT S2 specification SHA 6e7981627ffa616a7fabba856dca343e6f43c5eeda773d0eb87a572bdc7a0e1a is copied as `review-delivery-spec.md`. The current candidate replaces the reviewer-body producer with a same-thread `turn/start.outputSchema` item after `review/start` text; it requires the clean sentinel, full-subject saved request, dual-item collector/fresh read and unchanged PRE limits. Older r69 review-delivery paragraphs below describe historical candidates and do not override `route-bootstrap-contract.json#auditJoin.delivery`. No native WS216-01 from this DRAFT.

# Release 2.16.0: Audit evidence and reviewer provenance truth

## Revision69 current DRAFT — current-Codex limited outbound proof

This isolated plan candidate has parent r68e verified lock SHA `a619308da56efc1fe0c23a65de9b8c04074e79e93d7247f02958b5a831af6c66` and accepted S2 specification SHA `c69a24fa6170ba4a509048c2d4cf218f970f793431bc2cce6e08ce8687dec018`. It is not reviewed or locked. All historical revision paragraphs below describe their then-current states; the r69 rules in `route-bootstrap-contract.json#limitedFitApplicability` and `alk-input-fit-contract.json#r69FitDisposition` govern this candidate. r68e remains installed authority; native WS01 DENY, Release NOT_READY.

The proposed current-Codex positive claim covers only ALK-constructed bytes accepted by the OS stdin pipe associated with the selected child, not model-visible input or child consumption. Per-role fresh diagnostic and catalog are prelaunch candidates, not future native equivalence. Strong host-fit/financial requests refuse before dispatch. After observed Popen, only complete same-attempt pipe write/close plus joined native success/usage can pass the new limited case; failure retains unknown cost. Original strong IF09/IF12 remain NOT_RUN for this limited profile. All other accounting, H05/A5, 12-adapter, privacy, 30-day cleanup, hourly scheduler, security/platform/publication and final-audit gates remain.


## Revision68b exact correction of r179 findings

The reviewer-authored `reviewer-body.json` is the exact completed App Server review text, closed schema and raw UTF-8 SHA. It cannot contain its own SHA or a later server read. After completed item/turn and `thread/read`, the ALK collector writes `independent-audit.json` with server IDs, exact raw-body SHA and canonical stable item-projection SHA; first-native admission reopens the item and verifies both, then the lead's later SHA join. Actor strings alone never qualify. Both artifacts and the selected-host positive IF09/IF12 remain `NOT_RUN` until separately admitted live qualification.

The active first-native authority is the exact reviewed r68 successor lock; r67b appears only as the locked parent. Prestart C34/C35 prove RB11-PRE only. Started raw request, diagnostic and credential-free effective config source are sealed in an immutable private inventory with a hash-only pending marker before possible start and handed to WS01's durable per-run obligation. Only credential-only ephemeral CODEX_HOME material may be removed at child exit; the retained config source and other started raw wait until authoritative full closure plus 30 days. Missing source equality or safe credential split refuses before start.

`route-bootstrap-contract.json#validation.phaseEvidenceMap` is the one-to-one binding for five WS01 journal, three WS02 CLI and three WS03 target case IDs to owner AC, EV, exact command digest and receipt path. Each phase has a separately admitted finite budget; these are subsets of existing task allocations, not extra prestart C34/C35 slots. WS03 owns `tests/operations/test_retention_maintenance_target.py` and the operation document; its static command executes against the selected release target's actual installed scheduler and ALK command, recording scheduler identity/cadence, journal/root/authority SHA and real no-due/due/overdue outcomes. Local mock or unqualified platform deletion cannot close combined RB11 or retention release readiness.

## Revision68 current draft: source-bound RB11 and maintenance handoff

This is the exact r68 draft successor to the reviewed r176 specification SHA `b4a00c69751e67bfc81c277d38e0f2904c7f862ef461bdc596feb4019a1dc413` and current r67b lock SHA `56766d2d39988723484ce412523bbb34ab6ac6ae31f9e5deae1c96a779b6e561`. r67b remains operative until a separately accepted full S2 review, matching report and canonical r68 lock. No present product test or native/model result transfers to newly added cases.

Pre-WS01 lead owns only the six unchanged bootstrap paths; C34/C35 and independent audit cover RB01–RB12-PRE, with RB11-PRE limited to pure fully-closed eligibility/refusal. RB11-RUNTIME is `NOT_RUN` at that audit. WS01 owns journal/finalization/private authority and durable raw cleanup after SQL collection; WS02 owns the existing lifecycle CLI and new maintenance test; WS03 owns the operational document and installed hourly target schedule. Combined RB11 `PASS` is final-release-only after all three runtime owners and a supported-platform target probe. The old two-command prestart limit does not consume poststart commands.

The maintenance command uses a pinned private authority SHA and accepts no independent journal/root override. Started raw details delete only after authoritative full financial closure plus 30 days; unresolved runs have no purge clock. An immutable raw inventory and per-run pending obligation survive SQL collection and partial/crash unlink, with hash-only totals/dedup/closure state retained. The journal write-admission boundary covers fresh closure, due and financial-exception checks through bounded unlink and obligation result. Windows/macOS/Linux targets prove equivalent private path, identity and race-safe deletion behavior or refuse before unlink, retain PENDING/OVERDUE and block retention readiness. Same-user Codex does not gain a protected-close claim.

The independent bootstrap review uses a separately admitted local Codex App Server candidate, distinct review thread, completed item/turn, raw-text SHA and live `thread/read` verification. Documentation and installed schema are only interface candidates; runtime qualification is `NOT_RUN`. Selected-host positive IF09/IF12, all12 adapters, H04/H05/A5, numeric, security/platform/publication and final independent audit remain required. The current Codex claim is only `ALK_CONTROLLED_INPUT_FIT`; full host input/U/FULL_FINANCIAL and protected close remain unavailable. Missing native or review proof denies launch, and missing retention target proof blocks release.

## Revision67 prepared FROZEN shape

The r159 READY_TO_FREEZE verdict binds only r66b DRAFT digest `3a4fcec5600b08d35bceb8a5c2ebe7795695cd292bc15215520dbac702267ffb`. r67 is a new exact candidate, with no lock or native authority. Review its source hashes, preview and active r67 bootstrap audit identity before freezing.

## Revision66 DRAFT — independent bootstrap audit and current 16k preview

The exact r65 DRAFT digest `067a8dba42447c4f79d5d51b4b5f20b089e7b925efee7b7d7258a83a5f840241` received independent `CHANGES_REQUIRED` at r155 for two Medium findings only. This preserved r66 DRAFT adds an independently produced, SHA/subject-bound pre-WS01 bootstrap audit result and corrects the active 16k disposition to the exact r66 local preview while selected-host/native proof stays pending. The prior six-path exception, private request, process-start/input split, C34/C35 RB01–RB12, 300,000 pre-run cap, task acceptance DAG and all release gates remain. r64 is still the current locked authority, but WS216-01 native admission remains DENY until r66 has its own accepting review/lock, audited bootstrap and fresh host proof.


## Revision65 DRAFT — pre-WS216-01 ALK route bootstrap

The r64 plan is independently reviewed and locked at digest `847315064f829d64698d8a7caed2b9c65604e0dc4fcf80a993433571f4c2099b`, but r147 found its first native WS216-01 launch cannot meet the required exact-prompt route: WS216-02, which owns that route, depends on WS216-01. The independently accepted S2 product specification SHA `a4289b37d3372295aa85556adf5627fc272a294a49a1ef299e26b2084e043aa7` defines a bounded lead bootstrap before WS216-01. This r65 DRAFT binds that temporary six-path write exception, private caller request, immediate observed start followed by measured stdin receipt, separate coordinator allocation and later WS216-02 handoff in `route-bootstrap-contract.json`. The WS216-01→WS216-02→WS216-03 acceptance DAG and all other release gates remain. The current public packet index has 18 ordered context refs, adding `route-bootstrap-contract.json`; IF04 and the exact pre-review preview must bind this revision. r65 has no accepting plan review or lock; r64 remains current authority and WS216-01 native admission is DENY.


## Revision64 historical prepared FROZEN shape — later reviewed and locked

Independent r142 accepted only exact r63 DRAFT digest `b4fa3223f6ca53a701cdab27c6bef875d49fdda6dcf30cc5447d87437a51c315`. This separate r64 fills lock-compatible FROZEN/review fields and updates current r64 route/evidence references without changing Choice B scope, numeric caps, commands, cases or release gates. Its exact 25-source bytes and local preview need a new independent full S2 review before matching machine report installation and lock. At that preparation point r60 remained locked authority; r64 was later independently reviewed and locked. Native qualification and release gates remain open.

## Revision63 DRAFT corrects start sequence and lock identity

Independent r62 full S2 review returned CHANGES_REQUIRED for a pre-run requirement on an observed post-start receipt and a stale r61 lock in the current accounting EV route. r63 separates prelaunch intent/reservation from actual post-start observation and requires the exact reviewed r63 lock. It changes no numeric cap, case, workstream/product ownership or other release gate. New independent review and separate lock are required.

## Revision62 DRAFT corrects exact EV and private artifact joins

Independent r61 full S2 review returned CHANGES_REQUIRED only for two Medium plan joins. This isolated r62 DRAFT adds the exact route command/oracle to the accounting EV and names lead-owned private snapshot/diagnostic and support-receipt path templates with WS02 producers, modes, cleanup and 30-day raw-detail retention. No adapter, numeric cap, existing case or other release gate changes. Exact r62 review and new lock are required.

## Revision61 ALK exact-prompt Codex route — DRAFT

The r135 S2 product specification (SHA `4e1245c0c8fc4c321f275829bf2953aea75e67c23e657b55a39f1ab360d88ae2`) received independent READY_TO_DRAFT in r136. This isolated r61 plan remains unreviewed. It adds only ALK-owned `codex-exact-prompt-v1` with explicit scoped claim, canonical final component prompt, stdin transport and private config qualification, and a shared pre-run direct/unified gate. The shipped Codex adapter/profile is unchanged; absent qualification refuses. Native and all release gates remain.

## Revision60 prepared FROZEN shape — exact independent review required

r59 DRAFT received independent READY_TO_FREEZE only for digest `3bc10fcd871481f8bc38d0143d129facb5c4532c8f7ba49f9b4abf2568f5ef82`. This separate r60 prepares FROZEN/review metadata for a canonical lock, without changing Choice B scope, IF01–IF12, numeric caps or release gates. Its exact 25-source bytes and 4k/8k/16k preview need a new independent full S2 review; only then may a matching machine report and distinct lock be installed and verified. r57 remains authoritative until that happens. Scoped current-Codex fit is not full host fit, H04 U, native qualification or release approval.

## Revision59 correction of independent r58 findings

The exact r58 full S2 review returned CHANGES_REQUIRED on M01/M02. This r59 DRAFT binds IF04 to the actual ordered 17-entry context index and states explicit precedence for current-Codex limited input fit. Older r30 15-entry counts and generic full-host 16k route prose are historical for this scoped claim, while stronger claims keep their full proof gates. No r59 independent review, lock, native result or release sign-off exists.

## Revision58 Choice B current-Codex limited input fit — DRAFT

The user selected the r121 Choice B product boundary. This separate r58 DRAFT allows only a reviewed, version-bound `ALK_CONTROLLED_INPUT_FIT` claim for current Codex after exact ALK envelope, public packet and fresh diagnostic prompt binding plus a declared output reserve. It does not prove the complete host request fits 16k, provider output enforcement, whole-call U or FULL_FINANCIAL. Stronger requests refuse without silent downgrade. IF09–IF12 join retained IF01–IF08 under WS216-02/C20; all are NOT_RUN. Exact r58 preview, independent full S2 review, a new lock and native route/negative proof are required before adoption. r57 remains the execution authority. Existing H04/H05/A5/all12 adapter, storage, security, platform and final gates persist.

## Revision57 prepared FROZEN shape — exact independent review required

r56 independent full S2 review returned READY_TO_FREEZE for exact DRAFT bytes with no open Medium/High finding. This separate r57 prepares the FROZEN manifest/review metadata required for a canonical lock; its report file and lock remain absent until independent review of r57 bytes. All DS24–DS27 evidence bindings, v5/v6 storage design, Choice B current-Codex protected refusal, ordinary work/late settlement and unrelated gates persist. This shape alone grants no execution or release authority; r52 remains the only lock.

## Revision56 migration evidence correction candidate — full S2 review pending

r55 independent full S2 review was `CHANGES_REQUIRED` only because DS24–DS27 were absent from EV216-WORKFLOW-STORE caseIds. r56 binds those four mandatory local observations and aligns acceptance/evidence descriptions, retaining all r55 storage design, Choice B current-Codex refusal, ordinary guarded work/late settlement and unrelated release gates. r52 remains the only locked plan. No tests, native proof, implementation authority or release approval is claimed.

## Revision55 storage migration correction candidate — independent full S2 review pending

r54 independent full S2 review was `CHANGES_REQUIRED` (R54-S2-H01/M01). r55 defines complete v5→v6 base/P02/v4 financial plus workflow/authority guard retarget, explicit legacy-v5 and qualified-v6 Journal modes, full v5 empty-workflow eligibility, metadata-before-receipt insertion, and one normative RunOutputAnchor validator. DS24–DS27 are required local cases; WR07 retains qualified/native scope. Choice B current-Codex protected refusal and ordinary guarded financial/late-settlement continuity, all H04/H05/A5/12-adapter/security/platform/publication gates remain. This draft has no accepting review, lock, native proof or release authority; r52 stays locked.


## Revision54 correction candidate — independent full S2 review pending

Revision54 corrects r53 independent full-S2 findings R53-S2-M01–M04. Positive protected closing requires explicit v5→v6 Journal migration and separate durable F0 B/P stage before E outbox; current Codex still refuses that route. Exact directory/mode/temp/route write inventory and disjoint event recovery are in the new contracts. The exact r54 local input-fit preview finds 4k/8k FAIL for all three workstreams and conditional 16k local PASS; actual host receipt is required before any 16k native launch. This draft has no accepting review, lock or native proof; r52 stays authoritative.


## Revision53 DRAFT — closing request contract

This unreviewed candidate closes the r71 full WindowRequest shape gap using the exact contracts in `cf-d-window-request-contract.json` and `closing-write-inventory.json`. It preserves Choice B current-Codex refusal and all r52 release gates. The independently adopted artifact root and package-root-relative B/E identity, F0 producer staging and F3–F6 publisher recovery are plan obligations, not implemented or accepted behavior. r52 remains locked; r53 has a local 4k/8k FAIL and conditional 16k PASS preview; it still needs complete write-inventory review, exact r54 local preview, independent S2 review and a separate lock; actual host fit is required before any conditional 16k native launch.


## Revision52 prepared FROZEN-shape candidate — Choice B current-Codex capability-scoped closing

The user selected Choice B. On the current full-access Codex route ALK must refuse protected adoption, root/epoch-0 publication, closing activation/grant and protected dispatch before write or process start. Positive CC04–CC16, DS14, DA15 and joined DS/DA/DR/DD cases remain NOT_RUN/UNPROVEN under their original IDs; distinct OR01–OR19 native negatives and independently reviewed applicability are required for a limited release. All 53 retained WS01 local cases, CC01–CC03, late settlement, H04/H05, A5 for all12 adapters, platform/security/publication and numeric caps remain mandatory. A qualified future route must pass the original positive native cases before enabling protected closing. This prepared candidate has no accepting review, lock, native proof, task acceptance or release permission; r48 remains current.


## Revision48 — prepared adoption-input candidate

Revision47 is a saved DRAFT without report, lock or native run. Revision48 is a distinct prepared FROZEN-shape candidate adding the closed D-STATE/D-AUTH adoption input and independently selected operator identity only. Exact source and 16k/4k/8k fit preview must be saved before independent S2 review; no r48 report, lock, run or task acceptance exists at preparation. The accepted r46 lock remains current until superseded by an accepting r48 review and new lock. DA15 operator qualification, WS216-01 implementation and every release gate remain open.

## Revision47 — DRAFT adoption-input staging

The reviewed and locked r46 package remains the current plan authority; its native run and WS216-01 acceptance have not started. Implementation found a precise `adopt_run` gap: semantic inputs did not define closed legacy history/accounting and independently selected root import. Revision47 stages only the D-STATE/D-AUTH adoption input and selection contract; it is DRAFT, with no review, lock or execution authority. A distinct prepared revision must bind exact source and fit preview before independent review. No case, command, owner, cap, adapter boundary, release gate or historical cost changes.

## Revision38 — complete cap-check preview before review

The independent full r36 review returned `CHANGES_REQUIRED` for R36-PREVIEW-H01: its otherwise exact preview omitted successful renderer cap checks, counts and explicit non-token outcomes. Revision36 and its nonaccepting report are archived; revision37 was a DRAFT staging successor. Revision38 is a fresh prepared FROZEN-shape candidate. Before any accepting review, save its exact read-only preview with every renderer check, count and limit for each workstream/window, explicit source/packet/context cap outcomes, six-role bounds and candidate/source identity. The actual review report, lock and run state are absent at preparation; the r34 nonadopted lock and r36 rejected preview confer no current authority.

## Revision36 — exact preview before independent review

The structurally valid r34 review and lock were superseded without adoption after independent finding R34-POSTLOCK-FIT-H01: no exact r34 preview existed before its accepting review. Revision35 was a DRAFT staging successor; revision36 prepared a new candidate and saved an exact pre-review preview. Its independent full review rejected the preview because it omitted mandatory complete cap-check receipts. No report or lock was issued for r36; all runtime, host and release gates remained open.

## Revision34 — archived nonadopted native review candidate

The full independent r33 review returned `CHANGES_REQUIRED` for R33-STATUS-M01 because active instructions still treated DRAFT-to-FROZEN preparation as future work. Revision34 corrected that status text, received a full independent READY_TO_FREEZE report and a structurally valid native lock, then was superseded without adoption after the exact pre-review preview gap was found. Its archive remains evidence, not current execution authority.

## Revision33 — status-bound native review candidate

The full independent r32 review returned `CHANGES_REQUIRED` for R32-STATUS-M01: several controlling paragraphs described that candidate as DRAFT/PENDING. Revision33 time-scoped those historical statements and prepared fresh bytes, but its full review found one remaining active-status conflict. Its `FROZEN` value and expected `READY_TO_FREEZE` verdict did not create review or execution authority. Runtime cases and host qualification remained open.

## Revision32 — prepared native review candidate

The independent r31 correction review closed R29-FIT-H01 for the exact r31 delta and found the composed S2 design ready to prepare for formal review. Revision32 was the first native review candidate. Its full independent review was nonaccepting because its declared status prose conflicted with its FROZEN-shape manifest; that report is archived outside the package and cannot authorize a lock. Input fit remains conditional on the exact existing host route, and IF01–IF08 and all runtime cases remain `NOT_RUN`.

## Revision31 — actual managed launch input-fit join

The r30 review found that the input-fit contract named adjacent ALK paths but omitted the actual local-profile `managedTask` process start. Revision31 binds `unified_start.py` and the `launch_preflight.py` pre-run gate, both already WS216-02-owned, and requires IF05/IF07 direct-launch negatives to observe `hostLaunchStarted=false` before `context.runner`. `planningTask` is explicitly a limited non-run operation and must refuse stronger task/run fit or financial claims before its process starts (IF08). The independent narrow review accepted this correction at the S2 design level; executable behavior remains `NOT_RUN`. Caps, commands and product code are unchanged.

## Revision30 — bounded ALK input-fit design

The r29 whole-candidate review found one High prefreeze gap: source selection and future validator/auditor/retry/coordinator/closing inputs were not bounded. The pinned `alk-input-fit-contract.json` now defines exact on-demand selection for its then-15 context references (historical; r59 has 17), per-role component limits and fail-closed dispatch, with WS216-01 pure selector and WS216-02 integration owners and IF01–IF08 planned oracles under existing C18/C20. Candidate worst-case measurement and independent review remain required. This is DRAFT, not implemented host-wide fit or release approval.

## Revision29 — complete acceptance-checklist join

The read-only r28 whole-plan verification exposed a pre-existing 6-vs-17 mismatch between the human checklist and the manifest. Revision29 adds the eleven already-declared criteria to `acceptance-criteria.md` with their exact requirement/evidence links and current final-audit proof obligations. It changes no AC ID, case, command, owner, budget or execution result. Structural reconciliation and independent review are still required; the candidate remains DRAFT/PENDING.

## Revision28 — context-window route decision

The source-derived r27 local context projection fails 4k-strict and default 8k for the current unsplit WS216-01/02; both pass local 16k checks. Revision28 binds those workstreams to a conditional 16k route or dispatch refusal and reviewed split. In historical r27 WS216-03 passed a smaller-input fixture; exact revision52 inputs fail 4k/8k and must refuse those routes. `prefreeze-fit-contract.md` defines exact host/version and input qualification; no local estimate establishes actual host fit, H04 enforcement or release readiness. This candidate remains DRAFT/PENDING.

## Revision27 — H05 command binding correction

The r26 independent H05 design review found that added validation commands 18–33 were referenced by raw SHA-256 instead of the required `canonical_digest(command string)`. Revision27 corrects only those digests in the manifest and two normative mirrors. Commands, case IDs, evidence subjects, owners and caps are retained. This is DRAFT; H05 re-review, fit, whole-plan review and all runtime/release gates remain open.

## Revision26 — separate design from executed proof

The r25 fit-ordering review found premature runtime-proof wording. Revision26 requires documented host feasibility, ALK refusal/admission design and independent H05 design coverage before plan acceptance; executable admission/refusal, usage/reconciliation and H05 test results remain post-implementation gates. Both findings are corrected in DRAFT only; no independent r26 acceptance exists.

## Revision25 — staged fit measurement, no gate waiver

`prefreeze-fit-contract.md` defines read-only candidate-side packet/input measurement before independent review, exact native packet comparison after a reviewed lock, and later actual host usage/profile qualification. The r24 packet projection is only 6803/6222/2850 bytes and omits host-owned input; it does not close fit. FULL_FINANCIAL still requires documented compulsory pre-dispatch coverage and an enforceable whole-call bound; limited routes must refuse stronger requests. H05 independent whole-candidate coverage, all runtime cases and release gates remain OPEN. This r25 amendment is DRAFT/PENDING.

## Revision24 — typed A5 evidence bindings

R23-A5-M01 is addressed as a DRAFT correction. The two existing required typed
evidence routes now conjunctively require their retained commands/cases and the
new owner-specific A5 command/cases. EV216-SCHEMA (WS216-01) requires
A502/A506/A510/A511; EV216-CLOSING-WINDOW (WS216-02) requires
A501/A503/A504/A505/A507/A508/A509/A512. All six r22 categories retain their
existing case IDs and now map to these owner cases through the implementation
contract's typedEvidenceJoin.categoryToOwnerCases. Both required EVs must pass
on their independently expected task/subject; an old-only or A5-only receipt is
insufficient. The same typed routes bind the exact implementation contract,
owner tests/fixture, and the WS216-02 boundary registry as configuration input.
Missing/wrong command, case or input identity must reject after implementation.
All A501-A512 remain NOT_RUN; this declaration does not attest runtime behavior.
Prior evidence obligations, source/validity/provenance rules and release gates
remain mandatory. A narrow independent review must close R23-A5-M01; structural
PASS alone does not do so.


## Revision23 — concrete A5 limited implementation candidate

`cf01-a5-implementation-contract.json` now defines the proposed closed records,
frozen policy/state/adoption join, ordinary planning request binding, exact ALK
launch/refusal and consumer hooks, all12 saved expectation targets, exact owners
and 12 future oracle groups. Status: DRAFT_REQUIRES_INDEPENDENT_DELTA_REVIEW.
The accepted r22 capability policy and r19-r21 authority/storage/resource/deadline
semantics remain unchanged. This amendment supersedes only their unresolved A5
integration placeholders; it does not claim full-plan acceptance or runtime proof.

Ordinary standalone context binds the actual explicit operation/input; it is not
a bearer authorization and needs no invented authority file or workflow attempt.
Frozen workflow requirements remain independently authoritative. Accepted attempts
retain original A5 classification/evidence/cost and use a separate adoption binding.
No strong-positive v1 variant exists. Every proposed strong request refuses.

R216-IMMUTABLE-INPUT maps to AC216-A5-SCHEMA / WS216-01 / EV216-SCHEMA and existing
AC216-A5-CAPABILITY / WS216-02 / EV216-CLOSING-WINDOW. All six r22 policy categories
are covered by A501-A512 in the contract. Future commands are declared in the
manifest, NOT_RUN. H05, measured packet/native-budget fit, independent delta and
whole-candidate review/freeze, implementation and actual all12/platform/final
qualification remain open. Existing caps are retained, never presumed sufficient.


## Revision22 — A5 according to existing host capabilities

User-approved scope: strong A5 is enabled only for an existing route with proven
continuous input protection. Other routes refuse that mode and may meet release
acceptance with a reviewed limitation plus actual source-bound refusal proof.
The positive A5 invariant is unchanged; no endpoint-hash fallback, silent downgrade
or immutable-input/write-scope exemption is allowed on a limited route. Ordinary
source/result/ownership/audit and independently required security/validity checks
remain mandatory; any operation requiring unavailable protection remains refused.

`cf01-a5-capability-scope.json` is the normative applicability authority for all12
adapter routes. Older unconditional A5 prerequisite statements below apply to the
STRONG_A5 branch; limited routes instead require a complete refusal integration
contract before freeze and actual route/consumer qualification before release.
H04 support does not establish A5 support. Unknown remains UNPROVEN, not PASS.
The accepted r19/r20/r21 design is retained. This r22 amendment needs scoped
independent review; full candidate readiness, H05, actual fit and all implementation,
storage/platform/final release gates remain open. Historical revision narratives
below are retained as history and do not override this current applicability rule.

## Revision21 — exact local proof and FINALIZE authority decisions

R20-DELTA-M01 is author-corrected pending independent narrow review. D-AUTH now
specifies distinct PRODUCE_PROOF and FINALIZE decision keys, both using the existing
signed grant action finalize and null claimId. They reference the original activated
grant/nonce without renewed allowance; genuine financial CLAIM remains separate.
A closed Q0 binds once-only local deterministic proof production; P records Q0/A0.
Final A1 binds the fixed Q and commits atomically with E and the final result/outbox.
Local variants cannot authorize model/provider/process/auditor/test work.

The accepted r20 current-receipt/ABSENT-cap corrections and final proof hash,
materialization/publication/replay construction remain retained. Only the affected
authorization and DS02/DS07/DD10/DD12 joins require review. All runtime cases are
NOT_RUN; original owners/commands/evidence IDs/budgets/gates and all12 adapter
limitations remain unchanged. No product code/tests/native/host changes or freeze.

## Revision20 — three precise joins after complete r19 review

The independent r19 review completed all14parts and confirmed R18-JOINED-M01
replay correction. Three Medium findings are author-corrected here, pending an
independent delta review: R19-JOINED-M01 separates pinned freshness policy from
current receipt observations; M02 distinguishes ABSENT and FINITE retained caps;
M03 specifies prepared proof inputs, separate producer/final decisions, downstream
committed envelope, exact materialization and publication/replay identities.

See D-DEADLINE.currentEvidenceJoin, D-RESOURCE.capBindingSemantics and
D-STATE.finalProofConstruction and their closed wire schemas. Existing case IDs
DD04/DD08/DD10/DD12, DR04/DR18, DS02/DS07 now include the precise counterexamples.
All runtime cases remain NOT_RUN. No product code/tests/native/host changes.
This block supersedes older review-pending/partial statements only for completed
r19 coverage. The raw r19 CHANGES_REQUIRED report remains immutable; no blanket
whole-release acceptance, freeze or native qualification follows. Existing exact
owners, command groups, evidence routes, budgets and retained A5/H05/fit/all12
adapter/platform/final gates are unchanged. Review only these deltas and joins.

## Revision19 — committed replay before pending-publication rejection

R18-JOINED-M01 is author-corrected pending independent verification. D-STATE P1
qualifies the authoritative store, P2 returns an identical committed result even
while publication is PENDING, and only the new-operation branch rejects pending
publication and checks fresh authority/revisions. Replay adds no event, allowance,
nonce, reservation, claim or dispatch. DS02 now holds publication unavailable
throughout its pre-ACK replay. No product code or test changed.

The previous independent report remains CHANGES_REQUIRED/PARTIAL with all unread
sections still unreviewed. This revision makes no new whole-design, native or
release readiness claim. All four contracts need completion of the bounded review.

## Revision18 — D-DEADLINE configured consumers and current time

cf-d-deadline-contract.json joins the four closing-window design contracts. Actual
runtime gate input is per-task controllerGates and its producer/phase configuration,
not securityGates prose. Only an independently declared compatible execution-only
predicate may consume signed closing permission; run/attempt wall budgets, evidence
freshness, lease/grace/I-O and opaque custom gates retain their original bounds.

The supplied historical receipt identifies project planning/immutable-gate.py and
its execution-deadline failure. Its old FAIL is preserved; historical script source
semantics/current runtime qualification remain unproven. No gate was rerun or
project script/host patched. New contract templates are reviewable before freeze;
actual compiled registry/source/clock identities must be qualified after implementation.

New workflow timestamps use canonical UTC microseconds. D-AUTH and D-DEADLINE share
the same fresh final decision observation; replay/projection never renews time.
Late useful results and all actual costs remain recordable, with reuse classified
separately from permission. Final-audit acceptance or a prepared proof file alone
cannot bypass finalization gates or commit COMPLETE after an invalid decision.

16NOT_RUN cases contribute8WS01 rule/clock-storage and8WS02 consumer/integration witnesses.
Seven exact ownership paths and two planned validation groups retain old owners and
native caps. The joined DRAFT needs independent review, then implementation/native
proof. CF01-A5/H05/actual fit/all12adapter/storage/platform/final gates remain open.

## Revision17 — D-RESOURCE prospective policy and current claim

cf-d-resource-contract.json defines the minimal ACCOUNTING_REPORTED_TOKENS_V1
policy effect in the existing journal, joined with D-STATE and D-AUTH. Signed
additional allowance A yields cumulative ceiling C=S+A at the exact signed anchor.
It never adds unused old allowance. Task/run/window constraints evaluate one charge;
old costs, caps, reserves, protection and violations remain. Source bound failure
or unknown opening cannot be repaired by raising a budget.

Activation records policy/window/nonce together. Reservation and once-claim both
validate current resource and authority state; claim includes the already reserved
U once. Each closeout transfer/refund stays with its original owner/window. A new
signed window may retire an earlier entitlement but cannot roll over unused A,
claim an old unclaimed permit or reset spend. Legacy billableTokens/invocations/
wallSeconds remain distinct unchanged guards; unsupported extension is unavailable.

20NOT_RUN cases contribute16WS01 resource witnesses and4WS02 integration witnesses.
Five exact ownership paths and two validation groups are added within unchanged
native ceilings. These are author design contracts, not implementation or evidence
of native enforcement. Configured D-DEADLINE consumers and their exact guard state
must be bound next, then the combined design needs independent review. CF01-A5,
H05/actual fit, all12adapter qualification and final release gates remain open.

## Revision16 — D-AUTH issuer, revocation and commit contract

cf-d-auth-contract.json defines an independently pinned operator root, a signed
per-run issuer snapshot and a separately signed closing grant. It reuses ALK's
Ed25519 implementation through a planned contracts extraction with compatibility
exports. A name, receipt hash, external pathname or TEST_AUTHORITY is insufficient
owner proof. Native bootstrap qualification remains required as DA15.

The existing SQLite writer transaction orders authority publication, nonce use,
workflow activation and financial claim. A revocation takes effect when its signed
snapshot commits locally. A prior committed claim is in flight and cannot be
promised cancelled by this protocol. Current authority/time and financial state
are rechecked at claim; historical replay cannot issue a new permit. Expiry during
projection or commit does not extend permission or cause checks to restart.

Sixteen NOT_RUN cases contribute12WS01 authority/storage witnesses and4WS02
integration/native witnesses. Eight additional exact ownership paths and two
planned validation groups preserve all previous owners, cases and finite ceilings.
This is a concrete design candidate, not implementation or independent acceptance.
D-RESOURCE must close the exact approval-policy schema/transaction/claim join next;
configured D-DEADLINE, CF01-A5, H05/actual fit and final review remain open.
Only ALK is changed by the planned implementation; all12adapter capability limits,
FULL_FINANCIAL semantics and30-day financially-closed detail retention are retained.

## Revision15 — D-STATE transaction and recovery contract

cf-d-state-contract.json selects one authoritative SQLite transaction for workflow
state/event/result, closing window, nonce use and qualified prospective policy.
JSON state/event files become derived, generation-bound projections. Existing
Journal transaction/version/writer admission is a primitive to extend, not proof
that this workflow feature already exists. A typed WS01 WorkflowStore port owns
storage/adoption/replay/publication; WS02 integrates state/kernel/events and every
permission consumer. No new database, JSONL authority implementation or benchmark
is introduced by this plan. Four exact paths and one planned command are added.

An operation committed before a lost reply returns the same durable semantic
result on replay. Pending/mismatched projection denies new dispatch. A claimed or
uncertain model invocation never restarts during storage recovery. Late expenses
remain recordable without renewing authority. Trusted JOURNAL_REQUIRED binding
prevents fallback to old JSON or a new empty accounting scope. Adoption requires
qualified legacy observation, known quiescent writers and preserved history.

The22 NOT_RUN cases separate18WS01 storage witnesses from4WS02 integration cases.
D-STATE is a concrete DRAFT design, not independently accepted or implemented.
D-AUTH commit-bound verification, D-RESOURCE same-transaction policy port, configured
D-DEADLINE consumers, CF01-A5, H05/actual fit and final candidate review remain open.
FULL_FINANCIAL limitations and30-day financially-closed retention remain unchanged.

## Revision14 — CF01/CF02 exact integration map

cf-integration-map.json is the current source/owner/oracle authority for this
integration. Fourteen rows separate source-read facts, reused accepted core proof,
declarations and proposed interfaces. Thirteen exact paths are added to the serial
WS01/WS02 ownership; no directory wildcard or product edit is authorized by DRAFT.
WS01 provides a pure closing-policy/state/finalization seam before WS02 native
activation. Direct CLI, Python and continuation routes must converge on the same
authoritative action/time/resource guard; ordinary task work cannot bypass it.

S2-R11-P01 is PARTIALLY_ADDRESSED, not closed. Existing neutrality signature code
is a domain-specific primitive, not a workflow owner grant. Kernel event append
and state replacement are separate; neither this nor accounting SQLite proves an
atomic activation/nonce/policy transition. The exact authority route, all-writer
transaction/recovery interface, configured execution-deadline/watchdog producers
and prospective resource policy API remain prefreeze design dependencies.
No literal execution-deadline consumer was found in the bounded repository source
search; dynamic/installed/configured consumers remain unproven, not nonexistent.

Evidence TTL, worker leases, process grace and capture deadlines cannot be extended
by a new execution permission. Expired permission does not discard valid evidence
or prevent late financial settlement; those actions do not grant new paid work.
CF01 A5/G-AUTH/G-OBS/G-TIME/G-CONSUME/G-SCOPE, H05 coverage and measured fit remain
open. No actor, receipt, counter, lock or runtime PASS is manufactured here.

## Revision 13 — pinned expectation inputs and staged runtime identity

All12 expectation templates are now populated in h04-adapter-profile-cases.json:
descriptor/capability hashes, selected versions with provenance, saved official
source snapshots, each documented candidate's ceiling/oracle, role and original
case obligations, and bounded qualification recipes. These are EXPECTED_NOT_OBSERVED
inputs pending independent review; no runtime profile is accepted by this revision.

r12's requirement for actual host executable/configuration hashes before freeze
is replaced by TARGET13 in h04-artifact-contracts.json. Before freeze review the
fixed targets, source hashes and claim/qualification policy. After implementation
bind exact existing runtime identity for every native-positive claim. A reviewed
source-bound limitation may use explicitly null runtime hashes and must reject
all native-positive/financial claims through actual ALK refusal. This grants no
host compatibility or permission to modify/install a host. Every documented
candidate still requires an individual justified disposition; no convenience fallback.

Native experiments require concrete admitted argv/configuration and source-bound
oracles before execution. The12x100000 ordinary planning allocations consume1.2M
of existing WS02 ordinary2M; remaining800000 covers integration/validation. WS02
protected250000 is shared once, not copied per profile. Request/time/tool/evidence
and validation-run fit remain unproven; this allocation changes no native cap.
Retained CF02/CF01 integration design, H05 coverage, actual fit and final independent
review still block freeze. No code/tests/native transition or release approval.

## Revision 12 — reviewed findings and current authority

r11 full-plan independent review returned CHANGES_REQUIRED (3 High,4 Medium).
r12 addresses S2-R11-H01/H02/M01/M02 in DRAFT; these are author corrections,
not independently closed findings. h04-artifact-contracts.json defines closed
artifact/request/result types, immutable expectation joins, exact comparison and
refusal rules, bounded producers and qualification milestones. The profile-case
file maps all21 profile oracles and all13 original core/native assertions.
WS01 produces pure resolver proof in its own EV; WS02 produces exact-final-profile
refusal after integration. Expected bindings are pinned templates, not runtime PASS; TARGET13 controls runtime qualification.
Before freeze populate and independently review all12 exact target/source/claim
and recipe expectations. Runtime qualification follows implementation and precedes
release. Existing CF02/CF01 transitive design, H05 independent coverage and actual
packet/budget fit remain open; no lock, execution or release approval exists.
Full H04 on current Codex remains optional; all12 scoped profile acceptance remains
mandatory. Earlier revision text is historical where it conflicts with this block.

## Revision 11 — current H04 authority

DRAFT. The user removed mandatory full H04 in current Codex. [h04-adapter-boundaries.md](h04-adapter-boundaries.md), h04-adapter-profile-cases.json and manifest revision11 control adapter-specific acceptance for all12. Every accepted profile requires both applicable capability/limitation evidence and exact-profile ALK resolver refusal proof. FULL_FINANCIAL remains strict but optional per supported profile. Earlier conflicting H04 statements below are historical; other release gates and original evidence remain unchanged. Independent specification review permits migration only; full-plan review, implementation and runtime qualification remain pending.


Status: **DRAFT, revision 9**. Independent specification/plan review and reviewed
freeze are required before implementation. No previous review approves these bytes.

## Product specification

ALK must decide acceptance from the exact required evidence and its declared
guarantee. Currently the audit facade can count any supplied evidence file as
satisfying the entire required ID set; report runtime validation is weaker than
parts of the published contracts; malformed raw findings and missing usage can
be normalized into misleading values. The accepted source is `v2.15.0`, commit
`8480ef61cccfacb92928cbc68f8849a59001d5b5`.

Users gain explicit missing/invalid evidence diagnostics, trustworthy evidence
mapping and honest reviewer provenance. Runtime validation and published schemas
share one contract. Existing artifacts are never rewritten to make them acceptable.

## Exact receipt contract candidate, revision 9

The following is normative proposed product behavior, not a claim that the 2.15
runtime already implements it. Names and limits below are fixed for this candidate.
The independent review and the ATTESTED integration decision below remain open.

### Shared values and limits

All new objects are closed: reject unknown authority-bearing keys, duplicate JSON
keys, invalid UTF-8, NaN/infinity, wrong types and trailing JSON values. A boolean
is not an integer. Object depth is at most 16. General strings are at most 8192
UTF-8 bytes; identifiers are nonempty, at most 128 bytes. Lists have at most 1024
items unless a tighter bound follows. No implicit trimming or case conversion.
Digests are 64 lowercase hexadecimal characters. Use core canonical_digest for
JSON identities, omitting only the object's own digest field; hash artifact bytes
with SHA-256. Never hash a reformatted artifact in place of its stored bytes.

Receipt JSON is at most 262144 bytes, inline payload at most 131072 bytes, raw
review input at most 1048576 bytes. Referenced artifacts keep the existing 8388608
byte cap; retain the lower of contract, task and run byte limits. At most 256
receipts, 64 components, 64 commands and 1024 case observations per receipt.
Use bounded readers before parsing, including object-depth enforcement. No remote
schema fetch, executable predicate, arbitrary plugin validator or new event store.

ArtifactRef is exactly {path, sha256, bytes}: path is a normalized repository-
relative path of at most 1024 bytes, contained under the authorized evidence root;
bytes is an integer from 0 through the applicable byte cap. Resolve containment
including symlinks, then read and compare both size and byte digest. Absolute paths,
parent traversal, missing files and escaped links fail. No implicit network reads.
Integer measurements are bounded by 9007199254740991, with nonnegative values
unless stated otherwise. Timestamps used below are monotonic integer milliseconds
within one declared clock, not evidence of a trusted wall clock.

### Expected descriptor in the frozen manifest

acceptance.evidence[] entries have unique id, required=true, artifactPath and a
validation object with schemaVersion=agent-expected-evidence.v1. Its exact fields:

| Field | Contract |
| --- | --- |
| schemaVersion | Literal agent-expected-evidence.v1. |
| kind | command-observation, composite-applicability or async-observation. |
| scope | TASK or FINAL. |
| components | Nonempty array of {id, repositoryPath, configurationPaths, oraclePaths, buildArtifactPath}; IDs and normalized paths unique. repositoryPath is contained in the already declared repository boundary. configurationPaths and oraclePaths are sorted arrays of contained relative paths (maximum 64 each); buildArtifactPath is a contained path or null for source-only proof. |
| producerRequirement | DECLARED or ATTESTED. It cannot be selected by the supplied receipt. |
| requirements | Exactly the kind-specific requirement object defined below. |

The descriptor lives in the existing validation field, not a second registry.
Select it by the exact evidenceId and task/final required set from the verified
frozen manifest. Verify manifest digest, lock inventory and state plan binding
before resolving it. A JSON file at state.manifestPath is not sufficient authority.
Reject absent/duplicate required descriptors and unknown required versions/kinds.
Current 2.15 structural recognition of this field does not prove typed enforcement.

For command-observation, requirements is {commandDigests, caseIds}: both nonempty
unique arrays. commandDigests identify exact strings in frozen validation.commands
using canonical_digest; caseIds name the required implemented oracle cases. They
are acceptance requirements, not case IDs invented by the receipt producer.
For composite-applicability, requirements is {allowHistoryOnlyChange:true}; all
expected components must be covered. For async-observation, requirements is
{surfaceId, readinessId, boundary}; boundary is exactly {kind:"duration",
minimumMilliseconds} with a positive integer, or {kind:"event", eventId}.

### Expected subject and envelope

A subject is exactly {packageId, runId, planRevision, planDigest, sourceRevision,
scope, taskBindings, components}. planRevision and each attempt are positive
integers. taskBindings is a sorted nonempty array of {taskId, attempt, resultDigest,
snapshotHash}: one task in TASK scope, all relevant accepted tasks in FINAL scope.
Resolve these values from verified state and independently validated result/snapshot
artifacts. Recompute current snapshot applicability through the existing native
source/result guards. Do not equate the base sourceRevision with the tested
candidate or trust a worker-supplied snapshot merely because its hash is formatted.

Each subject component is exactly {id, commitOid, contentDigest, buildDigest,
configurationDigest, oracleDigest}. commitOid is the full 40- or 64-hex Git object
ID, or null for a declared non-Git component. For the declared component root,
contentDigest binds a sorted inventory of tracked paths plus declared new source
paths, each {path, mode, sha256}; mode preserves file/executable/symlink identity.
Reject uncontained symlink targets. Hash configurationPaths and oraclePaths as
sorted {path,sha256} inventories; an empty declared list hashes the empty list.
Hash buildArtifactPath bytes when present; otherwise buildDigest=contentDigest
and the claim is source-only. Capture expected values from the candidate being
examined by the consumer, not by copying the envelope's component array. An
unavailable expected checkout/build/config/oracle is a blocker, never a wildcard.
These structural bindings do not themselves attest who executed the producer.

The envelope is exactly {schemaVersion, evidenceId, subject, producer, payload,
payloadDigest, receiptDigest}, with schemaVersion=agent-evidence-receipt.v1.
producer is exactly {actorId, sessionId, guarantee, attestation}; guarantee is
DECLARED or ATTESTED, attestation is null or an ArtifactRef. For DECLARED it must
be null. payload is inline and validated by its built-in schemaVersion. Check
payloadDigest=canonical_digest(payload) and receiptDigest over the envelope minus
receiptDigest. No untyped extensions influence acceptance. One envelope satisfies
one evidenceId only; duplicate IDs fail even if the receipt bytes are identical.

### Workstream command selection, revision 9

`validation.commands` is the frozen release command inventory. Required commands
for one workstream are the union of commandDigests in its required evidence
validation descriptors, selected through that workstream's evidenceIds. Resolve
each digest to exactly one inventory string using core canonical_digest(string).
Missing or ambiguous mappings block execution and acceptance. The producer cannot
select a different command, omit cases or substitute a later task's receipt.

| Workstream | Required EV command set | Earliest valid execution |
| --- | --- | --- |
| WS216-01 | Inventory command 1: core/schema/receipt/shared-verifier suites | After WS216-01 changes; no WS216-02 or publication suites |
| WS216-02 | Inventory command 2: core plus review/import/freeze/adoption integration suites | After accepted WS216-01 and WS216-02 changes |
| WS216-03 | Inventory commands 3–17: unchanged full release command set | After accepted WS216-02 and WS216-03 publication changes |

The exact command strings and EV digest arrays are authoritative; table positions
only help navigation. The complete original focused regression, full discovery,
security, architecture, quality, neutrality, platform and publication obligations
remain required for final release acceptance. They are not prerequisites for
WS216-01 acceptance. Publication receipts retain the exact 15 original command
identities and their candidate-platform proof obligations.

The existing compiler projects task evidence IDs, acceptance and contextRefs;
it does not project a per-task executable command list from the manifest. Each
workstream therefore references the frozen manifest and this evidence plan through
existing contextRefs. Before execution, the worker reads the verified frozen
manifest and resolves its required commands by the rule above; absence of those
inputs blocks execution. WS216-01's already-owned descriptor/receipt validation
must enforce the exact selected digests at acceptance. No new workstream schema
field, compiler implementation or automatic projection is claimed by this plan.
Runtime activation and complete host-packet budget fit remain separate open
S2-R7-H03/H04 findings; this command correction does not close them.

### Supported payloads and success conditions

1. agent-command-observation.v1 is exactly {schemaVersion, platform, commands}.
   platform is {os, architecture, pythonVersion}, nonempty bounded strings; os is
   linux, macos or windows. Each command is {commandDigest, status, exitCode,
   stdout, stderr, cases}. stdout/stderr are ArtifactRefs. status is PASS, FAIL
   or SKIPPED; exitCode is null for an unexecuted command or an integer in
   [-2147483648,4294967295]. Each case is {id, status, evidence}; status uses the
   same enum, evidence is an ArtifactRef or null. Reject contradictory PASS with
   null/nonzero exitCode. A required command succeeds only with PASS and exitCode=0;
   all required case IDs occur exactly once with PASS and non-null readable evidence.
   FAIL/SKIPPED/missing cases cannot satisfy acceptance. Extra command/case IDs or
   duplicates fail. Command digests must belong to the frozen expected command set.
   The independent reviewer still checks that an oracle actually tests its claim.
2. agent-composite-applicability.v1 is exactly {schemaVersion, previousReceipt,
   previousSubjectDigest, currentSubjectDigest, componentIds}. previousReceipt
   is an ArtifactRef to a valid prior receipt. Both digests bind their complete
   subjects; componentIds is the complete sorted expected set. All component
   content/build/configuration/oracle digests and all non-source lineage must
   match; only Git history identity may differ. Revalidate both receipts and
   the current native result/snapshot guards. This record never overrides an
   existing native source guard, changes a plan/run/task/attempt, or repairs
   missing observation coverage. Changed content or merge trees require new proof.
3. agent-async-observation.v1 is exactly {schemaVersion, surfaceId, readinessId,
   clockId, readyAtMs, coverageStartMs, coverageEndMs, boundary, violationCount,
   observationArtifact}. boundary is {kind:"duration", atMs} or
   {kind:"event", eventId, atMs}; observationArtifact is an ArtifactRef. Require
   the expected surface/readiness/boundary kind, one clock, ordered times,
   coverageStartMs <= readyAtMs <= boundary.atMs <= coverageEndMs, and for a
   duration boundary atMs >= readyAtMs + minimumMilliseconds. For an event require
   the exact expected eventId in the bound observation artifact. violationCount
   must be zero for the declared negative result. Pre-readiness completion,
   incomplete intervals/events, missing artifact and a seeded observed violation
   fail. Structural validity cannot prove semantic oracle sufficiency or honest
   execution; the fixture must include a delayed violation the oracle detects.

### Provenance interpretation and unresolved integration boundary

Compare producer/reviewer actorId and sessionId with the result's actor/actorRunId
and the independent assignment: either equality is self-review and fails. Different
strings and independent=true provide DECLARED evidence only. They never imply
cryptographic or external identity verification. Preserve existing stronger gates.

### Reviewer provenance wire contract, revision 9

This revision proposes a narrow reviewer-specific verification contract over the
existing Ed25519 primitive. It does not claim that neutrality receipts already
attest reviewer identity or that the new integration has been implemented.

**Reuse boundary.** Use contracts.canonical.canonical_bytes for signed bytes and
neutrality.ed25519.verify/fingerprint for cryptographic operations. Do not reuse
neutrality receipt schema names, their signed domain, their zero-counter semantics
or their signing authority. Existing signed neutrality bytes/readers stay intact.
The repository dependency policy permits review(level 1) -> neutrality(level 1)
and contracts(level 0); keep graph acyclicity and all existing quality gates.
No crypto algorithm copy, new key generation, signing daemon or identity database.
Release 2.18 R218-CRYPTO retains its separate hardening obligations; it is not
silently made a dependency or treated as providing this reviewer protocol.

**Public trust configuration.** agent-reviewer-trust-root.v1 is a closed object
{schemaVersion, revision, authorizedIssuers}. revision is a positive integer;
authorizedIssuers has 1..64 entries, each exactly {issuerId, fingerprint,
publicKeyHex, actorIds, phases}. issuerId and fingerprint are unique across the
root; actorIds is a nonempty unique array of at most 64 IDs. phases is a nonempty
unique subset of plan-review, task-review, final-review. publicKeyHex is exactly
64 lowercase hexadecimal characters (32 bytes); fingerprint must equal the
existing fingerprint(public_key), formatted ed25519: followed by 64 lowercase
hexadecimal characters. The root is public JSON of at most 65536 bytes. All shared
shape/depth/string bounds apply. Unknown fields and duplicate bindings fail.
A removed/changed issuer changes the root's canonical digest; stale proofs fail.

The caller must receive the root and its independently pinned canonical digest
from an operator-authorized host/workflow trust boundary, outside producer-writable
report/assignment inputs. A root copied from the attestation, an adjacent worker
file, or a model-supplied expected digest is never sufficient. Do not auto-discover
or generate trust roots. A frozen manifest may request ATTESTED; it does not grant
its author authority to appoint a trusted issuer. Public-key pinning authenticates
an issuer assertion at the configured trust boundary; it does not prove that two
actors are different human beings or that a model is trustworthy.

**Attestation artifact.** agent-reviewer-attestation.v1 is exactly
{schemaVersion, claims, signer, signature}, at most 16384 bytes. signer is exactly
{algorithm:"Ed25519", fingerprint}; signature is exactly 128 lowercase hexadecimal
characters. claims is exactly:

| Field | Required value |
| --- | --- |
| schemaVersion | agent-reviewer-identity-claims.v1 |
| issuerId | Exactly the issuer selected by trusted caller context, authorized by the pinned root. |
| actorId, sessionId | Exactly the assigned reviewer identity and session from validated assignment/workflow state; nonempty bounded IDs. |
| phase | plan-review, task-review or final-review, equal to the expected phase and authorized issuer phase. |
| assignmentId, assignmentDigest | Exact ID and recomputed canonical digest of the current validated assignment. |
| subjectDigest | Canonical digest of the actual reviewed subject resolved by the consumer from current verified plan/state/result evidence. |
| trustRootDigest | Exact independently pinned canonical digest of the validated public trust root. |
| nonce | Deterministic challenge digest defined below, exactly 64 lowercase hexadecimal characters. |
| issuedAt, expiresAt | Real UTC timestamps in YYYY-MM-DDTHH:mm:ssZ form. |

Signed bytes are the literal UTF-8 prefix agent-lifecycle-reviewer-attestation-v1
followed by one 0x00 byte, followed by canonical_bytes of the complete attestation
object with only signature omitted. Thus the schema, signer and every claim are
covered. Reject signatures from the neutrality or lifecycle-control domains even
when they use the same key. Do not treat nonempty signature text as verification.

nonce = canonical_digest({domain:"agent-reviewer-challenge.v1", phase,
assignmentDigest, subjectDigest, actorId, sessionId, trustRootDigest}), with those
values taken from the independently resolved expected context. No producer-selected
challenge or new nonce store is needed. Reusing a proof for another assignment,
subject, actor/session, trust root or phase fails. Replaying the identical valid
proof in the same existing assignment is idempotent and cannot create a second
reviewer seat, independent-evidence credit or acceptance transition. Enforce this
through existing assignment/review identity and participation checks; do not add
a new ledger. Expired identical retries still fail freshness validation.

Use caller-supplied trusted reference time; never receipt-provided current time.
Require issuedAt <= referenceTime <= expiresAt, expiresAt > issuedAt and an
interval no longer than 300 seconds, with no implicit future-clock tolerance.
Unavailable trusted time, trust root, issuer selection or assignment/subject
expectation yields UNSUPPORTED and does not satisfy an ATTESTED gate.

**Verification API and ownership.** Plan one narrow new module
review/provenance.py, owned by WS216-01, with
verify_reviewer_attestation(attestation, *, trusted_context). This is a proposed
API. contracts/reviewer_identity_schemas.py contains only shape/field validation
and registrations; it does not import a higher architectural layer for crypto.
trusted_context is a caller-owned value, not a deserialized report field. It
contains exactly trustRoot, expectedTrustRootDigest, expectedIssuerId,
expectedActorId, expectedSessionId, expectedPhase, expectedAssignmentId,
expectedAssignmentDigest, expectedSubjectDigest, workerActorId, workerSessionId
and referenceTime. The caller validates their provenance before invoking the API.
Worker identity may be absent only where the native phase genuinely has no
implementation author; a missing required task author/session is a blocker.

The API validates bounds, root digest/key/fingerprint/issuer role, actor allowlist,
all expected claims, freshness, recomputed challenge and Ed25519 signature. The
actor OR session must differ from the actual result author; preserving the native
same-actor/same-session rejection is mandatory, including DECLARED flows. A
trusted issuer signing an unassigned actor cannot override that check.

Return agent-reviewer-provenance-validation.v1 with exactly schemaVersion, status,
guarantee, attestationDigest, claimsDigest, trustRootDigest, assignmentDigest,
subjectDigest and blockers. status is PASS, FAIL or UNSUPPORTED; guarantee is
ATTESTED only on PASS, otherwise UNAVAILABLE. Unavailable digests are null, never
fabricated. blockers is a bounded list of {code, field}; no raw secrets. Stable
families remain evidence-provenance-unverified and evidence-provenance-unsupported.
The returned validation object is diagnostic evidence; an imported producer copy
cannot grant authority. Each accepting consumer invokes verification using its
own expected context and binds the validated result to its current review.

review/validation.py, workflow/reviews.py and Review Mesh gates remain the caller
integration seams. WS216-01 task/final audit consumers obtain the same validated
result through these owned seams. Direct/non-Mesh review routes without a qualified
assignment or trusted context cannot claim ATTESTED; their existing DECLARED
behavior remains at its original guarantee. Import never grants trust or a seat.
Do not silently add fields to assignments or weaken any native acceptance check.

**Positive and negative evidence.** A bounded test harness may act as an explicit
test issuer with a public test root pinned independently of the receipt producer.
A valid signature proves this verifier's behavior under that test authority; it
is not evidence that a production host supplied an external attestation. Cover
valid issuer/actor/session/assignment/subject, unknown key, root supplied by the
producer, changed root, unauthorized actor/phase, wrong domain, altered claim,
wrong assignment/subject/session, future/expired timestamps, malformed signature,
nonce mismatch, same actor/session and repeated identical proof without new credit.
The test root must never be installed as a production trust root. Source tests
keep the existing signing-key/Ed25519 security gates; no stronger crypto claim is
made from the new wrapper alone.

### Native trusted-context boundary and capability decision, revision 9

This section governs integration and supersedes the provisional r6 caller/ownership
assumptions. No existing inspected native caller has a qualified trusted_context
source. R7 proposes an explicit native capability deferral, subject to independent
S2 review before freeze. It does not claim to have implemented an operator host.

**One trust boundary.** The sole positive verifier input is a caller-owned
TrustedReviewerContext value constructed in an operator-controlled process outside
the report producer's control. Its fields are exactly the trusted_context fields
above; shape/type or Python object identity does not authenticate its origin.
The pure verifier does not discover files, read env, create keys or attest that its
caller is trustworthy. A process in which the worker can replace the root, pin,
expected assignment, issuer selection or reference clock is not this boundary.
neutrality's external-file checks and env selection are reusable examples of
loading, not proof of isolation or a reviewer trust provider. Do not share its key
or signed domain. No CLI flag, report property or trusted=true value activates trust.

| Expected input | Authoritative source required at a qualified caller | Current inspected native route |
| --- | --- | --- |
| trustRoot, expectedTrustRootDigest | Operator policy root plus independently provisioned canonical pin; immutable to the report producer for this verification | Unavailable; neither repo file nor env proves separation |
| expectedIssuerId | Operator selection within that root's issuer/actor/phase allowlist | Unavailable; never selected by incoming signer |
| expectedActorId, expectedSessionId | Operator-observed reviewer launch/session bound to its selected assignment | Unavailable; assignment.reviewer strings alone are declarations |
| expectedAssignmentId, expectedAssignmentDigest | Independently selected existing Review Mesh assignment, schema/digest validated and bound to that launch | Available only conditionally; no native direct-review assignment is fabricated |
| expectedSubjectDigest | Consumer's freshly verified subject, matching the selected assignment subject; canonical digest over that exact subject | Existing plan/state/result checks remain mandatory; receipt.subject cannot supply expectation |
| workerActorId, workerSessionId | Current committed result identity after artifact, lineage and attempt validation, compared with trusted context | Task paths have result.actor/actorRunId; final paths must check every accepted result author |
| referenceTime | Operator-controlled verification clock, sampled for this call | No clock copied from report or replayed validation result |

For multiple final-result authors, invoke the same verifier against each distinct
actor/session pair and require every comparison to pass; do not extend the signed
claims or silently choose only one author. Missing required authors is blocking.
Plan-review has no implementation result author; existing plan-author independence
rules still apply. A valid issuer signature cannot override any native separation,
lineage, freshness, quorum, publication or completeness rule.

**Exact phase translation.** Keep native gate/config phase names unchanged. Map
only at the verification boundary from the consumer operation, never receipt.phase:

| Consumer operation and source | Native phase | Expected claims/assignment phase |
| --- | --- | --- |
| freeze/package_integrity.build_reviewed_plan_lock_v2; workflow/plan_adoption._verify_frozen_manifest | freeze | plan-review |
| workflow/reviews.validate_task_review via task_transitions.accept_task and task_outcomes; audit/implementation.build_implementation_audit_report | task review; implementation-audit at _review_mesh_summary | task-review |
| workflow/finalization.finalize_run and _validate_review_mesh_final_quorum; final implementation-audit acceptance | final-audit | final-review |

review_mesh/contracts assignments and their selected subject must use the expected
claims phase at an attested boundary. Unknown phase, wrong operation/scope or an
assignment from another phase fails. In particular implementation-audit is the
existing TASK report path, not a synonym for every final audit. No global string
replacement or fallback alias is permitted.

**Concrete API and native behavior.** WS216-01 supplies the existing proposed
verify_reviewer_attestation API and a shared guard in review/provenance.py:
validate_native_reviewer_provenance(review, *, native_phase, trusted_context=None).
The guard validates the phase mapping and the closed reviewer identity contract.
For this revision, all inspected native call sites explicitly pass None; adding a
positive operator-to-workflow forwarding route is deferred. A non-None input to
this native guard is UNSUPPORTED until that separate integration is qualified.
The pure verifier remains available to the explicit test authority.

The guard returns the provenance-validation schema above. With no attestation and
no ATTESTED claim it returns UNSUPPORTED/UNAVAILABLE, which preserves only a
DECLARED path when independently resolved policy permits it. A supplied attestation
or asserted ATTESTED guarantee never falls back to DECLARED after validation fails.
Any independently expected evidence descriptor requiring ATTESTED blocks on a
non-PASS result even when the supplied report omits the claim. This adds no native
policy switch and cannot weaken an existing independence requirement. Imported
PASS summaries and quorum receipts do not bypass revalidation.

| Owning caller seam | Integration obligation |
| --- | --- |
| WS216-02 review/validation.validate_independent_review and freeze/package_integrity.build_reviewed_plan_lock_v2 | Check raw reviewer provenance before accepting READY_TO_FREEZE; preserve exact package/report/lock checks |
| WS216-02 workflow/reviews.validate_task_review, validate_task_rework_review, validate_task_outcome_review | Use the same guard; retain same actor OR session rejection and route ACCEPTED through existing acceptance |
| WS216-02 workflow/review_mesh_gate.validate_review_mesh_quorum_gate/path | Resolve expected native phase from its caller; check underlying reviewer evidence; a quorum PASS alone cannot manufacture ATTESTED |
| WS216-02 workflow/plan_adoption._verify_frozen_manifest | Preserve verified manifest/lock authority and explicitly unavailable native context at freeze quorum gate |
| WS216-01 audit/implementation and workflow/implementation_audit_gate | Guard fresh task/final evidence at producing and accepting boundaries; use verified expected descriptors, never producer-selected requirements |
| WS216-01 workflow/finalization | Guard final review/audit before ACCEPTED/final proof, preserve all native final gates and non-accepting outcomes |

WS216-01 builds the shared contracts/verifier and their tests before its audit/final
consumers. WS216-02 integrates the remaining review/freeze/adoption consumers after
that API exists. No WS216-01 import may depend on a new WS216-02 symbol. There is
one writer per path; exact ownership is regenerated from the manifest.

**Evidence and freeze decision.** The pure verifier's positive fixture is
provenance.valid-trusted-route under explicit TEST_AUTHORITY, not a native route
qualification. Required negative integration cases cover every native accepting
seam, missing context, report-selected root/pin, stripped claims under an expected
ATTESTED descriptor, unknown/wrong phase, and final authors. No production trust
root or issuer is installed by tests. Production native ATTESTED remains
UNSUPPORTED. Its availability is not an AC PASS inferred from a test signature.
H01 remains PARTIALLY_ADDRESSED_IN_DRAFT pending independent acceptance of this
explicit capability deferral or a reviewed qualified-route amendment. H02 remains
OPEN for full S2 coverage, native budget fit and bootstrap. No freeze is authorized.

### Raw review import and compatibility

New raw input schema agent-reviewer-output.v1 is distinct from normalized results.
Required keys are schemaVersion, status and findings; optional keys are bindings,
budgetUsage, liveCallsStarted, commandResults. status is PASS, FAIL or SKIPPED;
findings is an array validated item-by-item by the shared Review Mesh finding
contract already published in agent-review-mesh-result.v1, with its existing
required fields/enums retained. Bounds above apply; no malformed item is dropped.
liveCallsStarted, when present, is strictly boolean, never bool(value) coercion.

bindings is exactly {assignmentId, assignmentDigest, subjectDigest}; values must
match the independently supplied assignment. All three are required when bindings
is present. For the documented legacy flat alias only, the same three names may
appear at top level: merge them only when complete and identical to any nested
values. Reject partial, conflicting or unknown binding spellings. Store the
validated values in normalized inputBindings without substituting claimed values
for assignment authority.

budgetUsage may be absent; when present it is a closed object with optional
invocations, inputTokens, outputTokens, wallSeconds. Each present value is an
integer in [0,9007199254740991]; reject booleans, negatives, fractions and strings.
A missing field becomes null with observation=UNAVAILABLE; an observed 0 stays 0.
Use normalized agent-review-mesh-result.v2: preserve v1 fields/meaning except
nullable usage, per-field budgetObservation (OBSERVED or UNAVAILABLE), inputBindings
and retained commandResults. v2 status additionally admits UNKNOWN for historical
input whose status was not reported; UNKNOWN never satisfies a passing gate.
Do not silently revise the existing v1 schema to claim that missing usage was zero.

commandResults is an array of {id,status,exitCode,evidenceRefs}; status is PASS,
FAIL, FAILED, SKIPPED or WAIVED; exitCode uses the command range above or null;
evidenceRefs is an array of ArtifactRefs. Preserve every valid entry and order.
FAIL/FAILED or any observed nonzero exit dominates normalized status as FAIL.
A WAIVED/SKIPPED/null outcome cannot create PASS. Retain findings and valid bindings
through redaction; redact values using the existing redactor without dropping
facts. Recompute digests only for the new normalized artifact. Import keeps
roundParticipation.eligible=false and cannot allocate or satisfy a quorum seat.

Validate raw input before coercion and before creating normalized output. The raw
source is read-only. Do not persist secrets in diagnostic/raw logs; report bounded
JSON-pointer errors, keeping the existing rawOutputStored=false behavior. A v1
normalized result is read-only historical evidence at its declared guarantee;
never relabel it as typed receipt, v2 complete telemetry or ATTESTED proof.

Unversioned input supports only the documented raw subset and legacy aliases above;
missing status stays UNKNOWN, missing usage stays UNAVAILABLE. Explicit malformed
containers/enums are rejected. Known older structured contracts retain their
existing readers and declared guarantees, but cannot satisfy a required v1 typed
descriptor without a newly produced, validated receipt. Unknown required versions
fail closed. Do not rewrite old evidence. Migration documentation lists newly
rejected inputs and both the raw and normalized schema versions before activation.

### Stable failure families and consumer ownership

Use stable codes evidence-contract-invalid, evidence-contract-unsupported,
evidence-id-missing, evidence-id-duplicate, evidence-subject-mismatch,
evidence-artifact-invalid, evidence-observation-incomplete,
evidence-provenance-unverified, evidence-provenance-unsupported and
review-raw-input-invalid. Attach bounded field pointers/evidence IDs, not raw
secret-bearing values. Existing more specific guards and failure facts remain.

WS216-01 owns manifest descriptor validation, shared receipt/schema checks,
audit.implementation report construction, workflow.implementation_audit_gate task
consumption and workflow.finalization final consumption. Both consumers resolve
fresh frozen expectations and revalidate evidence; neither trusts an old status
field or a copied suppliedEvidence list. Shared pure validators receive resolved
expected inputs; file/state loading belongs to the existing workflow/audit layer.
WS216-02 owns independent review and Review Mesh import/schema consumers and
compatibility. New schema modules register through contracts/schemas.py. Use
existing state, snapshot, contained-reader and review paths; no second controller.
All actual call sites and missing producer/verifier paths still require independent
source review before freeze. Full independent coverage remains OPEN; packet bytes do not establish native
100000/task or 300000/run budget fit.

## Requirements

- `R216-SCHEMA`: Converge implementation/final-audit runtime validation with published schemas through one shared validation source, preserving lineage, bounded inputs and fail-closed verdict semantics.
- `R216-BINDING`: Match each required evidence ID to its independently expected typed contract, subject and validated receipt; reject missing, unrelated, duplicate, stale, wrong-source/configuration/oracle or inapplicable evidence.
- `R216-RECEIPT`: Provide a bounded versioned typed evidence envelope with producer, subject, lineage, evidenceId and digest; validate supported payload contracts and observation conditions without promoting raw output or advisory extensions.
- `R216-PROVENANCE`: Distinguish DECLARED from ATTESTED reviewer independence; require externally verifiable actor/session/subject provenance for an ATTESTED gate and preserve the existing same-actor or same-session rejection.
- `R216-IMPORT`: Validate the documented raw reviewer-input contract before normalization, preserve findings and actual command outcomes, reject ambiguous bindings and invalid values, and represent missing usage as unknown without changing quorum eligibility.
- `R216-PUBLICATION`: Publish the changed contracts, migration and interpretation limits, synchronize every version consumer, and retain source-bound regression, security, quality and supported-platform proof.

## Scope boundaries and compatibility

Use the existing audit facade, workflow acceptance gates, manifest validation,
schema registry and Review Mesh import. A narrow new receipt schema module is
allowed by ownership; a second controller, event store, permission engine, general
receipt DSL, deployment tool or model runner is not part of this release.

Task BLOCKED/DEFERRED, waiver/contract-change semantics and adoption lineage remain
2.17. Builders and guided review preparation remain 2.19. Full provider-session
accounting and launch preflight remain 2.21. Oracle quality review and runtime
environment discovery are not secretly implemented by accepting a receipt schema.

New strict contracts may reject previously tolerated invalid input. Publish the
exact compatibility/version policy, stable errors and read-only interpretation
before activation. Preserve existing valid flows at their declared guarantee;
never present legacy DECLARED evidence as ATTESTED.

## Self-contained execution

Every executable fixture and its producer is ALK-owned and runs from this checkout.
Use component-a/component-b and generated temporary repositories/data, without
specific third-party projects, their paths, services, credentials or receipts.
Historic incident and review documents are advisory provenance only.

## Delivery and exit

Read the developer overview, this specification and the remaining declared plan
files. Follow scope-decisions.md for candidate preparation, independent review,
reviewed lock, native authorization and the retained validation gates. Each AC
has one owner, an EV and a final gate. Completion requires their bound applicable
evidence, independent task/final audits and synchronized publication metadata.


## Revision-9 execution authority and native review binding

This section controls the H03/H02 bootstrap and freeze preparation sequence.
At revision 9 the package was DRAFT and `planReview.status=PENDING`; those fields
were requirements for later candidate preparation, not a reviewer report. The
current revision 42 is a prepared FROZEN-shape evidence-order correction to
the accepted r41 plan. Its `planReview` names the expected review revision, not
an actual verdict; revision 42 has no independent report, reviewed lock or
native run. The r41 lock and r40 run remain historical authority for their
exact bytes and cannot accept implementation under revision 42. H04 input-fit
and H05 independent design coverage remain pre-review design; executable
profile, H05 and release proof are later gates.
Native caps do not change. Only plan.lock.json may be unlisted at package top
level; the reserved machine-readable review is a declared inventory member.

Revision 41 assigns four exact WS216-01 write paths needed by the existing
D-AUTH single-implementation Ed25519 move: `policy/python-quality.json`,
`tools/release/validate_input_privacy.py`,
`tests/release/test_ed25519_equivalence_validator.py`, and
`tests/release/test_input_privacy_validator.py`. The privacy validator must
compare the new contracts module's actual source and runtime origin, the
equivalence test must inspect the sole algorithm location, and the quality
baseline must follow the unchanged E741 source digest to that location. This
does not permit weaker AST, differential, timing, privacy, or quality checks.
No other owner, command, cap, case, acceptance gate or historical spend changes.

Revision 42 sorts `oraclePaths` in seven existing expected-evidence descriptors:
EV216-SCHEMA, EV216-ACCOUNTING-CORE, EV216-ACCOUNTING-ENFORCEMENT,
EV216-CLOSING-WINDOW, EV216-CLOSING-POLICY, EV216-WORKFLOW-AUTHORITY, and
EV216-DEADLINE-CONTRACT. This makes their order match the contract above;
the path sets, payload requirements, case IDs, command digests, evidence IDs,
owners and acceptance rules are unchanged. The new pure validator identified
these data defects before r41 execution, so no r41 run or task result exists.

Revision 43 corrects WS216-01 ownership for the D-STATE/D-AUTH store before
task start. The existing `accounting/workflow_store.py` is a JournalStoreMixin;
the planned public WorkflowStore is implemented in the newly assigned
`accounting/workflow_state_store.py`, with package-internal authority SQL in
`accounting/workflow_authority_store.py`. Both use the same Journal connection,
admission and transaction. This does not add a database, signing authority,
model call, acceptance case, command or budget. The r42 lock/run remain
historical and no r43 task or release evidence exists before a new review/lock.

Revision 44 corrects WS216-01 D-RESOURCE ownership before any native task
acceptance. The existing `accounting/closing_resources.py` is a 794-line
retention mixin, so the read-only membership/bucket recovery belongs in
`accounting/closing_resource_recovery.py` and pure policy proposal/candidate
construction belongs in `accounting/closing_resource_policy.py`. Both are
package-internal WS01 seams. The first r44 review found the unowned r58
`tests/workflow/test_final_typed_evidence_consumer.py` in historical WIP. Its
exact bytes remain preserved, but it is excluded from the r44 transfer; WS01
must carry its meaningful cases into already owned
`tests/workflow/test_implementation_audit_gate.py` before task acceptance.
Any activation or claim still requires the one
admitted Journal transaction and current D-AUTH/guard checks. No command,
case, evidence ID, budget, adapter guarantee or release gate changes. The
r43 lock is historical; unaccepted WIP may transfer byte-exactly only after
a successor is reviewed and locked.

Revision45 is a DRAFT staging successor after two nonaccepting r44 reviews.
The selected 62-file WS01 transfer and byte-exact excluded-test archive remain
proposed, not executed. No report, lock, native run, cap reset or acceptance
belongs to r45; a distinct prepared revision requires a new exact preview and
independent review before any WIP transfer.

Revision46 is that distinct prepared FROZEN-shape candidate. It retains the
same two WS01 D-RESOURCE ownership paths and the exact 62-file proposed
transfer, with the unowned historical test excluded until its meaningful
cases enter an already owned test before WS01 acceptance. New exact source
hashes, pre-review packet/fit preview and independent review are required;
the plan's unchanged commands, cases, evidence IDs, budget ceilings, adapter
scope and release gates remain binding. No report, lock or native r46 run
exists at preparation.

### Runtime activation before acceptance (S2-R7-H03)

The bootstrap runtime P is the accepted 2.15 source at
8480ef61cccfacb92928cbc68f8849a59001d5b5, tree
96b128e19a40ade814b7b4b2494879e1ee13245b. The inspected checkout commit
4ea1041ae9f385d10e3ee245435a705fd68989e6 has the same tree; commit equality
must not be inferred from tree equality. P supplies existing package lock,
compiler, initialization, authorization and task lifecycle operations. Its
_evidence_summary and task audit consumer do not enforce this release's new
expected-descriptor/receipt contract. No task or final acceptance for this release
may be performed with P, including acceptance of WS216-01.

1. After the exact accepting plan review and reviewed lock described below, use
   pinned P to verify the lock, compile packets outside the frozen package,
   initialize work/release-2-16/run.state.json and adopt with approval-required.
   Obtain existing native execution authorization, then start WS216-01. P can
   grant administrative permission to implement the reviewed change; it cannot
   certify the new evidence. Record P's executable, import root, commit/tree and
   source inventory beside this bootstrap evidence. The existing adopted
   sourceRevision is the real execution base, recorded separately from the
   component commit/content under test. Do not replace it with a runtime version.
2. Implement only WS216-01's existing owned paths. Before constructing its
   implementation-audit report or invoking task-accept, pin candidate C1: the
   complete candidate source including WS216-01 changes and its test/oracle/config
   bytes. Record actual repository HEAD plus a sorted path/byte-length/SHA256
   inventory of candidate source and changed/new files; canonical_digest of that
   inventory identifies dirty content independently of HEAD. A commit alone does
   not bind WIP. Record the frozen manifest digest, lock inventory digest, task,
   attempt, committed resultDigest and snapshotHash with these identities. Resolve
   runtime content and tested component content to the same source inventory;
   configuration and oracle digests remain separate receipt fields. Do not invent
   a future commit/digest in this plan. Store records under the existing evidence
   root as release operation evidence, not as a new native authority schema.
3. Use C1 to run the WS216-01 selected command and the acceptance-route regression
   below, then obtain the required independent task/implementation audit against
   exactly C1 and its result/evidence bindings. Test execution and report creation
   do not mark the task ACCEPTED. The reviewer must inspect the enforcing changes
   and source-bound results, not trust the worker's runtime label or summary.
   An unverified/failed C1 remains non-accepting; never fall back to P to pass it.
4. Start a fresh process pinned to C1 for the actual workflow task-accept and its
   implementation_audit_gate consumer. Keep the existing state, runId, adopted
   manifest/lock, sourceRevision, task attempt and operation history. There is no
   re-init, re-adoption, sourceRevision rewrite or bypass of result freshness,
   review, authorization, budget or ownership guards. The runtime activation point
   is BEFORE the first WS216-01 implementation audit and acceptance; P must not
   generate a permissive report that C1 merely imports as PASS.
5. WS216-02 and WS216-03 repeat source pinning for C2/C3 after their own edits,
   preserving accepted dependency evidence and current applicability checks.
   Their audits and acceptance use the corresponding verified candidate; final
   audit/finalize use the exact final candidate. Any runtime/source/config/oracle
   drift invalidates affected observations and requires affected validation and
   review. This is an operational source selection rule using existing entrypoints,
   not an installed-plugin upgrade, a new controller or proof of native attestation.

The launch is an explicit subprocess argv, with cwd set to the repository root:
`[python_executable, "-P", "-m", "agent_lifecycle", ...native_arguments]`.
Use Python >=3.11, PYTHONDONTWRITEBYTECODE=1 and PYTHONPATH set to the absolute
selected runtime src directory; remove inherited PYTHONHOME. Before use, a fresh
process under the same executable/environment resolves agent_lifecycle.__file__
and the concrete audit/implementation.py, workflow/implementation_audit_gate.py,
workflow/task_transitions.py and workflow/finalization.py module files; every file
must lie in that pinned source tree and match the recorded inventory. Validate
before/after operation; no concurrent source edits or long-lived cached imports.
The selected test command strings/digests stay exactly as declared in the manifest:
execute them in the matching candidate repository where PYTHONPATH=src resolves
that candidate. Record actual argv/cwd/environment identity with their observations.
Source-selection failures stop the operation; a version string alone is insufficient.
This recipe does not add an automatic runtime pin guard to the predecessor CLI.

**Required activation regression, implemented by WS216-01 in its already owned
workflow/audit tests and fixtures.** Build an isolated temporary repository with
an actually verified frozen manifest/lock, authorized v4 RUNNING state, WS216-01
VERIFYING task, valid committed result/snapshot and an otherwise valid independent
review/report. Invoke the real accept_task path (CLI workflow task-accept delegates
to it) through implementation_audit_gate.validate_task_implementation_audit_artifact.
Start with a complete valid receipt mapping as the positive control. For separate
negative trials, supply just one unrelated evidence file with a copied PASS/
suppliedEvidence summary, omit one required receipt, use a wrong subject, and use
an unsupported required descriptor kind. Reuse the existing EV216-BINDING and
EV216-RECEIPT case obligations; declaration does not add or pass a case ID. Keep
all unrelated guards valid so failure reaches descriptor/receipt revalidation;
assert the expected evidence failure family, task remains VERIFYING, state/event
bytes are unchanged and no task-accepted event exists. A second trial changes a
receipt after report creation and must fail at acceptance, even if the report
still says PASS. The valid unchanged control must reach ACCEPTED. Never run these
negative trials against the live release state. Test both report construction and
acceptance consumption; a facade-only unit result cannot prove activation. The
real WS216-01 acceptance additionally records C1's import/source identity and the
independent audit binding. R9 planning does not execute this regression.

### Exact native candidate preparation (S2-R7-H02)

Keep three identities separate: the revision-9 DRAFT source, its later native
review candidate N, and the reviewed lock. Revision 38 is already candidate N;
its reviewer report and lock are absent. Native source contract is
freeze/package_integrity.build_reviewed_plan_lock_v2 (lines 104-153), reached by
cli/plan_lock_commands.create_reviewed_plan_lock. The report binds the canonical
manifest, while the lock binds the raw bytes of all declared files including the
report. Manifest planFiles lists paths, not the report's digest; this removes a
self-hash cycle without weakening the final inventory check.

Before requesting an *accepting* review from a DRAFT source, resolve plan findings
and complete a distinct candidate revision N, with text calling it prepared and
non-authoritative. The recipe below records that one-time DRAFT-to-FROZEN-shape
transition; it was applied for revision 38 historically and now for revision
40 after the nonaccepting r39 DRAFT successor. It must not be rerun on this
prepared candidate. After any rejection, start a new DRAFT successor before using the
recipe for another distinct candidate; never recycle a reviewed revision:

```python
from pathlib import Path
import json
from agent_lifecycle.contracts import canonical_digest

manifest_path = Path("tasks/release-2-16/plan.manifest.json")
m = json.loads(manifest_path.read_text())
assert m["status"] == "DRAFT"
assert not manifest_path.with_name("plan.lock.json").exists()
n = m["planRevision"] + 1  # allocate a fresh revision, never reuse a reviewed one
report_path = "tasks/release-2-16/independent-s2-review.json"
assert not Path(report_path).exists()  # no placeholder or recycled verdict
m["planRevision"] = n
m["status"] = "FROZEN"  # native input shape only; no lock/acceptance exists yet
m["planFiles"] = sorted(set(m["planFiles"]) | {report_path})
m["packageIntegrity"]["allowedUnlistedFiles"] = ["plan.lock.json"]
m["planReview"] = {
    "required": True, "report": report_path,
    "reviewedRevision": n, "verdict": "READY_TO_FREEZE",
}
manifest_path.write_text(json.dumps(m, ensure_ascii=False, indent=2) + "\n")
reviewed_plan_hash = canonical_digest(m)
```

The prepared planReview.verdict is the expected accepting outcome required by the
existing API, not a review result. The actual independent reviewer alone issues
its verdict; rejection does not become approval because this field is present.
Do not create any report in this preparation step. Do not create a lock or native
state. Record the actual reviewed_plan_hash and each existing normative file's
raw SHA256/bytes in an external review-subject record, with the reserved output
path explicitly marked absent. The reviewer reads all source inputs under that
snapshot; the report is its output, not a pre-existing tenth source file. No
full-package filesystem PASS is claimed while that output is absent.

Require the real final report to be agent-plan-review.v1 with actual reviewId,
packageId, planRevision=N, reviewedPlanHash exactly as computed, fullReview=true,
reviewer.id/runId/surface and independently established reviewer.independent, an
actual verdict and findings. All native independence/provenance rules and complete
source/test coverage obligations still apply; declared identity is not ATTESTED.
The reviewer must verify the unchanged source-file snapshot before finalizing its
report. Non-accepting reports are archived with their candidate snapshot outside
live authority; any correction or binding change gets a fresh DRAFT revision and
a new review. Never convert the rejecting r7 report or a partial review to a
full accepting report. A human-readable .md is supplementary, not this JSON input.

Only after the actual full READY_TO_FREEZE report with no unresolved Medium-or-
higher findings exists, deposit its exact bytes at the reserved path. Recheck all
pre-review normative file hashes and the manifest digest; any change aborts.
Using pinned P, invoke the existing command from repository root:
`python -P -m agent_lifecycle plan lock-create --manifest tasks/release-2-16/plan.manifest.json --review tasks/release-2-16/independent-s2-review.json`.
Use the pinned environment above. It reads stable manifest/report bytes, validates
all bindings, builds the inventory including report SHA256, checks filesystem
integrity, creates plan.lock.json without replacement, and checks integrity again.
Capture the native receipt and independently inspect filesystemVerified, manifestHash,
reviewedPlanHash and planFilesHash. Then run existing plan check/verify with that
lock and recheck package integrity immediately before adopt-plan. The lock is the
first complete ten-file binding; no post-review manifest/doc edit is permitted.
Review the expected failure cases already implemented in tests/cli/test_plan_lock_commands.py:
DRAFT/REOPENED, non-independent/incomplete/rejecting report, wrong package/revision/
digest, open findings, unbound/changed inputs, and existing lock all reject.
Read-only inspection of those tests in r9 is not a fresh test receipt or proof
that WS216-02's future provenance changes preserve the protocol.


## Revision-10 controlling accounting/recovery amendment

Revision10 is DRAFT. release-prerequisites.md and the manifest define the added minimal accounting/recovery scope, serial ownership, prospective token ceilings and unresolved prerequisites. accounting-and-recovery-cases.json retains original H04 AC01–AC13 and CF CC01–CC16. All earlier unchanged-scope/cap statements apply to their historical revisions; original acceptance, command, quality/security and publication gates remain. This amendment is not an accepting review, implementation proof, freeze or native authorization.

## r69l R11 PRE bootstrap successor (DRAFT)

For the current prospective PRE bootstrap, `r69l-r11-bootstrap-delta.md`, the r69l route/manifest, v9/v4 oracles and v5 schemas supersede earlier r69j/r69k one-turn, six-path, 70-path and v4-only PRE wording. Earlier text remains historical for its pinned revision and for unchanged task/release gates. The installed r69k lock remains authority until a separate full DRAFT/FROZEN S2, exact report, canonical lock and controlled transfer. The r362 FAIL remains open; no product/native/release PASS is inferred.
