# Current r94 scope

Current executable tasks are WS216-02/WS216-03; accepted historical CORE is read-only baseline with all criteria reassigned to WS02 applicability/integration. Current r94 contract/selector/allocation override only old same-run/dispatch/task-allocation authority. The following product requirements remain; any old CORE execution instructions are historical baseline context, not a new worker. Full release predicates remain. No source implementation or task/release acceptance is granted by this draft.

# Release 2.16 — revision 88, approved ordinary release

Read ordinary-release-contract-r88.md first. Option A removes mandatory special Source authoring and explicitly owns 52 inherited WIP files. SQLite, cumulative known/unknown accounting, host capability limits, evidence/provenance/import, ordinary audits, retention and actual release proof remain required. Matching review and public lock precede execution; candidate labels confer no authority.
