# Prefreeze and runtime fit — r70

Ordinary reviewer packet targets and numeric caps in manifest remain. Use bounded file reads within finite admitted role budget; no raw one-turn source pack required. Retain per-role245760 known ALK request bytes,8192 output reserve,16384 context safety; hidden input/usage UNAVAILABLE. Native limited-input contract and actual selected-host gates are unchanged, including stronger-claim refusal. Exact source-bound runtime proof is required after plan installation.

Freeze candidate only: manifest status and planReview.verdict declare the required final shape. No approval exists until the actual exact-subject independent report is installed, canonical lock is created/verified and the whole package is transferred. Native DENY and release NOT_READY remain.
