# Current ordinary release contract — revision104

Immutable frozen103 product, oracle, ownership, DAG, numeric, acceptance, evidence and retention/platform/package requirements remain unchanged. Earlier execution dispositions, including consumed103, are historical inactive. bounded-execution-authority-r104.json alone selects the approved prospective execution scope; execution-source-scope-r104.md explains it without duplicating product requirements.

After actual independent review/freeze/lock/canonical packets and fresh finite admission with every existing actual guard, permit exactly one additional distinct ordinary f104 run on absent new state/event paths. At most one WS02 attempt and one WS03 attempt after actual WS02 acceptance. Maximum6 aggregate actual managed/host model launches, subject to every stricter inherited ceiling and separate genuine qualification/admission. No automatic retry or further renewal.

Preserve original f101/f103 runtimes/events/clocks/archives and all charges/full unknown holds. No old runtime adoption/reset, deadline extension, acceptance transplant, invented zero or refunded release budget. Preserve exact source/physical/partial proof after real applicability; repeat only missing or dependency-invalidated checks, not completed proof merely because resources expired.

All14 current typed joins and28 WS02 criteria, managed A5/deep consumers and task/final/retention/target/platform/package gates remain required. WS02 source edits remain forbidden; WS03 has only unchanged frozen ownership after actual start/admission. Unsupported protected requests refuse. No host/adapter modification or paid Responses API. Scope approval and this plan do not establish native permission, successful task acceptance or release readiness.
