# Current r94 scope

Current executable tasks are WS216-02/WS216-03; accepted historical CORE is read-only baseline with all criteria reassigned to WS02 applicability/integration. Current r94 contract/selector/allocation override only old same-run/dispatch/task-allocation authority. The following product requirements remain; any old CORE execution instructions are historical baseline context, not a new worker. Full release predicates remain. No source implementation or task/release acceptance is granted by this draft.

# Release 2.16: finish the ordinary release

Keep all 123 WIP files and valid results. Accept the existing implementation through public ordinary task APIs; preserve unavailable coordinator cost and all holds. Then finish FINAL_AUDIT recovery, integration, 30-day scheduled retention, applicable adapter/platform/package/publication proof and independent final audit. Special Source authoring remains disabled. Exact scope, ownership, sequencing, evidence reuse and rollback are in ordinary-release-contract-r88.md.

Revision89 corrects only the three source bindings reviewed in source-binding-correction-r89.json. It preserves original requirements, expense/history and expired clocks. A distinct lawful current context and all remaining actual release gates are still required; the new WIP snapshot grants preservation only.
