# Current r94 scope

Current executable tasks are WS216-02/WS216-03; accepted historical CORE is read-only baseline with all criteria reassigned to WS02 applicability/integration. Current r94 contract/selector/allocation override only old same-run/dispatch/task-allocation authority. The following product requirements remain; any old CORE execution instructions are historical baseline context, not a new worker. Full release predicates remain. No source implementation or task/release acceptance is granted by this draft.

# Current r81 WS01 ownership and local-proof correction

The active exact applicability contract is protected-positive-route-applicability-r81.json; ws01-local-proof-correction-r81.json defines the small ownership/evidence correction. Only closing_window_schemas.py and its pure test move from WS02 to WS01; WS02 reads them and retains native routing/publication. Original DD04/DR10/DR17 protected oracles remain unchanged and NOT_RUN_UNPROVEN until independently qualified support; three separate local cases are mandatory now. All ordinary accounting/cancellation/retention/read/refusal requirements remain. The new standalone schema command has its own digest; old commands/PASS are not renamed. No Source/TASK/native/release approval follows from this plan. Frozen r80 and all old costs/clocks/WIP are preserved.

----- BEGIN RETAINED PRIOR TEXT (historical selectors overridden only by exact r81 delta) -----
# Current r79 protected-positive applicability

User approved r648 choice A. Exact current route-dependent original cases and still mandatory local/ordinary cases are in protected-positive-route-applicability-r79.json. Current Codex proves unsupported protected-route refusal; no successful protected activation/producer/finalization is claimed. All ordinary accounting/retention/read and unrelated release conditions remain required. New local case IDs are deliberately narrower; original positive oracles stay NOT_RUN_UNPROVEN and are required before enabling their corresponding qualified mode. Valid earlier code/tests/source reviews remain usable with exact current joins. Frozen r78 and all existing clocks/costs are unchanged.

----- BEGIN RETAINED PRIOR TEXT (historical applicability overridden only by exact r79 partition) -----
# Evidence — r70

Keep existing manifest EV paths and typed command/case subjects for non-delivery product evidence. Ordinary audit uses private raw independently returned text, publication observations, source assignments, reports and fresh task receipts under work/release-2-16/evidence/ordinary-audit. Schema success is not semantic review, runtime or release success. Unknown usage remains UNAVAILABLE; preserve all old holds and source-bound results.

Freeze candidate only: manifest status and planReview.verdict declare the required final shape. No approval exists until the actual exact-subject independent report is installed, canonical lock is created/verified and the whole package is transferred. Native DENY and release NOT_READY remain.


## r74 EV216-SOURCE-USAGE

The exact expected evidence descriptor is in manifest and the source completion wrapper. Retain positive complete command origin, raw EOF streams, exact methods/subcases/refusals/timing/current-source/dependency joins. Current failed parent scoped commands and unqualified old158/51 inheritance cannot alone produce acceptance. Reuse valid unaffected evidence only under the existing source-bound inheritance rules.

----- END RETAINED PRIOR TEXT -----

----- END RETAINED PRIOR TEXT -----


## Current r82 semantic correction

Current authority, after actual independent review and public lock/verify only: architecture-correction-r82, standalone Source adoption and exact r661 oracle correction. Prior revision sections are retained historical context; active selectors and file ownership are in the r82 manifest and named contracts. All32 affected runtime implementation paths and affected tests belong to WS216-04; WS216-02 integration depends on completion, WS216-03 publication remains. Existing profile, ordinary, native/refusal, retention, security, quality and release gates remain. Expired r81 state and original clocks/costs are preserved. Current candidate has no lock or execution authority.
