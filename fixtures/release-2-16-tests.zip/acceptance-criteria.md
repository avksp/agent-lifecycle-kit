# Acceptance — revision 88

All current plan.manifest.json criteria and typed evidence remain conjunctive. Only R216-SOURCE-USAGE / AC216-SOURCE-USAGE / EV216-SOURCE-USAGE are removed from ordinary release acceptance by explicit user option A. The old Source observations remain history and optional regression input. Follow ordinary-release-contract-r88.md; never treat unknown costs as zero, ownership as semantic acceptance, a candidate as execution authority, or old raw failures as PASS.

| Criterion | Requirements | Evidence | Current disposition |
| --- | --- | --- | --- |
| `AC216-SCHEMA` | `R216-SCHEMA` | `EV216-SCHEMA` | Required; actual current evidence and independent acceptance pending. |
| `AC216-BINDING` | `R216-BINDING` | `EV216-BINDING` | Required; actual current evidence and independent acceptance pending. |
| `AC216-RECEIPT` | `R216-RECEIPT` | `EV216-RECEIPT` | Required; actual current evidence and independent acceptance pending. |
| `AC216-PROVENANCE` | `R216-PROVENANCE` | `EV216-PROVENANCE` | Required; actual current evidence and independent acceptance pending. |
| `AC216-IMPORT` | `R216-IMPORT` | `EV216-IMPORT` | Required; actual current evidence and independent acceptance pending. |
| `AC216-PUBLICATION` | `R216-PUBLICATION` | `EV216-PUBLICATION` | Required; actual current evidence and independent acceptance pending. |
| `AC216-ACCOUNTING-CORE` | `R216-ACCOUNTING` | `EV216-ACCOUNTING-CORE` | Required; actual current evidence and independent acceptance pending. |
| `AC216-ACCOUNTING-ENFORCEMENT` | `R216-ACCOUNTING` | `EV216-ACCOUNTING-ENFORCEMENT` | Required; actual current evidence and independent acceptance pending. |
| `AC216-FINALIZATION-RECOVERY` | `R216-FINALIZATION-RECOVERY` | `EV216-FINALIZATION-RECOVERY` | Required; actual current evidence and independent acceptance pending. |
| `AC216-CLOSING-WINDOW` | `R216-CLOSING-WINDOW` | `EV216-CLOSING-WINDOW` | Required; actual current evidence and independent acceptance pending. |
| `AC216-CLOSING-POLICY` | `R216-CLOSING-WINDOW` | `EV216-CLOSING-POLICY` | Required; actual current evidence and independent acceptance pending. |
| `AC216-WORKFLOW-STORE` | `R216-CLOSING-WINDOW`, `R216-ACCOUNTING` | `EV216-WORKFLOW-STORE` | Required; actual current evidence and independent acceptance pending. |
| `AC216-WORKFLOW-AUTHORITY` | `R216-CLOSING-WINDOW`, `R216-ACCOUNTING` | `EV216-WORKFLOW-AUTHORITY` | Required; actual current evidence and independent acceptance pending. |
| `AC216-CLOSING-RESOURCES` | `R216-CLOSING-WINDOW`, `R216-ACCOUNTING` | `EV216-CLOSING-RESOURCES` | Required; actual current evidence and independent acceptance pending. |
| `AC216-DEADLINE-CONTRACT` | `R216-CLOSING-WINDOW`, `R216-ACCOUNTING` | `EV216-DEADLINE-CONTRACT` | Required; actual current evidence and independent acceptance pending. |
| `AC216-A5-CAPABILITY` | `R216-IMMUTABLE-INPUT` | `EV216-CLOSING-WINDOW` | Required; actual current evidence and independent acceptance pending. |
| `AC216-A5-SCHEMA` | `R216-IMMUTABLE-INPUT` | `EV216-SCHEMA` | Required; actual current evidence and independent acceptance pending. |
| `AC216-OA-01` | `R216-OA-01` | `EV216-PROVENANCE` | Required; actual current evidence and independent acceptance pending. |
| `AC216-OA-02` | `R216-OA-02` | `EV216-PROVENANCE` | Required; actual current evidence and independent acceptance pending. |
| `AC216-OA-03` | `R216-OA-03` | `EV216-PROVENANCE` | Required; actual current evidence and independent acceptance pending. |
| `AC216-OA-04` | `R216-OA-04` | `EV216-PROVENANCE` | Required; actual current evidence and independent acceptance pending. |
| `AC216-OA-05` | `R216-OA-05` | `EV216-PROVENANCE` | Required; actual current evidence and independent acceptance pending. |
| `AC216-OA-06` | `R216-OA-06` | `EV216-PROVENANCE` | Required; actual current evidence and independent acceptance pending. |
| `AC216-OA-07` | `R216-OA-07` | `EV216-PROVENANCE` | Required; actual current evidence and independent acceptance pending. |
| `AC216-OA-08` | `R216-OA-08` | `EV216-PROVENANCE` | Required; actual current evidence and independent acceptance pending. |
| `AC216-OA-09` | `R216-OA-09` | `EV216-PROVENANCE` | Required; actual current evidence and independent acceptance pending. |
| `AC216-OA-10` | `R216-OA-10` | `EV216-PROVENANCE` | Required; actual current evidence and independent acceptance pending. |
| `AC216-OA-11` | `R216-OA-11` | `EV216-PROVENANCE` | Required; actual current evidence and independent acceptance pending. |
| `AC216-OA-12` | `R216-OA-12` | `EV216-PROVENANCE` | Required; actual current evidence and independent acceptance pending. |
